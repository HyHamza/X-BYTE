(function (_0x4abe1d, _0x26bbd6) {
  const _0x5e0f7d = _0x4abe1d();
  while (true) {
    try {
      const _0x4218d8 = -parseInt(_0x4254(1321, '064r')) / 1 + -parseInt(_0x4254(870, '5YW!')) / 2 * (parseInt(_0x4254(666, 'A(X&')) / 3) + parseInt(_0x4254(902, '1TkG')) / 4 * (-parseInt(_0x4254(500, 'xCT)')) / 5) + parseInt(_0x4254(644, 'L!Ee')) / 6 * (parseInt(_0x4254(729, '064r')) / 7) + parseInt(_0x4254(882, 'xCT)')) / 8 + parseInt(_0x4254(1350, 'pA&U')) / 9 + parseInt(_0x4254(330, '9d0P')) / 10 * (-parseInt(_0x4254(1020, 'L!Ee')) / 11);
      if (_0x4218d8 === _0x26bbd6) {
        break;
      } else {
        _0x5e0f7d.push(_0x5e0f7d.shift());
      }
    } catch (_0x5e31d6) {
      _0x5e0f7d.push(_0x5e0f7d.shift());
    }
  }
})(_0x163a, 330310);
function _0x4254(_0x5015ca, _0x4324db) {
  const _0x51dbf6 = _0x163a();
  _0x4254 = function (_0x4fcdc0, _0x4ca262) {
    _0x4fcdc0 = _0x4fcdc0 - 291;
    let _0x2f6c9a = _0x51dbf6[_0x4fcdc0];
    if (_0x4254.CYGlbE === undefined) {
      var _0x8a9242 = function (_0x365641) {
        let _0x109e9f = '';
        let _0x1058fb = '';
        let _0x2324b8 = 0;
        let _0x411393;
        let _0x1b0cf3;
        for (let _0x20cb8c = 0; _0x1b0cf3 = _0x365641.charAt(_0x20cb8c++); ~_0x1b0cf3 && (_0x411393 = _0x2324b8 % 4 ? _0x411393 * 64 + _0x1b0cf3 : _0x1b0cf3, _0x2324b8++ % 4) ? _0x109e9f += String.fromCharCode(255 & _0x411393 >> (-2 * _0x2324b8 & 6)) : 0) {
          _0x1b0cf3 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/='.indexOf(_0x1b0cf3);
        }
        let _0x135126 = 0;
        for (let _0x2cb3d0 = _0x109e9f.length; _0x135126 < _0x2cb3d0; _0x135126++) {
          _0x1058fb += '%' + ('00' + _0x109e9f.charCodeAt(_0x135126).toString(16)).slice(-2);
        }
        return decodeURIComponent(_0x1058fb);
      };
      const _0x27b815 = function (_0x337188, _0x2785eb) {
        let _0x34239b = [];
        let _0x167178 = 0;
        let _0x39b37d;
        let _0x2cb1e8 = '';
        _0x337188 = _0x8a9242(_0x337188);
        let _0xc5627a;
        for (_0xc5627a = 0; _0xc5627a < 256; _0xc5627a++) {
          _0x34239b[_0xc5627a] = _0xc5627a;
        }
        for (_0xc5627a = 0; _0xc5627a < 256; _0xc5627a++) {
          _0x167178 = (_0x167178 + _0x34239b[_0xc5627a] + _0x2785eb.charCodeAt(_0xc5627a % _0x2785eb.length)) % 256;
          _0x39b37d = _0x34239b[_0xc5627a];
          _0x34239b[_0xc5627a] = _0x34239b[_0x167178];
          _0x34239b[_0x167178] = _0x39b37d;
        }
        _0xc5627a = 0;
        _0x167178 = 0;
        for (let _0x1eddf = 0; _0x1eddf < _0x337188.length; _0x1eddf++) {
          _0xc5627a = (_0xc5627a + 1) % 256;
          _0x167178 = (_0x167178 + _0x34239b[_0xc5627a]) % 256;
          _0x39b37d = _0x34239b[_0xc5627a];
          _0x34239b[_0xc5627a] = _0x34239b[_0x167178];
          _0x34239b[_0x167178] = _0x39b37d;
          _0x2cb1e8 += String.fromCharCode(_0x337188.charCodeAt(_0x1eddf) ^ _0x34239b[(_0x34239b[_0xc5627a] + _0x34239b[_0x167178]) % 256]);
        }
        return _0x2cb1e8;
      };
      _0x4254.NeAmgC = _0x27b815;
      _0x5015ca = arguments;
      _0x4254.CYGlbE = true;
    }
    const _0x4ff563 = _0x51dbf6[0];
    const _0x360dc4 = _0x4fcdc0 + _0x4ff563;
    const _0xbbf2fd = _0x5015ca[_0x360dc4];
    if (!_0xbbf2fd) {
      if (_0x4254.mOpXzy === undefined) {
        _0x4254.mOpXzy = true;
      }
      _0x2f6c9a = _0x4254.NeAmgC(_0x2f6c9a, _0x4ca262);
      _0x5015ca[_0x360dc4] = _0x2f6c9a;
    } else {
      _0x2f6c9a = _0xbbf2fd;
    }
    return _0x2f6c9a;
  };
  return _0x4254(_0x5015ca, _0x4324db);
}
const config = require("../settings");
function _0x7f9333(_0x4a4c5e, _0x49d9b2, _0x134cfd, _0x5b5d4a, _0xb44d36) {
  return _0x4254(_0x4a4c5e - 0x2f3, _0x134cfd);
}
const {
  cmd,
  commands
} = require("../lib/command");
function _0x24a2f2(_0x485bfc, _0x133ba4, _0x315184, _0x1b48e1, _0x4dbc57) {
  return _0x4254(_0x1b48e1 + 0x2b4, _0x4dbc57);
}
const {
  getBuffer,
  getGroupAdmins,
  getRandom,
  h2k,
  isUrl,
  Json,
  runtime,
  sleep,
  fetchJson
} = require("../lib/functions");
var request = require("request");
const fetch = require("node-fetch");
var cheerio = require("cheerio");
let soundcloud = async _0x1fbc6d => {
  return new Promise((_0x396e2a, _0x4305c6) => {
    const _0x4234b4 = {
      method: "POST",
      url: "https://www.klickaud.co/download.php",
      headers: {},
      formData: {}
    };
    _0x4234b4.headers["content-type"] = "application/x-www-form-urlencoded";
    _0x4234b4.formData.value = _0x1fbc6d;
    _0x4234b4.formData["2311a6d881b099dc3820600739d52e64a1e6dcfe55097b5c7c649088c4e50c37"] = "710c08f2ba36bd969d1cbc68f59797421fcf90ca7cd398f78d67dfd8c3e554e3";
    request(_0x4234b4, async function (_0x50c7f5, _0x20ba07, _0x14bda5) {
      if (_0x50c7f5) {
        throw new Error(_0x50c7f5);
      }
      const _0x46cc3d = cheerio.load(_0x14bda5);
      _0x396e2a({
        'judul': _0x46cc3d("#header > div > div > div.col-lg-8 > div > table > tbody > tr > td:nth-child(2)").text(),
        'download_count': _0x46cc3d("#header > div > div > div.col-lg-8 > div > table > tbody > tr > td:nth-child(3)").text(),
        'thumb': _0x46cc3d("#header > div > div > div.col-lg-8 > div > table > tbody > tr > td:nth-child(1) > img").attr("src"),
        'link': _0x46cc3d("#dlMP3").attr("onclick").split("downloadFile('")[1].split("',")[0]
      });
    });
  });
};
let axios = require("axios");
function _0x4c3139(_0x50c02b, _0x38b307, _0x13d3d0, _0x8f4027, _0x419dcb) {
  return _0x4254(_0x8f4027 + 0x2d5, _0x419dcb);
}
async function ssearch(_0x434ad4) {
  let _0xec564c = await axios.get("https://m.soundcloud.com/search?q=" + encodeURIComponent(_0x434ad4), {
    'headers': {
      'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36"
    }
  });
  let _0x22ba9d = cheerio.load(_0xec564c.data);
  let _0x179bc0 = [];
  _0x22ba9d("div > ul > li > div").each(function (_0x1c5eec, _0x315076) {
    let _0xdfdca7 = _0x22ba9d(_0x315076).find('a').attr("aria-label");
    let _0x4080b9 = "https://m.soundcloud.com" + _0x22ba9d(_0x315076).find('a').attr("href");
    let _0x36617c = _0x22ba9d(_0x315076).find("a > div > div > div > picture > img").attr("src");
    let _0x14da50 = _0x22ba9d(_0x315076).find("a > div > div > div").eq(1).text();
    let _0x197a5a = _0x22ba9d(_0x315076).find("a > div > div > div > div > div").eq(0).text();
    let _0x1c868d = _0x22ba9d(_0x315076).find("a > div > div > div > div > div").eq(1).text();
    let _0x31a9f3 = _0x22ba9d(_0x315076).find("a > div > div > div > div > div").eq(2).text();
    const _0x3a6632 = {
      title: _0xdfdca7,
      url: _0x4080b9,
      thumb: _0x36617c,
      artist: _0x14da50,
      views: _0x197a5a,
      release: _0x31a9f3,
      timestamp: _0x1c868d
    };
    _0x179bc0.push(_0x3a6632);
  });
  return {
    'status': _0xec564c.status,
    'creator': "Caliph",
    'result': _0x179bc0
  };
}
function _0x163a() {
  const _0xe6a6b = ['W6jafuVdTG', 'W5qMd2nz', 'WP53x8k3W5e', 'W7ZcQmoaW4e', 'pgpcJG', 'aCkAWOe', 'iXHlWQGV', 'g8kKWQfIhW', 'WRPkxW7cJa', 'h8oPW5G2BG', 'F8k5sq', 'W55HDs3dOq', 'amoEW59AW4e', 'WR8Xw01c', 'W5KYWPNdMcu', 'W5DGWPddSmkT', 'A8oFmCo6', 'WP5LEmkkW4W', 'fCoGW5XYnq', 'pSo1W6JdPvO', 'AH9D', 'W60TievC', 'W448teddQq', 'eMeXWQHI', 'xCo5WP0', 'r8ocjdVdIW', 'W4ZdHanc', 'bcn2qCo7', 'fCoMW70mW6S', 'WPO/CI/cQq', 'yCogvIyW', 'WQxcQSofW5Gj', 'W5BdMIldHa', 'hmoOW5G', 'p2OSkCoL', 'jdNdJmogWQS', 'oSkDW6/dJd0', 'B33cHmklaW', 'omotnSoPmG', 'WOWbALa', 'W492x8obyW', 'WRlcQsSRWP0', 'ur3dGfSd', 'a8kLaNNcPW', 'WQVdNt1ODG', 'mctdSa', 'BNZcRa97pNeEk8o/lN4', 'WQlcH8oiW5qb', 'W7LZWRS', 'W5GOWPZcMxW', 'WPvGzq', 'WO/cIZu', 'CwyCW69v', 'WQ3cNxy7iq', 'gmo3WP0OCa', 'W6ZdP0NcSmk9', 'W5y+WPy', 'WRO0WR/cNa4', 'BCoCn8o6nq', 'mSkDW5CwW6S', 'W67dU04r', 'k17cGCoExa', 'W44oWRNcTwW', 'EMGp', 'd8kAdbtdUG', 'WQ/cPvXQcG', 'ec0QWQ4Z', 'W6ZdR04rcW', 'wNBdP8oB', 'W4L0WPVcQ8kP', 'WPZdSg7dHq', 'WPdcUgnPkW', 'jCosW5fKWOC', 'W7qVwspcTq', 'mqOVW5a/', 'amkVWR1Ueq', 'WRdcLhPnoG', 'E8ozjSk2BG', 'jCoFW5vyWOG', 'WP1UFs7cPq', 'BSkbjSoSzW', 'ksZdQIVcUq', 'WOObFKfu', 'AxxcPaf7', 'W7nSfK7dSW', 'W7eOiMDT', 'WQlcQHCBWRS', 'tSk1W6OeW7O', 'W7ekpLLz', 'WRdWQQkaWQXQna', 'W4fSiNFdTG', 'hmk/W7mYW4G', 'egGlk8oz', 'WPjGCJJcRG', 'zhBcIW', 'W47dMhaUWOm', 'u1rXWQiGp8kFDtJdTa', 'oCk5W7i7W5y', 'obddIJ/cTa', 'rXyLW7GU', 'jZldUsVcUq', 'laGPW5qb', 'WQ/cNZDY', 'u8olcZRdRa', 'WPtdNgxdJmk3', 'hCkZWRe5wq', 'C2afW6u', 'zmo/hsZdJG', 'W4tcOWiiWQ0', 'W4KuiNn8', 'iW1fWQS4', 'WRn3rCkF', 'w8owoCkJEG', 'W4f0Emkyea', 'WQSXW6v2uW', 'bHyM', 'WO3cQgj6oG', 'WQ9svHZdVa', 'W7uPBKldLq', 'gSkuWQnoea', 'W7tdQeKbdq', 'WP3dSgBdMa', 'w3DSWQ48', 'WPpcQMmUha', 'W7ZcNx84Ca', 'vMCHf8kV', 'W611WRRcJq', 'h8kWW54HmW', 'qLBcSbtcVW', 'W4eajXzq', 'qSogxbVcTW', 'h8oPid3dMW', 'W6mgjv9e', 'D2tdGI7dRq', 'iSkAW5uvW6u', 'w8oanNJdMq', 'W4ZdUMZcJ8kX', 'vmkMWQrVaa', 'CdFcNCk/EG', 'lt7cI8oEuW', 'ksmQW6CO', 'wwdcVY3dIW', 'mmkBW44C', 'mColsZW+', 'omoEuqu6', 'WRiKWOjeBa', 'cmkxgLhdPa', 'WP/cVZK9WQ0', 'W5ddLL0scq', 'FSodrY/cHW', 'eWC/W6m', 'WRRdIZz9', 'Dh0FW7m', 'WPnGAdpcRG', 'WQGnWR5Gwa', 'W53dLv5Aqq', 'yarmWQi5', 'W49pWPpdOcO', 'c8oSW5HHiW', 'WPxcQY0WFW', 'WQmYW67cN1G', 'yN5gW6Dw', 'pmo2WRBdSLm', 'nItcIY7dPG', 'gMWVdSkI', 'WPNdIdS2WOS', 'fmo8W7HnWRi', 'WOpHTipHTjNcMog0Tq', 'W6igW4hcGCoK', 'W44+WOhcNfy', 'h8kmWP0', 'osNdTtpcTq', 'W6VcLcLQW70', 'vwSTamoR', 'q0WQW4XU', 'WPv/WOZcLs0', 'imkyWQhcLLS', 'WPRdM2pcLCoZ', 'W6NcPmoi', 'jcnPqmkL', 'W7DYW7a7g8kLDXj9W4rila', 'mSoiW44mW68', 'rvRdQmolWRq', 'W7BdQeW', 'WQPmWPxcHCo2', 'W4aLDtBcPG', 'WRC0mSoLsa', 'W5hdNGTzWRi', 'W7uyyfhdOa', 'w8kvWPWBW5q', 'YydkGUg0HCoT4BwA', 'imkSW7xdQxG', 'WQ0XWRXYwq', 'DJRcQW', 'gMOMcG', 'ymo7amkzwG', 'WRrZrSklW4G', 'l8kfWRObW7e', 'gSoeltNdKq', 'WO1XFs/cTa', 'CSokzdhcQG', 'jmktW63dGs4', 'WOarWPPkxW', 'vvf2WQyR', 'WRaRWRXMBW', 'E8ovkSkU', 'WPjeWQBcJCkd', 'W4DQWRddRIa', 'q8ooic/dJa', 'mCkWjh/dLSoFW7njWQuoDdvh', 'pJFdOf87', 'dXyZW6C5', 'wadcJq', 'W7K6W6lcGWm', 'W5NdGGnltG', 'W5DYWRZcS8k+', '4BAp4BE2FVcEK7NIGyJWVjoZ', 'oSoqW59yWQS', 'BwpdHSoCWPW', 'fHCOW6mV', 'W7xdS0ucgW', 'vmo5W6H3eG', 'WQL1WQNcGr0', 'W5LEtCoEsq', 'WPOLCd7cRq', 'A8o/WR/cOaddRmkQjJWglSo0oq', 'W790WQZdHau', 'kSoHW6xdVL8', 'pINdVvC7', 'egOMbq', 'lMpcGs8', 'W5fBduJdTW', 'W6evluvt', 'WQWDiX9t', 'w3DQWRKY', 'W5WPWOBcMty', 'W7OtW4hcHCoY', 'uSkbB8oBW40', 'hmoYWQnvWQW', 'WOlcHZi/WO4', 'W4JdSe42iW', 'v8oblb/dPG', 'W7KDW4dcN8oZ', 'ksJdRJu', 'n8kUW6JdTx4', 'k8k1iMBcKW', 'W6FcQmojW7Cm', 'WQLKkW', 'uvj3WQb5', 'W63dVK8cgW', 'WQNWUBo6vsBdIa', 'gSouidNdJq', 'WQiUW7hdGqi', 'jmkyWQtcLNK', 'W5e+WOhcN28', 'WQ0pzu9Z', 'W6SSzKxdNG', 'BmoCpCkVBW', 'l8oGW45Jpa', 'aSkxdxlcRq', 'WO/cSNHGoW', 'W4fTAComqq', 'w8kipxxdIa', 'W4TUWOhcRCkV', 'WPPJvHFcKG', 'kZddLrhcIG', 'W5u8q0ddGq', 'uJpdHuXj', 'W4KUq0JdOW', 'pctdOf8N', 'W4LTEConqG', 'W4r7W5hdMg8', 'WQiSWQ57', 'W6LYW7pdLX4', 'WQ5qBSk7W5C', 'eSoKW5Lqoq', 'wuiUW7OT', 'WOLDt8oQyq', 'WRVdNc1SkW', 'W63dQComWPeW', 'puXaWQOS', 'nbOwW7mF', 'WQiAjuyx', 'lhdcNCoFva', 'FuyIW6z2', 'cqNdNG7cNW', 'fNRdSmoiWPWcza', 'zJ/dTsVdVq', 'BCkfmCoTAa', 'W5ySxKW', 'jLdcJmoovG', 'CSkOrSo9W6a', 'WO/cSXK/WRG', 'wIBcP8kPyG', 'W7SJlSo+', 'W5f9BSonqG', 'l8kXWPWiW5a', 'W4KYWOlcNwG', 'W4v3B8ovAG', 'oSkfySoJpa', 'cwyd8y6IUGO', 'h8ktbvhcPq', 'W6tcRSkaWOLf', 'DCkwW4W1W5C', 'aCktpLhcPG', 'ntDlW6vq', 'zNZcNsxdHG', 'W6StlvDs', 'uGnZWQKk', 'bmo9W7SaW64', 'emkUWR4Jtq', 'WQRcHN0G', 'dga7gCof', 'W73dM2aKW6u', 'W4/dGrXdxq', 'WO5KAc/cPa', 'WPNcUs1apG', 'pdNdOJm', 'W595eWtdUa', 'W4xcUwhdKCoV', 'WQ1kWQ3cOHy', 'sg1HWRq', 'kZhcJmofra', 'W4NdKh/cJCk3', 'WOVcGdmVWPi', 'icJdRJFcOW', 'WROyEWHt', 'WQNdNaLVCG', 'DrNdS38', 'zX8iWQCR', 'Y5BiSEg1SaRHTkq', 'W7pcTemAbq', '4BwM4BAbWP3HTi3HTzC', 'CmkQzCoCW6i', 'WPyVW5RdTq', 'WRy1WQrRxG', 'W73cMcXTka', 'WOhdUNVdHmoc', 'tIO0W6r3', 'W5K+WPW', 'BSoemW', 'omkyWQhcJwG', 'W5ddIM7cLSk/', 'WRWSWPHyBW', 'W5tdJM8LaG', 'W5BdHbrFrq', 'W6SgW4hcGW', 'hCkQWQLKfG', 'f3C8eW', 'W7emlW', 'zxRdQ8kaW6q', 'WQHKuq', 'W5tdQWb5ya', 'hGBdGgyK', 'bg5Lfmo9', 'W6xdS04r', 'cW0YW7nK', 'WOSuFK1b', 'WPZcGZe5WPy', 'WRPPESoOtq', 'cCkqWPySW6i', 'DSoQysdcHa', 'W5ldMMVcH8k2', 'WQ17WR3cTh4', 'W5e0WPRcNdu', 'WQ9/WQVcPcm', 'WOlcGx1IW4i', 'WQSxWOf0ua', 'WOlcIrWbWR4', 'WPxdVgtcK8k4', 'ASodiCk7Ba', 'W5BcGgi4WOm', 'z8osW55DWO0', 'rmorW5CRW6i', 'tSoOW6DGfW', 'pSkMW7dcSqW', 'WQRcQ0niWR0', 'm8oiWOPy', 'a3eK', 'lMtcICocuG', 'fSkRWQ0Jtq', 'B1pdSYyE', 'W5mW8y2qQMXq', 'AdFdQv4S', 'jbiEW6qh', 'kJFdUa', 'B8o6WRBcQau', 'mIddOf4N', 'd8kmWOS5W6a', 'E37dPSoSWPW', 'W7K2lSoPqW', 'BGNdPx8', 'gZS9W7rKrmoJWOddKmk/hmkk', 'W4O1WOpcL3O', 'WPNcTMVdK8oL', 'tCkiBCo/W5G', 'ltddTsdcVW', 'rMTRWQy', 'pSk5sSo1W7a', 'BwpdNa', 'ASocCSoKkW', 'umounJNdMa', 'thRdKCo1WOu', 'W60mDHa', 'z8ovm8k+BG', 'p2tcNSod', 'WO9eCmk/W68', 'imkxW4mmW6G', 'W5uchSkSya', 'xvxdTCoyWOK', 'W7WYkmoGsG', 'W7eBiLr1', 'WRvZwCkAW6a', 'W5BdKgVcHW', 'fCodlc7cNW', 'W5q8quhdRq', 'zCkxWQJcKgi', 'W6ddRK/cLmk/', 'z0STW6rU', 'WOJdVgBdMmof', 'WRRdUSkCWOae', 'WO/cVMLI', 'm8o0W4qvW6i', 'f8k6W43dSga', 'W73cMbjQW78', 'kgVdV1OH', 'WQ3dGsb9Da', 'WQPZtmkgW6q', 'WOJdSgBdM8oK', 'WORdRgFdImoT', 'W6fnDaih', 'iSkLWRWrW5a', 'x3bP', 'yfZcTsSn', 'C2FcJJZdTW', 'W7radLBdQW', 'WQCMW746ta', 'W7ddMxmDbq', 'WO3cIt4UWOC', 'W5BdUMddLCoK', 'WRCZxgH6', 'WQdcLI5HW7y', 'zW7dPgzj', 'aCkLWPTgnW', 'CshcUmk3DG', 'WQ/cNtfXW78', 'WP3cLdm', 'W4ZcJq9IW7S', 'qCocpsW', 'kCoEW5Su8yEcOG', 'W5ddHJqZWPq', 'b00SkCo9', 'W6qxW5NdNSkN', 'WPRcSN9JgW', 'W615mCoGtq', 'WRRdVHvhdq', 'W5zupbad', 'WOJcIsi3WQy', 'CSoteINdTq', 'W6ZcLazbW5K', 'dG8MW7aV', 'ESkOwW', 'CNBcNd3dRG', 'kxJcGCoouW', 'amoNWQ5Qhq', 'Fs3cQN/cHG', 'DCkydI44', 'W5e0WO7cNa', 'WORcHuKAeq', 'i20iW6DC', 'CaNdPh8m', 'mSoEtse1', 'kmkGW6VdHea', 'aSk1WRbnW7G', 'CmoGBZ0', 'yXddRITx', 'WQWDi10', 'W4D8celdSa', 'W7BdMtzLBq', 'b2fTWQq7', 'W47dNf1FwW', 'zNRcGY3dRa', 'W4xdPIvRsa', 'WOhcIb0fWPu', 'WPCtFeHA', 'WPJdRwFdJSo7', '4PAp4PAA4PsG4Pw1mW', 'WRRcGtL5pa', 'dmkchuy', 'gJa8WPS2', 'fCoXW4LMiW', 'W4JcIH8nWRy', 'WRfnhuzEdmkFyq', 'W6ixW5tcLCoY', 'W4Shkf1T', 'pmkMW6JdTq', 'ySorpmk+rW', 'WQJdHYjSFW', 'ymoYhbpdIq', 'FZRcVSkQqq', 'k8o0h8kJWQm', 'W5GeWPZcNxC', 'W4DRpColqq', 'BmkQr8o8W6u', 'W4/dHLNcRSk+', 'WPhcJGSnWR4', 'neJdRJG', 'DdRcQ8kfrW', 'WQTZamoi', 'EgmTW5rx', 'W4j4CG4', 'jCo2W5y5W5y', 'fY4xW68U', 'W6NdPcLHxW', 'WQ9OWRVdJa8', 'WOVcJZJcKCklE8kIW7iQ', 'gmoJEd4U', 'WOnBDCokqq', 'p8oYW7qfW7S', 'W7TXWQ3cRmkb', 'vKpcObRdLG', 'W4uYtfhdQa', 'FJJdQSoKeG', 'WOn7WP/cKxG', 'W6hcNh47iG', 'W4aWq0a', 'u8owdv3cSG', 'owxcLCoPBW', 'p8kcA8kmAG', 'oXtdUNiD', 'WORdNd4UWOO', 'CCkUqCo7W7G', 'wSoskZZdNa', 'WOJcHGS3WRi', 'WP3cSwrVla', 'rdrWwmk+CKS/W4PNfSkB', 'W64BW4pdKCkP', 'tSkEdfxcOa', 'aN7cL8ocuq', 'W5q+qKldVq', 'W5RcTWXnW6C', 'FZhdHCo8va', 'WRCGWQLHxG', 'W5hdMNm', 'W47cGJKSW4i', 'W705b8kyW7i', 'W6xcUCkE', 'W4ldVwLNkq', 'amkUWRXVfG', 'W67cJJPTW74', 'W5G2WPZcNN0', 'W50OW4BcK8oA', 'ghDNfmo/', 'n0VdR20n', 'gmkOWQLN', 'w2r3WP07', 'iSkLdvpcNq', 'kIVdOfin', 'p8kvW6ySW5e', 'tSoOW6DUxq', 'BmkOsCo5W6a', 'WOJcLcCeWQm', 'vLj+WQz4B8oRrHVdT3FcQmkw', 'WR9XWOVcMHO', 'WOVcGejqW7e', 'WOCLiNVcTq', 'jCkcW4WrW7m', 'v3JcMbVdMa', 'gCkFhvJcOq', 'W4JdTNJcKmkJ', 'YkllNog2MMFHT50', 'W5D9zCom', 'W6ldRLqh', 'lmkrWQq', 'CNpcTsBcOa', 'WP4/WOpcTuS', 'W6HVWR0', 'jmojsW', 'h3a8', 'g8k8WO11mq', 'CsVcVSk5wG', 'WQJdNcTSFq', 'a8orWPu5W68', 'W5iPWOlcIZu', 'W7RdNd1Ozq', 'hJldLaxcGG', 'edpdU8ogWQC', 'dCoeDJ3cIG', 'WPaREINcPa', 'bCkrWPS0W64', 'DrRdMLLO', 'W6NcLdfWW7q', 'W6dcMJPBW7i', 'jt3dTcpdQG', 'kCkgWRtcKh0', 'W5/dJhNcGSk0', 'imkHWQn6aG', 'WPabC0bq', 'W4b5ACoDsq', 'W4K+WPFcJa', 'WOS/WOZcNN4', 'W6n1WRddIqG', 'WOBcLrSbWQi', 'W6bVWQVdIuy', 'W7arirbe', 'W6DbeKW', 'zNlcTg0', 'W5j6DCoTtq', 'WRldSeq2oW', 'W6z6WQNdHXi', 'a8oWW6iiW68', 'abaaW7eP', '4Bw4WQxiPmQzCa', 'W7y5j39A', 'x3tdLCo8WQy', 'fSoGW4q', 'WQeaabxdVq', 'W6HPWQJcJvu', 'W4JdKavogW', 'WPDEqCkjW60', 'WRC0WQ7cOIK', 'W74tW4dcLCkL', 'f3CP', 'gMWPbq', 'W5RdQCkmWPbp', 'WQldIwmXmq', 'rSockZZdUq', 'xxBdSColWPW', 'jCkGgL7cIG', 'WPdcVci7Cq', 'WRXEkfLb', 'oeXrW7f/', 'emo9WQz3gW', 'W7uGnmkSzW', 'WPJdUhZdLCoN', 'xgnPWRGY', 's2hcV8krW7e', 'WQZcTIuPWQu', 'n1SDd8of', 'yCouWOhcIx4', 'prldPLSY', 'W6RdNZ5OEW', 'WR3dVCoiWOi', 'm8kbW5mzW6a', 'eSo5W6TnWRi', 'W7T3zmkSqa', 'omouW5DxWPu', 'W7KuWOpcGNC', 'hCk4WPlcShG', 'bmkDdbtcGW', 'fg8TqCkX', 'j8oftsuF', 'kmkeW5udWOi', 'mSkLWORcJfO', '8l+JSUkaRFcIG5pcIEg1J+g0HUg1Tq', 'hSkAWOaS', 'WR1PWPNcQb4', 'WQNdHYHW', 'W4tcJmoUW6vf', 'WO/cKJe', 'WQJdT8knW4ue', 'WP1HW4FdKG', 'jmoIb8oTW7W', 'W74tW5JcGq', 'WRDqcflcUa', 't2FdRmooWQe', 'W7FdSLuycG', 'WQZdJxGXDW', 'W7Trd0FdTW', 'WO7cIG4pWRq', 'W5NdHWyfWRy', 'A8k/ra', 'WO7dT3ZdMmon', 'swTKWQf3', 'WOBcIWmBWR4', 'W5NdI2pcJmk9', 'WOBcTIaCWRa', 'ocNdQs8', 'uSoIFWBcGq', 'E2VcThtdPG', 'WQeSWR4Ifa', 'umoXW6CBWQW', 'W78gW4hcNSo5', 'WPRdVsBdJmoG', 'lcRdOvGS', 'W7D1g8oy', 'WRq5p8o4EW', 'WQWDi1WA', 'WQfqwrZcQq', 'WQPOWQS', 'zezAWPKo', 'iW0WW7KM', 'bYNdQgFcKW', 'eXyUW7KT', 'W6zxWO/dIIy', 'wSkCW4TV', 'WR9ZWQBcTa', '4BAN4BA1uog0SEg0RG', 'WQVcSGisWPC', 'W711WRhdMq4', 'W6PVWQZdGc8', 'W5vXEmopxq', 'W4u4wu3dOW', 'wLVdQmoGWOy', 'vmkZWQPSfW', 'WQLHomoOhq', 'WQTNAmo+FamSW5BcPG', 'y3VdKdNcVW', 'WO/dUgxdJa', 'kSoeW7NdGgO', 'za/dUgOo', 'W4CWlmkrdG', 'WOmOWOvazG', 'rNBdVSolWRq', 'g8kgevVcLq', 'W74xW43cHq', 't2ddUCohWRW', 'W5mqWQVcVYe', 'W6VdK28TWRe', 'gs/dIalcPq', 'WPJcJZuTWPe', 'W6FcVSodW50k', 'WQT/raJcUa', 'sNZdSCoBWPa', 'lmoyW5Hq', 'jZ3dVMFcVq', 'CanhWQb5', 'WReSWQvNwq', 'W4/cRZ7cICoIWPJcMJddJdu', 'h8o4fttdMG', 'DKxcIWpdLG', 'W5VcUsldR8on', 'W5jWneVdLq', 'W6dcVCozW4ew', 'fcjHWQqH', 'WONcKemAbq', 'W5qQa0RdQq', 'iCotpCk2jG', 'BCkaz8oyW6W', 'BCoRDcxcLq', 'WRrMW6NcLq8', 'cCoGW4vI', 'W5PIW4ldP8kQ', 'WQtcJHyvWQy', 'DvZdRxKg', 'W7LLkxxdJa', 'cSkFWPGiW6S', 'q8kLW5L/jG', 'AeddTmoTWOi', 'W7LMW6G', 'WQRdGtLNFq', 'ldxdUf88', 'WPK3mSopwq', 'o8kBWOZcLKu', 'ACoGlwpdGa', 'WPxdTwFdNCoS', 'WP3cGZ4+WQa', 'iWHaWRfR', 'iCoapmk9', 'W7tcGwf+zG', 'W5v/Amo6za', 'zSogCSoKkW', 'WPVcUhK', 'W5rsWRNdHIq', 'gCoHW755pq', 'v8ovkJtdMa', 'yHxcUItcVW', 'yZVcUmk/eG', 'gxuXemoQ', 'vmoFWPWXW7e', 'dSkAbKhcOa', 'whaNfmoH', '4BEIW4FlTSUNW7e', 'W7NdQu4TbG', 'lsddUfmP', 'qXFcMSkFga', 'W4eFifLh', '4BE9rmQlYQSv', 'W6LbWO3dG8kN', 'gxpcNmo8Aq', 'lwPyW6qm', 'lwxcQHy8', 'WOTIWOVdIxG', 'eWNdLMez', '4Bw74BsgAmU4Yia', 'DWveWQi4', 'W5VdI37cKq', 'WP46hKhcUq', 'WPdcVg9RmW', 'oSkDhMFcNG', 'W4zeyK1w', 'W7r8W7a3e8oksHvJW41/', 'WQSuuujS', '8j+rU+kdOVcTKlNdH+g0Iog0TEg2JW', 'emoGWP0SEG', 'h8kgWOaCW6G', 'W5BdRvlcPCkz', 'r33dVmodWQq', 'CbXfWQ4/', 'W7KgW4FcMmo5', 'CmoXvapcPa', 'W5FcU8oiW4ej', 'W4WUWO3cL1C', 'W6qgWPRcHmoN', 'FMWs', 'W7hdQCktWPer', 'xxBdS8okWRi', 'W78LESkYba', 'W41riridDamPl8oylSo+W7a', 'WOVcN0mC', 'xctcPmkzEq', 'CJZdQSoKeG', 'DX3dUwig', 'pmoqW6uGW4e', 'ASkOs8oYWRS', 'W68AWO1Wwa', 'W6vvrmoosG', 'rmkCWPD3W6m', 'W5z0ECowcq', 'W5ddJgxcJq', 'jJOA', 'fCoNW7yJfW', 'WPXsBJBcUW', 'ymkTjwa', 'W7arW4BcICoD', 'aGWM', 'd8kbW7aDW44', 'wmkaCCoSW7a', 'oJFcTaHO', 'WRRdJM49WQy', 'W4Xwi0jw', 'cmkfgLxcOW', 'WPJdSgNdKa', 'lcddULif', 'gmoKW55+', 'pSkQW7xdSG', 'a8kWW6vLha', 'W60zi0zs', 'pdxdTYlcOW', 'WP/dMrvltq', 'xuHN', 'WOpcGIWIWPK', '4Bwi4BE5W6dXGygM4Ogn8lYJPq', 'zw7dTmo6rG', 'tMb8bmk6', 'WQHvuWNcLq', 'bmkbW7iaW4u', 'yhSh', 'hcZdQSoDWR0', 'kCkQW6JdTx8', 'ncddRq', 'WRqWWQD2tW', 'W4RdNN7cL8k2', 'tCk4prtdTq', 'qmovkq', 'W6exW4W', 'kCoCW4KBW7K', 'raVcJ8k/FG', 'qSo4cSkxza', 'sNddS8oaWQq', 'ic7dVYe', 'WP1cWR3cQt4', 'oSkxW44BW6G', 'WPRcUtBcNmoS', 'WQ9su0BdUq', 'WRrqdwNdIa', 'F3WpW7rv', 'WQSHv0f5', 'CuWxW6C/', 'FmoFj8k0BW', 'l8koCSkUAG', 'W70+pmo1', 'y3ldU8o5WOS', 'W459pCkcba', 'FcFcJ8opba', 'WP/dUhZdNq', 'W7xdNsjOCa', 'Bh3cUGbX', 'WO0VzMP9', 'WQiJrJOx', 'uveEW7Hl', 'e8kxWRbcaW', 'v8kVWQ1IfW', 'WP7cRef7bW', 'WQxcJd4zWQK', 'WQiabbC', 'WORcJYz6W5W', 'WRXlW5hdGmo0', 'WR7cKJ8xWPC', 'W6uXWQPTtG', 'aLHTWRC', 'nu7cUM0k', 'iMuJgmo+', 'eCkhWPdcNeC', 'aWSXWRD0', 'g8oSW5nY', 'oYddP1u', 'gmkrWPCvW4S', 'iSkxW5Gm', 'WRBdQCojW5Gt', 'q8o2W7HGqW', 'W5q9jgrq', 'xhBdS8okWRa', 'W5RcJZPOW4G', 'W4KNpmoPuq', 'C2ahW6rx', 'WQ/dHx5WW7a', 'b8ouW4vhWOa', 'WRrZrmkkW6y', 'EmkKrmo/W7O', 'WPBdUgBdMmkY', 'W4BdTfqqgG', 'W4i2wKRdOa', 'C3BcGsZdJW', 'WRhcIKzSlq', 'W5G3xwPY', 'wCkKWQbQhW', 'W78xW6dcK8oD', 'i8ofwZe', 'u8kEDtVdNG', 'WQVcOCoiW5ab', 'h8kDWQSDW4m', 'WQjKcmorWQu', 'WOPTAtBcOW', 'WQxcIsSeWPq', 'm1CAkCo6', 'WPBcOG0NWRS', 'C2pcGYhdTG', 'ywaFW61C', 'wCoaAgdcNW', 'ASofW5rBWOu', 'W67cN3b0W7K', 'mL0BWOWbBCohW5nu', 'ncBcR8k7vG', 'yCoovJ57', 'W791hmkkWRa', 'WQzLtSkhW6G', 'o2OeW60u', 'W6BdUuSAqq', 'W6aqW6ZcHCoB', 'W7mod1ddSa', 'vmotmsO', 'WRDLW7yIxG', 'jmosWP5yW7m', 'u1b0WQv8yCoMsrldNfhcU8kx', 'iCklWPPkbq', 'W55wFt3cOa', 'BbLhWQmO', 'g8oekJtcKG', '8l2WMUkcUpgdGkZdLEg1TUg3HUg3IW', 'eCoLW74bW6u', 'W6tcNIC', 'txBcNdVdOW', 'WQBcOYO6W7S', 'zrNdRW', 'n2BcGCkszG', 'WPJcThSUyq', 'bq4IWRD0', 'W5XKWRFcLCke', 'jSoEW5DqWPi', 'WQedbuldVa', 'W7mKg8oDWRnGW4TQWPtcTmo0cqe', 'W55ZWPhcUSkG', 'l8kqfwG', 'WQ9DdKpdLCkhW7q', 'oSkDa2hcKW', 'bmosWOfzWQ0', 'wSoskYW', 'rxDRWRL3', 'fCkZWQK', 'oCkDW6xdIuC', 'W7v0WR/cVSkE', '4Bse4BwS4BsKW6FWRAgc4Ok58lAIUa', 'whRdUSoyWQi', 'E8oqhX7dMq', 'm8opxISV', 'W6rLWRRdJYi', 'b8oFWPv2W7q', 'W5e9nmopBW', 'WQKubu3dRG', 't2FdQ8oD', 'WQ1/WRdcPa', 'nCocsIu5', 'WP4nFea', 'W4D5eWtdQa', 'W4PpWPhdUs4', 'dqNcTwLI', 'igFcJsFdPG', 'W6ZcRCoUW54i', 'WRRdHYnSyG', 'W40xWR/cGh8', 'bSkyW5vGWQC', 'lCkrWQfPfW', 'r8kCWPaXW6S', 'W6FcJYP0W6i', 'jmoWE2NdNG', 'omkuWPXskq', 'ymoxpCkSBG', 'DSouWQtcKhG', 'a8oWW6ajW4e', 'W5L1WOdcRq', 'WOHu8kYtIHC9', 'WP3dRrPgDW', 'W57cHwtcL8k7', 'W64DW4lcN8o7', 'W5bSFmomwW', 'WQKQWQLM', 'rZPWvmk2hxy4W5rUiq', 'WQxdIZC', 'WOpcGZqZWOm', 'ixRdS8oQcG', 'W6v2W77cK0S', 'WPlcUKbikq', 'W6RdRablsa', 'WQpcRGGxWO0', 'W6SMWQDUbW', 'DSomWOamW6y', 'WP7dH1fiWQu', 'hSkSWOpcQMa', 'uHn3WQ8C', 'gmkebq', 'WQa6W7BdSdG', 'lb/dO2if', 'nLuEW758', 'o2tcN8oohq', 'e2iUmSoN', 'eCkJWQfIuW', 'WPddULJcSCkC', 'WRenDMXF', 'WRxdH05jW7S', 'cmo2WP1LpW', 'WQavqxbs', 'W4dcIduUWR0', 'aW0WW7KM', 'kCkBW6pdQuy', 'k3JcM8klaW', 'kCopwYOs', 'WQ8nFbib', 'WRHOWRZcUt8', 'gCkpWPqXW7m', 'WP/dSh7cNmk2', 'wuiJW748', 'WOX7DCozqa', 'W5b1WOdcR8k/', 'WQm+gSog', 'WPpcR3q', 'bSo8W6SAW78', 'DWLrWRm', 'W5mbW6xcLmoE', 'W5ldHv1Eua', 'yxjZWR0w', 'WPD8zSkLW4C', 'lqJdIthcIa', 'F8kkwYeT', 'WR0TAKnr', 'WOFcKhbKW4i', 'eSo0W6CFWQi', 'nCk6W6JdPri', 'pmoBWRFcIsm', 'W6SFW5a', 'DrhdVuiK', 'aCkIWP1Hoq', 'lMxcNSoktq', 'kMlcNSokwG', 'W4jWBJFdVW', 'WRjKra', 'yCodWPaBWRC', 'mwRdRbS/', 'W55Kpd3cPa', 'o8krWQ7cNum', 'W77dUqjIwq', 'WQ/cNZDYWRe', 'cmopW4fHW6m', 'nqGrW796', 'tIO3W6q', 'zwhdJ3BcOG', 'h8k1W4tdIeq', 'W5VdVwhdIG', 'W6HjWPxcJmki', 'W78lW6BcVmo6', 'jCkxW44CW4O', 'WPX2aLpdPa', 'WQLKc8o6tsazW6S', 'W43cTHOjWR0', 'uuChW4v7', 'f3aTqCo/', 'W5u8q0ddIG', 'WRGRWRZdPIa', 'WOaHxMDZ', 'EqRdHKqG', 'BJpdMMCg', 'BSkqBmo6BW', 'fSo6W6ezW6K', 'W6GoWRBcS20', 'n8kQW7ldUv0', 'eCo4W6S', 'b8kAWPWXW6y', 'fColldBdLa', 'W6nrgva', 'xh7cSSoAWQm', 'W6vxuSoSAW', 'WOzNdvddRq', 'W4TxvmoFyq', 'FZhdTLKS', 'WRNdJZ81W7q', 'W6zeiKrF', 'wSoqW5W/W4m', 'tCkcc1VcOa', 'kmohW6KgW4m', 'WRyGWQzMzW', 'WPNcKJSVWOa', 'p8orW7Pzha', 'u8oMW5j6Fq', 'W4FcGWyEW7e', 'oZNdTcpcNq', 'WPm0EK5+', 'W4fIWR/dGcC', 'gCkqWO02W6m', 'fCoKW5n4nq', 'iJHBW6ij', 'WP3cGZ4+WQ8', 'W6fYWQtcUSkf', 'CW/cPwum', 'u8kBW41QW6i', '4BE+4BsippcPOQNIGyxWRPo8WQy', 'kYddRei', 'DHPWWQKn', 'cCoTW5r4nW', 'kCkaWRtcIW', 'cwPGWQWZ', 'xSk7WQebW6u', '4BEL4Bsbpog1Gog3HG', 'zCo8yYFcGG', 'DCoCFI7cRW', 'fCkYWQW', 'W4P7WPJcL2K', 'vHFdVfGZ', 'CCoLntddKG', 'bCoeDM8', 'WPv8jCkahW', 'W4TQEmoE', 'WOBcM1a', 'k8kBWQ7cJwS', 'ymoQycFcJa', 'C8kKySoXW7a', 'cCkFhXtdUG', 'WQ3dUu8zrq', 'i37cISoeea', 'lSoEW5HaWQa', 'zSk1lNdcHa', 'WOVcIbOmW7W', 'DgtcNbhdUa', 'WRPKWR3dIW4', 'kZ3dQJpcUq', 'o8k9W6/dSb8', 'WRdcR8kFW5me', 'fdCrW5O9', 'ESoLg8kZ', 'W73cU8ob', 'WPH5su3dUG', 'W5VdJx7cISkG', 'CSkIsCo+W6C', 'W5/cTa1q', 'WPZcIt0pWPa', 'rhyOWRKU', 'WRjqFaSx', 'uvtcVrRdIW', 'gGVdGbyB', 'a8ktFgJcHW', 'WPRdQxJdKmoH', 'WRTdWOFcUSoDWRiLWRlcLG', 'W77cQmobW4qa', 'WRxcQHbcwW', 'WRDYWQdcTrq', 'WO17CSouaW', 'W6CHW5NcV8oM', 'gwiSj8oM', 'W7RcIti', 'pdxdRIVcTq', 'W5NdKgtcL8k2', 'W5ldNHrpba', 'W5a+W4ddGs4', 'WPWnzaql', 'W7jydKpdTW', 'AHNdSG', 'upc6G6BIGAdWVjkFWOdHTRhHTP8', 'agiKfmoQ', '4BwcYP7jGog3Us4', 'W5ldGNGbgq', 'aHbNWQLQ', 'ux3cGr3dUa', 'W7TECHbd', 'zmovkW', 'WQ5ktW8', 'W4zeDK1d', 'W4P1FmoFsW', 'WOBcKW4', 'u8ookZW', 'W5r5eWtdUa', 'hSkEWPuO', 'WPHLWP3cQq', 'hIpdUMuA', 'WRJcMdO3WQG'];
  _0x163a = function () {
    return _0xe6a6b;
  };
  return _0x163a();
}
function _0x216253(_0x5c9297, _0x21762c, _0x2f76bd, _0x59b9d7, _0x33544e) {
  return _0x4254(_0x5c9297 + 0x316, _0x2f76bd);
}
function _0x22ee42(_0x228abb, _0x49c03c, _0x4c1ac3, _0x596ae5, _0x16861c) {
  return _0x4254(_0x4c1ac3 + 0xe5, _0x49c03c);
}
if (config.COMMAND_TYPE === "button") {
  const _0x4d8269 = {
    pattern: "allsocial",
    desc: "Download media from various social platforms.",
    category: "download",
    filename: __filename,
    use: "<url>"
  };
  cmd(_0x4d8269, async (_0x37a5db, _0x2e54eb, _0x166e91, {
    from: _0x1032a1,
    prefix: _0x4cd591,
    l: _0x421593,
    quoted: _0x21490e,
    body: _0x25cece,
    isCmd: _0x5ce3fd,
    command: _0x382e51,
    args: _0x23f64c,
    q: _0x541266,
    isGroup: _0x1c7d6c,
    sender: _0xc11b7b,
    senderNumber: _0x2789eb,
    botNumber2: _0x305b8f,
    botNumber: _0x3382e7,
    pushname: _0x3c5719,
    isMe: _0x6f80ae,
    isOwner: _0x276138,
    groupMetadata: _0x449621,
    groupName: _0x2d3b71,
    participants: _0x44d3a7,
    groupAdmins: _0x51e573,
    isBotAdmins: _0x2a23ad,
    isAdmins: _0x1f8f33,
    reply: _0xb960fd
  }) => {
    try {
      if (!_0x541266) {
        return await _0xb960fd("*_Please provide a URL!_*");
      }
      const _0x391c39 = "https://api.maher-zubair.tech/download/alldownload2?url=" + encodeURIComponent(_0x541266);
      const _0x3b4dc9 = await fetch(_0x391c39);
      if (!_0x3b4dc9.ok) {
        return await _0xb960fd("*_Error: " + _0x3b4dc9.status + " " + _0x3b4dc9.statusText + '_*');
      }
      const _0x2c32f8 = await _0x3b4dc9.json();
      const _0x465cb0 = _0x2c32f8.result;
      if (!_0x465cb0 || !_0x465cb0.medias || !_0x465cb0.medias.length) {
        return await _0xb960fd("*_No media found!_*");
      }
      const {
        title: _0x5af7aa,
        thumbnail: _0x49de05,
        medias: _0x3c7829
      } = _0x465cb0;
      const _0xb76342 = "*Title:* " + _0x5af7aa + "\n\n*Source:* " + _0x3c7829[0].source;
      await _0x37a5db.sendFromUrl(_0x1032a1, _0x49de05, _0xb76342, _0x166e91, {}, "image");
      for (const _0x54106f of _0x3c7829) {
        const {
          url: _0x5cff2a,
          formattedSize: _0x2bebae,
          quality: _0x25ffd2,
          extension: _0x594114
        } = _0x54106f;
        const _0x1ac880 = "*Quality:* " + _0x25ffd2 + "\n*Size:* " + _0x2bebae + "\n*Extension:* " + _0x594114;
        await _0x37a5db.sendFromUrl(_0x1032a1, _0x5cff2a, _0x1ac880, _0x166e91, {}, "video");
      }
    } catch (_0x1befe1) {
      _0xb960fd(_0x1befe1 + "\n\ncommand: allsocial", _0x1befe1);
    }
  });
  const _0x4b55eb = {
    pattern: "soundcloud",
    react: '📱',
    alias: ["song2", "scdl"],
    desc: "It downloads songs from soundcloud.",
    category: "download",
    use: ".soundcloud lelena",
    filename: __filename
  };
  cmd(_0x4b55eb, async (_0x401454, _0x56835c, _0x417141, {
    from: _0x16a947,
    prefix: _0x22730a,
    l: _0x3b2768,
    quoted: _0x27e30d,
    body: _0x2641bb,
    isCmd: _0x359ebc,
    command: _0x2e99a4,
    args: _0x4e0d8f,
    q: _0xe16a75,
    isGroup: _0x55282b,
    sender: _0x4eccea,
    senderNumber: _0x1c8e86,
    botNumber2: _0x4f832d,
    botNumber: _0x4a32f0,
    pushname: _0x441b24,
    isMe: _0x43572a,
    isOwner: _0x5d51a5,
    groupMetadata: _0x3eae65,
    groupName: _0x816236,
    participants: _0x305596,
    groupAdmins: _0x219927,
    isBotAdmins: _0x2e073f,
    isAdmins: _0x4050be,
    reply: _0x752cfd
  }) => {
    try {
      const _0x524d31 = {
        text: "```Please write a few words!```"
      };
      const _0x3f1598 = {
        quoted: _0x56835c
      };
      if (!_0xe16a75) {
        return await _0x401454.sendMessage(_0x16a947, _0x524d31, _0x3f1598);
      }
      const _0x1c1b88 = await ssearch(_0xe16a75);
      const _0x9fd477 = _0x1c1b88.result;
      const _0xceb79f = {
        text: "*I couldn't find anything :(*"
      };
      const _0x24e06e = {
        quoted: _0x56835c
      };
      if (_0x9fd477.length < 1) {
        return await _0x401454.sendMessage(_0x16a947, _0xceb79f, _0x24e06e);
      }
      var _0x250463 = [];
      for (var _0xc871a7 = 0; _0xc871a7 < _0x9fd477.length; _0xc871a7++) {
        if (_0x9fd477[_0xc871a7].thumb && !_0x9fd477[_0xc871a7].views.includes("Follow")) {
          _0x250463.push({
            'rows': [{
              'title': _0x9fd477[_0xc871a7].title,
              'description': _0x9fd477[_0xc871a7].artist + " | " + _0x9fd477[_0xc871a7].views + " | " + _0x9fd477[_0xc871a7].release + " | " + _0x9fd477[_0xc871a7].timestamp,
              'id': _0x22730a + "selectaud2 " + _0x9fd477[_0xc871a7].url
            }]
          });
        }
      }
      let _0x477eef = [{
        'name': "cta_url",
        'buttonParamsJson': JSON.stringify({
          'display_text': "Join Our Channel",
          'url': "https://whatsapp.com/channel/0029VaNRcHSJP2199iMQ4W0l",
          'merchant_url': "https://whatsapp.com/channel/0029VaNRcHSJP2199iMQ4W0l"
        })
      }, {
        'name': "single_select",
        'buttonParamsJson': JSON.stringify({
          'title': "Result from m.soundcloud.com 📲",
          'sections': _0x250463
        })
      }];
      let _0x4097e0 = "┌───[ powered by talkdrove ]\n\n   *SOUNDCLOUD DOWNLOADER*\n\n*📱 Entered Name:* " + _0xe16a75;
      const _0x3d14ac = {
        image: "https://cdn.freelogovectors.net/wp-content/uploads/2023/05/soundcloud-logo-freelogovectors.net_.png",
        header: '',
        footer: config.FOOTER,
        body: _0x4097e0
      };
      const _0x3a0b98 = {
        quoted: _0x56835c
      };
      return await _0x401454.sendButtonMessage(_0x16a947, _0x477eef, _0x417141, _0x3d14ac, _0x3a0b98);
    } catch (_0x2cc2c0) {
      _0x752cfd("*ERROR !!*");
      _0x3b2768(_0x2cc2c0);
    }
  });
  const _0x4802fa = {
    alias: ["selectaud2"],
    filename: __filename
  };
  cmd(_0x4802fa, async (_0xbbd6d3, _0x2b8377, _0x5d9ec0, {
    from: _0x318c7d,
    l: _0x2f35be,
    quoted: _0x45b86a,
    prefix: _0x5b57c4,
    body: _0x2f977d,
    isCmd: _0x333ea4,
    command: _0x1129e4,
    args: _0x2fbf28,
    q: _0x5ada0f,
    isGroup: _0xe8283c,
    sender: _0x3f9743,
    senderNumber: _0x566b0d,
    botNumber2: _0x120d9f,
    botNumber: _0x533496,
    pushname: _0x435ab0,
    isMe: _0x51564c,
    isOwner: _0x531765,
    groupMetadata: _0x1ca59a,
    groupName: _0x2504e4,
    participants: _0x205177,
    groupAdmins: _0x2b6e52,
    isBotAdmins: _0x2723e7,
    isAdmins: _0x5421f2,
    reply: _0x591616
  }) => {
    try {
      let _0x119fbc = [{
        'name': "quick_reply",
        'buttonParamsJson': JSON.stringify({
          'display_text': "DOCUMENT SONG",
          'id': _0x5b57c4 + "sounddoc " + _0x5ada0f
        })
      }, {
        'name': "quick_reply",
        'buttonParamsJson': JSON.stringify({
          'display_text': "AUDIO SONG",
          'id': _0x5b57c4 + "soundaud " + _0x5ada0f
        })
      }];
      const _0x4cfa5e = {
        image: "https://cdn.freelogovectors.net/wp-content/uploads/2023/05/soundcloud-logo-freelogovectors.net_.png",
        header: '',
        footer: config.FOOTER,
        body: "powered by talkdrove\n  *SELECT SONG TYPE*"
      };
      const _0x29d64e = {
        quoted: _0x2b8377
      };
      return await _0xbbd6d3.sendButtonMessage(_0x318c7d, _0x119fbc, _0x5d9ec0, _0x4cfa5e, _0x29d64e);
    } catch (_0x470451) {
      _0x591616("*I couldn't find anything :(*");
      _0x2f35be(_0x470451);
    }
  });
  const _0x25e7c6 = {
    pattern: "sounddoc",
    dontAddCommandList: true,
    filename: __filename
  };
  cmd(_0x25e7c6, async (_0x5db6f1, _0x450780, _0x15e132, {
    from: _0x5e4e12,
    l: _0x3b6c17,
    quoted: _0x144202,
    body: _0x11784a,
    isCmd: _0x3221f6,
    command: _0x54d678,
    args: _0x3c6695,
    q: _0x2a77d9,
    isGroup: _0x3effb1,
    sender: _0x2e47da,
    senderNumber: _0x277e68,
    botNumber2: _0x2d92df,
    botNumber: _0x1d6f83,
    pushname: _0x339142,
    isMe: _0x2dbd59,
    isOwner: _0x47b43,
    groupMetadata: _0xe269a6,
    groupName: _0x3e2db0,
    participants: _0x4c35d6,
    groupAdmins: _0x355ef6,
    isBotAdmins: _0x572852,
    isAdmins: _0x40410f,
    reply: _0x721ca2
  }) => {
    try {
      const _0x3d52c5 = {
        text: '📥',
        key: _0x450780.key
      };
      const _0x2669bc = {
        react: _0x3d52c5
      };
      await _0x5db6f1.sendMessage(_0x5e4e12, _0x2669bc);
      const _0x5112f = {
        text: "*Need link...*"
      };
      const _0x2a88e7 = {
        quoted: _0x450780
      };
      if (!_0x2a77d9) {
        return await _0x5db6f1.sendMessage(_0x5e4e12, _0x5112f, _0x2a88e7);
      }
      const _0x125e93 = await soundcloud(_0x2a77d9);
      let _0x381f12 = "*📚 Name :* " + _0x125e93.judul + "\n*📺 Down Count :* " + _0x125e93.download_count;
      const _0x4360c2 = {
        url: _0x125e93.thumb
      };
      const _0x48f093 = {
        image: _0x4360c2,
        caption: _0x381f12
      };
      const _0x395f55 = {
        quoted: _0x450780
      };
      await _0x5db6f1.sendMessage(_0x5e4e12, _0x48f093, _0x395f55);
      const _0x582b0e = {
        url: _0x125e93.link
      };
      const _0x1753a6 = {
        quoted: _0x450780
      };
      let _0x3de568 = await _0x5db6f1.sendMessage(_0x5e4e12, {
        'document': _0x582b0e,
        'mimetype': "audio/mpeg",
        'fileName': _0x125e93.judul + '.' + "mp3"
      }, _0x1753a6);
      const _0x5e8bed = {
        text: '📁',
        key: _0x3de568.key
      };
      const _0x41a64 = {
        react: _0x5e8bed
      };
      await _0x5db6f1.sendMessage(_0x5e4e12, _0x41a64);
      const _0x3bf9ef = {
        text: '✔',
        key: _0x450780.key
      };
      const _0x2af2c0 = {
        react: _0x3bf9ef
      };
      await _0x5db6f1.sendMessage(_0x5e4e12, _0x2af2c0);
    } catch (_0x5668b6) {
      _0x721ca2("*ERROR !!*");
      _0x3b6c17(_0x5668b6);
    }
  });
  const _0x4f19a8 = {
    pattern: "soundaud",
    dontAddCommandList: true,
    filename: __filename
  };
  cmd(_0x4f19a8, async (_0x59f0bf, _0x3d79ed, _0x25046a, {
    from: _0x19626d,
    l: _0x377181,
    quoted: _0x392fe4,
    body: _0x4e138a,
    isCmd: _0x3d178a,
    command: _0x1259b8,
    args: _0x394570,
    q: _0x33c58c,
    isGroup: _0x141bbb,
    sender: _0x310e74,
    senderNumber: _0x324e2e,
    botNumber2: _0x56035b,
    botNumber: _0x5cf782,
    pushname: _0x55011e,
    isMe: _0xd834ad,
    isOwner: _0x4ab7e9,
    groupMetadata: _0x46743f,
    groupName: _0x53018d,
    participants: _0x636242,
    groupAdmins: _0x454a3f,
    isBotAdmins: _0x26172a,
    isAdmins: _0x1f3f6d,
    reply: _0x4e3722
  }) => {
    try {
      const _0x255b81 = {
        text: '📥',
        key: _0x3d79ed.key
      };
      const _0x35cb51 = {
        react: _0x255b81
      };
      await _0x59f0bf.sendMessage(_0x19626d, _0x35cb51);
      const _0x18f1fd = {
        text: "*Need link...*"
      };
      const _0x5b4f84 = {
        quoted: _0x3d79ed
      };
      if (!_0x33c58c) {
        return await _0x59f0bf.sendMessage(_0x19626d, _0x18f1fd, _0x5b4f84);
      }
      const _0x462626 = await soundcloud(_0x33c58c);
      let _0x1cb0f0 = "*📚 Name :* " + _0x462626.judul + "\n*📺 Down Count :* " + _0x462626.download_count;
      const _0x576641 = {
        url: _0x462626.thumb
      };
      const _0x3b9eb6 = {
        image: _0x576641,
        caption: _0x1cb0f0
      };
      const _0x3ab86e = {
        quoted: _0x3d79ed
      };
      await _0x59f0bf.sendMessage(_0x19626d, _0x3b9eb6, _0x3ab86e);
      const _0x168ab2 = {
        url: _0x462626.link
      };
      const _0x14361f = {
        quoted: _0x3d79ed
      };
      let _0x15a9c5 = await _0x59f0bf.sendMessage(_0x19626d, {
        'audio': _0x168ab2,
        'mimetype': "audio/mpeg",
        'fileName': _0x462626.judul + '.' + "mp3"
      }, _0x14361f);
      const _0x296b15 = {
        text: '📁',
        key: _0x15a9c5.key
      };
      const _0x39de17 = {
        react: _0x296b15
      };
      await _0x59f0bf.sendMessage(_0x19626d, _0x39de17);
      const _0x17c00d = {
        text: '✔',
        key: _0x3d79ed.key
      };
      const _0x5dba4b = {
        react: _0x17c00d
      };
      await _0x59f0bf.sendMessage(_0x19626d, _0x5dba4b);
    } catch (_0x536cc6) {
      _0x4e3722("*ERROR !!*");
      _0x377181(_0x536cc6);
    }
  });
}