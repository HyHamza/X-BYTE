(function (_0x4a8bab, _0x29bae8) {
    const _0x4afb58 = _0x4a8bab();
    while (true) {
      try {
        const _0x2b32b6 = parseInt(_0x222d(743, 'rfGy')) / 1 * (-parseInt(_0x222d(305, 'MzEI')) / 2) + parseInt(_0x222d(919, 'XQVp')) / 3 + -parseInt(_0x222d(426, 'rJrS')) / 4 + parseInt(_0x222d(376, '9JrN')) / 5 * (-parseInt(_0x222d(1015, 'FnDv')) / 6) + parseInt(_0x222d(1212, 'pimj')) / 7 * (parseInt(_0x222d(450, '4*gF')) / 8) + -parseInt(_0x222d(658, 'pimj')) / 9 * (parseInt(_0x222d(766, 'rBBp')) / 10) + parseInt(_0x222d(235, 'XQVp')) / 11 * (parseInt(_0x222d(780, 'hBk!')) / 12);
        if (_0x2b32b6 === _0x29bae8) {
          break;
        } else {
          _0x4afb58.push(_0x4afb58.shift());
        }
      } catch (_0x254bc5) {
        _0x4afb58.push(_0x4afb58.shift());
      }
    }

  })(_0x31b1, 627195);
  function _0x222d(_0x4d6502, _0x4aa14b) {
    const _0x387ee0 = _0x31b1();
    _0x222d = function (_0x3292e5, _0x5390e4) {
      _0x3292e5 = _0x3292e5 - 158;
      let _0x2586be = _0x387ee0[_0x3292e5];
      if (_0x222d.GAeiqO === undefined) {
        var _0x7a5c12 = function (_0x1a9ba0) {
          let _0x25fd6c = '';
          let _0x4ee245 = '';
          let _0x371c5f = 0;
          let _0x4bf828;
          let _0xf4d997;
          for (let _0x5d0744 = 0; _0xf4d997 = _0x1a9ba0.charAt(_0x5d0744++); ~_0xf4d997 && (_0x4bf828 = _0x371c5f % 4 ? _0x4bf828 * 64 + _0xf4d997 : _0xf4d997, _0x371c5f++ % 4) ? _0x25fd6c += String.fromCharCode(255 & _0x4bf828 >> (-2 * _0x371c5f & 6)) : 0) {
            _0xf4d997 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/='.indexOf(_0xf4d997);
          }
          let _0x495bb9 = 0;
          for (let _0x39f651 = _0x25fd6c.length; _0x495bb9 < _0x39f651; _0x495bb9++) {
            _0x4ee245 += '%' + ('00' + _0x25fd6c.charCodeAt(_0x495bb9).toString(16)).slice(-2);
          }
          return decodeURIComponent(_0x4ee245);
        };
        const _0xce491b = function (_0x1c6b2f, _0x4c1f98) {
          let _0x12d6b7 = [];
          let _0x5ea278 = 0;
          let _0x4736d4;
          let _0x4447de = '';
          _0x1c6b2f = _0x7a5c12(_0x1c6b2f);
          let _0x478b08;
          for (_0x478b08 = 0; _0x478b08 < 256; _0x478b08++) {
            _0x12d6b7[_0x478b08] = _0x478b08;
          }
          for (_0x478b08 = 0; _0x478b08 < 256; _0x478b08++) {
            _0x5ea278 = (_0x5ea278 + _0x12d6b7[_0x478b08] + _0x4c1f98.charCodeAt(_0x478b08 % _0x4c1f98.length)) % 256;
            _0x4736d4 = _0x12d6b7[_0x478b08];
            _0x12d6b7[_0x478b08] = _0x12d6b7[_0x5ea278];
            _0x12d6b7[_0x5ea278] = _0x4736d4;
          }
          _0x478b08 = 0;
          _0x5ea278 = 0;
          for (let _0x3fb068 = 0; _0x3fb068 < _0x1c6b2f.length; _0x3fb068++) {
            _0x478b08 = (_0x478b08 + 1) % 256;
            _0x5ea278 = (_0x5ea278 + _0x12d6b7[_0x478b08]) % 256;
            _0x4736d4 = _0x12d6b7[_0x478b08];
            _0x12d6b7[_0x478b08] = _0x12d6b7[_0x5ea278];
            _0x12d6b7[_0x5ea278] = _0x4736d4;
            _0x4447de += String.fromCharCode(_0x1c6b2f.charCodeAt(_0x3fb068) ^ _0x12d6b7[(_0x12d6b7[_0x478b08] + _0x12d6b7[_0x5ea278]) % 256]);
          }
          return _0x4447de;
        };
        _0x222d.DjACae = _0xce491b;
        _0x4d6502 = arguments;
        _0x222d.GAeiqO = true;
      }
      const _0x536c34 = _0x387ee0[0];
      const _0x83faf7 = _0x3292e5 + _0x536c34;
      const _0x5d358a = _0x4d6502[_0x83faf7];
      if (!_0x5d358a) {
        if (_0x222d.kfCxbC === undefined) {
          _0x222d.kfCxbC = true;
        }
        _0x2586be = _0x222d.DjACae(_0x2586be, _0x5390e4);
        _0x4d6502[_0x83faf7] = _0x2586be;
      } else {
        _0x2586be = _0x5d358a;
      }
      return _0x2586be;
    };
    return _0x222d(_0x4d6502, _0x4aa14b);
  }
  function _0x31b1() {
    const _0x2ae861 = ['FWxdJCkeW5i', 'W5ldVmoAWPjD', 'nJdcI23dIW', '8kUaNUkdOVc1OzfJ772e77Yf776H', '77YC77+577YLFo+9HW', 'hSknxrq', 'ASoOWRtdTf4', 'WRddRGBdJCoh', 'W5FcKmkuW7Op', 'fmoEpSo8W6G', 'sq48rfy', 'BmoHWQlcUXG', 'W4JdUMNcSxa', 'ohtdIG', 'c2q2W6z7', 'bqFcJwVdIW', 'W4OMWPNcRq4', 'w8ksESkJW6S', 'WRLRrI/dUG', 'vGm5W7DA', 'fCktW7xdHaK', 'kCk0W7/cSqquW5xdOGitWQi', 'rSoHW60X', 'sSktWQRdUSkp', 'WOe2B8oRW4y', 'WQ3dSmkny8o5', 'xmk5kCkTW58', 'dCo0W4K', 'dcClxMi', 'W6xdQCkZ', 'W4/cPmk0WOy', 'eSoytfhcMa', 'xmk4gCkHW4a', 'WQNcHaTMW7W', 'WRhcS8o/p8k0oL3cNSk2qSos', 'amofWP7dHG', 'WRGPlW', '8j+aPUkbTVc+ORqXrpcwSidINy4', 'WRtdQHD3W54', 'W4BcL8oLWRhdMW', 'WQNdRCkBDCoT', 'WRJdT8kCEmoV', 'WOpdU8k3W5BcTW', 'WP3dJCk6W5a', 'p2pdH8knW7m', 'gLpdGCkgW44', 'FmoIWQNdTxm', '4BEbYjbwlSka', 'A8kqbCkUW4e', 'aCoBwXi', '8lo6VFc2U68p8jcyI/cBIAe', 'WPdWRQcUW7K/xG', 'CCkMDJq0', 'jbmHa8kO', 'WOddN8kX', '4lAP4lwNsSkwW5C', 'imomFX7dVq', 'W53cM8oWgHe', 'mJ4jvua', 'wSk8a8kWWPW', 'yWRdM8oxW5O', 'WR3dTt7cT3C', 'd8kRWRn4W54', 'qCkloCkfW5G', '4lAP4lwNsSklW70', 'WQmNkGWy', 'fSobwGm', '4Pwq4Pw34PsG', 'hrRcVeZdVa', 'Z53WROAssuBXHOE+', 'bW4jk8kz', 'WPWJy8o2', 'WPJcIWNcPdW', 'cCkeW4i', 'WPWVB8oUW4W', '77YL776J77Yie/cRGjFIGylWNigN', 'm1ZcTgRdRq', 'FNtWPP274OcW4OkNZRRoOC24ZBZpKa', 'evJcP8k6CG', 'WQxdP1y0W64', 'WQyJoXWa', 'lSkYWOrxW7m', '4OE88lM3Qmku8yYxTFc2HyW', 'fXzfySkP', 'WQhcMbnbW7y', 'DW/dMCoZoq', 'mbO1dmk/', 'CmkbW57cJdG', 'WO3dVCk9W4dcHq', 'umkqW6tcRY4', '8kA6VFcwUlJWPQUZ8js6Nem', '4PsH4PsH4Pwq4PEQna', 'WRFdHMFdRXq', '8ywqRUkaLVc/Sjj6c8ofWPy', 'WPZdU8kDW5FcNW', 'WR7dU8kjD8o+', 'WPONoWHm', 'WQpcLq97W7O', 'WQxcGWW', 'orpcJSopWO8', '8yEgRVgjP7RXJjE0WO3WNPEx', 'DmkkW4K', 'Cg0PDN0', '4Pwj4Pwr4PwA4PsE4Ps3', 'WPWVcY8U', 'rd0AW6LU', '8k2TP+kaTEkcQmY2Zi7mQC62Z53mIVcDHAC', 'uSkIyIu', 'W4lcNLdcGxa', 'smo9suzX', 'CSoXsey9', 'erRcRKVdQW', 'W4tcV8o+WPNdQq', 'W4NcSComWQbi', '8loNPVcAHOlIHilIHQRWQ7sK', '8jgYKUkdR/c8OyfeAmkt8yMwOq', 'W6JcRNZcUNq', 'W7RdNL8', 'WR/dPt7cQG', 'cuFcMmk7DW', 'WRhdKWtcSGu', 'WOFdO0/cLSoM', 'W5lcQMNcOw8', 'n1dcU2u', '8yIyHFcVMk3WPPQG8lciLSkm', 'pvdcUwVdPG', 'WRNcTSkG4OsYkG', 'W7dWNioaD8oyWPa', 'WO/dN8k7W78', 'aY8Ub8kU', 'imolW5pcN8k4', 'j8kxxvWH', 'W7VcLYpcLCo6', 'W4JcOSoP', '776P776477+Ml+++Ra', 'r/cESAVdJSkTWQa', 'kCkQW6VdGa', 'W6tWVQcA4OkS8lEZUmk88kMAN/cTMRK', '8kc6G/cOQ4dXJlUzW67WQlMl', 'WOCods0', 'WR5SEJy', '8yIlSpcEMRNWUAU+8jw5Uha', 'a8ohsaxdKW', 'DmkpW4BdLmoO', 'W63dMviIWR4', 'tmoLAmo+kW', 'bFc7P6lVUOL6t2u', 'WO1aWRBdMWW', '8yEBJVcBQihcICoEaq', 'W5ldUSkUxmof', 'oKdcINRdRq', 'wq/dMW', 'W5qIWPRcQG', 'W6VcOSoHoHe', 'W4OYWP7cSq', 'WQNdQSoiwSoV', 'WRBcUCo3pCooi0pcJCkfua', 'W6JcR8oTWR9A', 'vSkuyCoBW7u', '8yY8IE+5GG', '4OsKWR7HT7pjVUg2Kq', 'WP7dHs9XW5G', 'W43cLSohgrK', 'upcxUBtdVVcyMiZXIiUK', '4PEf4PAg4PwZ4PAG4PAJ', 'r8kUzt8h', '8k+2IVghLPxWKQEr8jwvPmo0', 'cCoMWQFdUSot', 'WQP4Ft8', 'ZkNWL6AlbrtWP7sq', 'ovBcSxC', 'W4NcKmoaWRrI', 'WQG1D8kVW4O', 'W6/cJCoLuCoT', 'nahcNmklWQW', 'Dmo9t180', 'p1ZcPM3dUG', 'WQVdStNcOW', 'WRVdNhVcIG', 'W7VdIwtdLSo1', 'vmk/yxXt', 'a8kSWRq', 'lmooW4pcSCkl', 'zSo/wCkPoW', 'W5RcL8oQeJK', 'W57cRw4', 'ibdcV8oXWPG', 'WR3dVmkBD8oh', 'WOncWRFdGXS', 'WQS8W64', '4Pwl4PwF4PEP4PwX4Ps+', 'jSojWPVdGmo2', 'WPOJAmo3W4u', 'dcqstvO', 'ufuItq', 'lCk5fH57', 'pK7cPG', 'mHFcM8ooWO0', 'WQaVACo3WOK', 'W5ZcT27cPMu', 'd8ozsaZdLW', 'W5ZcV2K', 'b8oAtbZdGq', 'dmkBW5hdRJq', 'W4dcGCoW', 'WRpcNq1UW6a', 'WOWNB8oJ', 'W6NdP8kMAmoN', 'vSoOWRddSG', 'i0tdLmkRW40', 'WOmDW4hcQ8oU', '776377+k776RbE++Oq', 'WQqNpb0j', 'WOxdN8k/W6/dMW', 'WPtdSmkzF8og', '8kU1OVgaLPxWMjsE8yIgMmkm', 'kwpdKSkpW64', 'mfZcRa', 'D8kpWPpdHSkk', 'rvCI', 'WPHQWQddVrW', 'aCkcW5BdTZC', 'WR9EWOFdNJK', 'WR8Jmq', 'u8kjWPy', 'WOhdNg/cKCkZ', 'W5dWNigM4OgA8lQrGSoW8lYlRVghUly', '8j2xL/ctPi9Rvw8', 'WOVdMSonWQvD', 'iHpcGCopWQC', 'vrW/W79x', 'amoaxmoBW5b2rN0', '8lwDQ++6IW', 'W43dR8k0FmoJ', 'ld81A3C', 'eCoRW4tcTCkR', '8yYuJFc4PRdWTPwg8k+LKUkeJq', 'urldJSoFW7K', 'W7xdVSkZymoS', 'W5/cGCoaWRvy', 'lmkpWORdMSo1', 'W4RcO8kR', 'W4dcTSoKWR99', 'W45K8lQNRmkmuW', 'otVcNa', 'WRWuW4xcL8ov', 'WRLLlHldUG', '8lUlT/cLMB3WMPQC8jYlQSo8', 'xCk4AHOD', 'svmL', 'W57cLmoAWRe', 'WQBcLJNcOH4', 'jWBcGIDT', 'gCoO8lYpNEkcSokaIC+4ZA7pQ866ZRO', 'zdOvW6j4', 'hgRcG17dIG', 'hmoNW5hcT8kV', 'yJWAW7C', 'e8omjmoVWQe', '8yEyI/cBQR7WT4I58jERMCkw', 'fCkkW5hdSZ4', 'W63cNCoKqCok', 'b1/dVaNcSW', 'qCkyFmoFW6S', 'WRZcMJJcOHW', 'FCk6W7JcGWy', 'WOdcMb/cLJy', 'pmk0dKzf', 'fSkoW4VdOXy', 'WPWPtSoYW5K', 'yCkhW63cHXK', 'WO3dT8kGW5FcTG', '4PAO4PEZ4PAf4Pw34Pw1', 'grGqDh8', 'A8o2t8oLka', 'pSopWQhdIua', 'WQxcHWXUW7q', 'ySkYW5ZcRr0', 'iSk+eCkRDW', 'wqZdM8kBW7G', 'WRVdN2m', 'vHSdW6H5', '4Pwm4Psh4PAN4PEV4PAg', 'WPxcGSopW75c', 'emoJW4tcTSkR', 'wCkIAJC', 'zCkErHa6', 'WOJdV8k2', 'W4/cS2NcPgu', '8jo3GVgfT4tXG7wYqVcZH6m', 'zCkZrtSC', 'WRhdMhJcMa', 'WP/cPCkOW45N', 'W5JcU23cVgK', 'baSwkG', 'W4OlWQ7cOYK', 'uCoZb8kJW5O', 'h8oCp8kvWQO', 'uKNcGSktWQ4', 'CmkdW7ZcKaq', 'WRpcRmkGW7O', 'vCkiWPS', 'lYBcMbXE', 'C8oOWR4', 'DHtdUcpcPq', 'W77cGLVcM04', 'oHSsmq', 'W5/cSYhdLmk+', 'hKVdICkcW7q', 'iw/dImkf', 'zmkaW4pIHz3cUa', 'WQNcMWW', 'umkuDZKF', 'W6pdR8kyECoN', 'WPZdLCknvCoL', 'q8oBDN4q', 'WRbTW4ddTey', 'Fmk1FEkwJEkuJW', 'amkzWOJdVs4', 'W5tcKmozWQm', 'wCksW4ldNmko', 'jComBmoQpW', 'WQFdNg3cMSoN', 'lCk5fH58', 'Ad4pW65G', 'FLtILyxILylINP8', 'W6NdHXnr', 'x8knWPe', 'WOpdN8kPW7JcKW', 'wfldSaxcSW', 'yYJcICkcW64', 'uCkdE8oBW6W', '8lo0N/c2Tlyp8jcxKVcBH7K', 'hbSejSki', 'W7FdLXDkqW', 'CCoHveC0', 'W7xdJM3cL8oN', 'kZH7Cvm', 'vCk8bmkMW74', 'z8khW6/cJei', 'gmoNqmoI', 'jq7cNSo8WRK', 'W4i7W7VcRr/cU8kfW7KEWRy', 'W6ddS8o+', 'm8oyWQhdHau', 'hCkDqbGI', 'W5/cPSoMWOpcS8oeW7X8W4ZcOW', 'W4vRnSkVWOq', 'WRDSydpdMa', 'W7FdUSoEWOjK', 'jhxdKG', 'it8HE1m', 'tue/qxi', 'kSopWOFdGCoz', 'WQKVW6pcMmoe', 'vSkEFmomW4y', 'Bmo1t1u+', 'WRxcNI8', 'A8o3F8oPnW', 'A8oYsmoJdG', 'abmVjSkM', 'W5pcVmkQ8jAfLU+5JokDPW', 'WQdcMJ7cUXC', 'W67dMwO', 'reu1hXq', 'WONcKmogba', 'ASoNvf0', 'owpdNSkA', 'WPFcI8k0WQ8', 'dmoJW4BcUSkG', 'eCovsW7dHG', 'e1BdLmk5Fq', 'r8kOCYKe', 'W6FcTSoZWRv/', 'WQuPECoRW4u', 'WQXFwHddGW', 'a8odwG', 'reuJrfa', 'WPNdTsxcQ3G', 'W6tcK8oTgdO', 'iIRcNabm', 'W5tdImkytmkD', 'W4VcK8oTbfO', 'WOxcHX5HW7i', 'W5/cKmkoWR5k', 'k2/dISklW6K', 'WRxdU8kkWO9G', 'l3FcTgpdRq', 'eSolomky', 'W4JcN8oH', 'WQJdU8kCDCoJ', '4PEm4Pwzz8oImq', 'WPtdQXFdGmor', 'm0/cKCkzwq', 'WQ3dMXTQW6e', 'qu00', 'gd0FxNm', 'fG7cS07dMW', 'W7ldU8oV', 'eCkcW5hdQZ4', 'wrldHmoiWR0', 'W5xcMg/cJuO', 'W4JcKmoDWQvd', 'cmoEpCozW7C', 'WQVdTt7cOwK', 'qSkeyCoq', 'WO8JBW', 'fvZcON0', 'WPKZDmo2W4W', 'xSkFWPhdRa', 'WOyNDSoN', 'WQCVW6pcLCon', 'ydOoW7qV', 'fepcH8k/na', 'WRddMMtdMCo9', 'W44IWO7cSuq', 'Fg3dMejZAMNdISkIra', 'W58WWP4', 'CSkm8lAFQ+kaK+kbVm+9ZzhmLm2LZBa', 'WOJdU8kNWPJdPa', 'WOZdPW5JW6m', 'W54MWPNcUa', 'WRDOlNFcRG', 'fCkcAJOC', 'WOqesSoVW6O', 'bSoOWP/dM8o+', 'jhBdKSkhW6G', 'W7xcV2RcUW', 'W7RWNigN8kQ9R+kdTpglJk3cN8k8sW', 'W4hcL8oLeHe', 'rSkvWQjMW4i', 'z8o4ESohhG', 'smkFWOpdRmko', 'WRJdMglcNCoF', 'W7hdLWfDEq', 'lsmOFLe', 'WPxcLSkAbCk/', 'e8koW7ldVI8', 'pcqRjrK', 'W4xdKmk4W7S', 'mmoqWQ/dRSko', 'jMpdNW', 'WP/dS8k0W5VcTq', '8joANvddOG', 'i3dcIWjw', 'aCkpW6BdQdy', 'WQxdObS7W5W', 'WO3dK8kKW7NcMa', 'W73dJmoVf8k7', 'WQBdOdNcQ3q', 'fCoRjhX5', '77+i776H77+YWPtVV6O', 'CSkpW6K', 'rvaqt1O', 'WPXUWR0', 'W73cKmoAW7bb', 'WQRdJq9nW60', 'WP3cNdNdTZW', 'WQ7cPdj+W5y', 'Z5pWNlEuD8k+4OES', 'tmoCuSoZaa', 'lCkoWPrDW7S', 'WQhdKhJcLCo2', 'WRGxdZaE', 'dSk+WQz1W5q', 'vSkuDSkcWQ0', 'FCkTWONdPeu', 'A8oOWRm', 'zx12mHS', 'reeLqa', 'W77cKmoDWRnD', 'ovdcNCk9FW', 'WQ8RW67dHSok', 'kGOCreO', 'upcxT6lXIRMe8kQkMpc0M7e', 'ZiBWU5EMWQzW4OwW', 'WPhXIBotW6HmW54', 'WR9JqY/dTW', 'WO8QW7/cICoj', 'WRmdW67cOSoF', 'm8oyWQBdHa', 'zmo1t1i', 'WRG1zX4n', 'WO7dHa7cIJS', 'WPRcHmofbCo+', 'E/cISlxcI8kPiG', 'WPZdOmk/', 'bmo7pgKXW7jaW5tcPZS', 'W7xdUmkR', 'w8k8gSk2W5S', 'W6BIMy3VU6C0W4q8', 'eq0elmkm', 'WRZdLg3cNSo2', 'W6dcGH5LW7O', 'W7tdO8kZy8oN', 'm8kjWOS', 'jSkzW4ZdPda', 'f8kuWOFdUmkj', 'WR0PoW', 'E8kwW7JcLb4', 'CISvW6nc', 'vCkRWOJdV8oJ', 'W63cKG5CAW', 'WQNcMr5OW7y', 'pLxcGSk0ta', 'sSkBWPBdU8kF', '8k+yNFcRQzhWKlI18jo5MpcyIOG', 'fHG1ff0', 'W5S1WPNcVa8', 'grRcULRdUa', 'W5aN4PUD77MyWRtcTq', 'WQpcLqTQW7q', 'vSkQDcGA', 'W6hcKpgnLORdLNW', 'peVcMmk7EG', 'bCogqaJdMq', 'W44OWRJcQrS', 'kuFcGa', 'd8kOWRm', '4PspW5rFbFc7OiC', '8lkRRSoN8yA5MVgiQ5VWTAQI', 'WQBdOZK', 'y8knW4tcMmk1', 'jHBcR0NdQG', 'DI8zW6j7', '8lg9G++4KG', 'f8olmSkUW6y', '8kkSPU+5Ma', 'W43cL8o3fqy', 'W5BcNmoaWRS', 'WOddV8k0', 'WQ3cP8oQiSkV', 'W53dGJjqBW', 'W7RcMCo+ra', 'WQ4CW5hcJSoF', '4Pwq4Pw34PEU4PAQ4PER', 'W7lcMvxcNK0', 'BWddPdNcSbbVWRVdTmountnT', 'r8kdFG', '4Ps54PEC4PwR4PEd4PAZ', 'WRdcLJNcTaa', 'WPWYwmooW74', '4PwN4PEA4PEg4Psq4PAW', 'W5hcKmox', 'yCo5xG', 'icqVB0u', 'mVc8GitcOwyj', 'WOtdRbpdL8oh', 'c8ovrW8', 'omkh8y6+UokdR+kcUm6lZO3nJS2pZ50', 'cSkCBrmc', '8y6xNUkhVFcyL4HPfq', 'WQpdM8kbW7xdPa', 'a8kOWRrWW5y', '4PEv4Pwh4Pwj4PwO4PwT', 'WPxdSCon4PsH4Psv', 'WOJdQGfN', 'WRtdQGvHW4y', '4BEq4BA54Bsx4BE+WRm', 'mmoCbCoSWOi', 'r8oAtLW0', 'nmkIaWvHrWvaWRybW4JdVq', 'WOyHo8obW5S', 'W4RdUqXTCG', 'khhcJGvr', 'l1dcOwldRq', 'WR5OFttdPG', 'hCosjhBWPkoA', 'WQiMW7RcUmoM', 'lulcK8kB', 'yg41W6j4', 'd8kvsW', 'Eg/cPHnOF0tdSa', 'WObQWRBdRG', 'fH7cRvZdSa', 'W4NcNmoAWRHA', 'WPdcLSob', 'WPC0iqOh', 'WQe6WRFcTCoj', 'W7CGi3RcUq', 'WR7dNhu', 'WOWPDCo2W6G', 'pdKVC1m', 'm1lcGmk3EW', 'E8kKDXGs', 'W7VcI8o5rmoV', 'ya0qW7jl', 'FCo2t8oZnG', 'eSoBfmoHWQS', 'WQxdJh/cKq', 'WO01ESoSW4G', 'hmkDxqKd', 'oSo+gCoj', 'lfJcT2VdVa', 'W4ifACoNW4G', 'ASoOWQBdOKy', 'arpcUa', 'WQVdRHHWW6y', 'kCojWO/dJa', 'W6JcKxhcNg4', 'WOiomsCa', '8kYZIokdPpcYGkpcIU+/Qo+/G+++JW', 'qhtXHzk1h0m', 'WQRdU8oDjSoO', 'vSkQCdKu', 'WQFcKdJcTGi', '8ks6KVgmQzhWSyUU8lsON8ku', 'WQxdRSkCFCoL', 'hCo0WOJcQmk7', 'kLFcH8k2', '4Psz4PAm4PEg4PAa4PsZ', 'c8olW5VcTSon', 'w8kuWOFdUmkj', 'W6hdS8o5WQ9M', 'igFdImkkW4S', 'WQKT4lAZ4lEH4lwB', 'WOVcGmoggCk8', 'W6VdV8kcAmoS', 'hSoVW4NcT8kG', 'WQWRW7BcN8oj', 'qhtcPrfl', 'pKRcPM/dRW', 'mKNcOwFdPW', 'bmogW4VdOIW', 'ASoHeCo8lW', 'dZuVA18', 'hmkDtX8B', 'W7ldR8kMBmo2', 'W7JdS8oZ', 'W5BdOubxEq', 'fbLGeGzEh0JdG1/dKgag', 'iY3cNa', '772z776K776a77+M77+V', 'lvhdLoc1O+c2OG', 'ACo6umoJna', 'nmoTWPVdMCoQ', 'WRldOcnKW5O', 'W7hdKCocWPLo', 'WRpdLCkNbCof', 'vH80W7D2', 'W57dUIFdOIa', 'D8kdW7JcHq', 'WRddOGRdLq', '772d772nrFcVSOxIGBlWS6ctEW', 'WOFdUmkVW4tcMG', 'WR5IycpdLq', 'bCkqWRjLW7S', 'W7BcJmo+vCo7', 'W67WRlgnW5VdR2C', 'omkXDdGv', 'W7NcSSkvWOXq', 'WRNcKs/cPvG', 'cmkkW4VdOXC', '4lA5WP/GT7JGTzFGTBW', 'iZpcIrDA', 'W6xdUCk0BSoL', 'iH/cNCokWPK', 'pJVcKaq', 'WR3dTsZcOw8', 'CmoOWQBdPvC', 'WQtcHYpcUbW', 'pKNcLgtdRa', 'v8kszSkyW6y', 'W4/cVSo7DSo6', 'FmoOWRtdOKa', 'WRBdMhZcJCo6', 'WQJdPGBdHmor', 'WRpdLCkNcmkL', 'Eg3dNqrmq0hdSmkL', 'oJu6Fei', 'xH3dNmktW7K', 'W43cTmo7WPTg', 'W5pdVSkMFCo2', '8jgyVpc2QQdWUkMXjUkzGW', 'W5pcHCoAWRLa', 'hmoNW5hcTW', 'jZlcRwNdRW', '8kshL/c0H4NWQ6svW4NWQPsU', 'WQdcJmo9jmkM', 'iG4KlCkd', 'tCohCSotca', 'W6hILBxIL4NILP3IL7C', 'WOldQGr1W4q', '4PYwhmkLW5lcTW', 'W7ddVSkQWOL+', 'WQHOBZtdOa', 'WObQW67dMbe', 'W6FdV8o+WRzV', 'W4RcLSkPeby', 'Adm6A1m', 'WRddV8kdW70c', 'WOpdM8k7', 'WR8nvCoTW5e', 'jXJcISoCWPK', 'zmo2rq', '8ywJKUkdHFc4Ky0i772L77Yt77YB', 'gZyJzLe', 'WO7dICk7W73cKq', 'WOpdOrjXW44', 'W54IWP7cUHK', 'EmkKzJuF', 'arBcQutdVa', 'WPv9WRRdVWW', 'xmk7CduC', 'WPFdMmkdW70c', 'uCkzmSoRW7m', 'zsevW7no', 'iZpcJtDY', 'cIPB8jAeQuO', 'Z4NXGQALl8k58yYwLW', 'WQFdPGBdHmof', '4PA+4PEq4PEg4PEV4PEB', 'iCoQl8oHWRa', 'W6iJWQBcIbK', 'lCoiW4NdPSoS', 'W5tdLCkuW7OL', 'eq0wi8kk', 'CmoHsfS', '4Bw5YAViUSkNyq', 'D8khW7JcHqq', 'WOuJo8kIWPm', 'WRmVW7xcNSoy', 'WQJdTtK', 'WOaJESoMW4W', 'cmk6WRrWW58', 'WOJINAa78l21IpcHL7m', 'W5TNWQpcVbW', 'e8kfW4ddScG', 'WQFdU8kr', 'utpdV/cEU7FWLjIL', 'WOnKrH/dOG', 'WQFcLItcSZ8', 'W4ZcHFcIIPdcIVc4QyO', 'W7dWNiwCD8oaWPa', 'W7FdSbj8vG', 'W5KIW6pcT0u', 'WQ3dTWBdImon', 'DsyoW6PT', 'aSolW5tcUmoifHRdQSklWRWT', '8jMMOFc+LQ/WPOAr8ygeOEkhTW', 'amkzWOxdIs4', 'bqRcRKa', 'BKyWuwO', 'BYSmW7q', 'naxcH8okW4C', 'yCkhW7/cKqe', '77+J776TW4JVVlRVVQ8', 'W5RcHSoLaGe', '4PMVWPlWPzMO8jQBRFcCIPm', 'WOJdRstdKCow', '8yENVVgpLQddNaHP', 'lduOFeq', 'W4GsCSo2W4u', 'WRVdTs7cQNu', 'amkDwq8', 'nHVcNmofWO8', 'ESksW7JcJqi', 'CsJdRmk6WRC', 'iwq0W7bH', 'nfBcNmooWOy', 'WRdcGqXN', 'frma', 'WQpdRmkr', 'q8oMu3Gs', 'W4VcR27cOa', 'lKVcGmkYCq', 'wSozWOK', 'W4hcMSocWPBdNa', 'tSkptXiB', 'a8oajCoxW6HLrxfx', 'h8oqja', 'WQNdRCklzSoJ', 'WQtcKJ7cOXC', 'W5tdR8k/zG', 'zdW4W6z8', 'WPddJIBdRCoN', 'kmopWOBdGCo9', 'v8oigHFcGa', 'rCk8sJq0', 'pKpcGmk/', 'WPZcKSog', 'lZVdIb5A', '8lkQLFgmQQpWMjURWR/WTAQN', 'W67dOCo9jCkI', 'vmosdG', 'WQNcHGPHW7y', 'WRhcGdNcTHu', 'pxpdLCkg', 'WPtdKVc9TOdVUODJra', 'ASoSW6FdS1m', 'ZAZXHzw/WQDX8kQNKG', 'z8klW7JcIaG', 'qSk4kJay', 'BpgjOihWMyQo8lkAM/cPI7S', '4Ps74PE74PEJ4PAo4PE7', 'aSovxq4', 'W67dNgxcOXC', 'vSk14PAy4PAp4PEh', '8yU6I/cEUkpWUjM48yMBTSkF', 'WPxdQq5TW40', 'WPtcKrXNWRm', 'bCk58jcvMo+5Luv4', 'CdSuW7nQ', 'iY7cNbLq', 'kvZcPNVdPa', 'umk8DW', 'W5jSoW', 'uSkvWPddU8oA', 'W6tdRSkeymoV', 'p8ogWRNdR8oQ', 'wCkXsSkmW5C', 'imoAp8oNWQu', 'WORcGpgoVlBIGz/IGPBmG8+XZ7RmNS6T', 'WQtdTtq', 'WQJcKr5RW7y', 'WQRdPZ7dRa', 'W5tdPZPyvG', 'a8obkSknW4vPCwPREW', 'a8kOWQz/W5a', 'WORdUSoZW7hcQG', 'WQ3dL8kaW7FcLG', 'W5JdOZddVdC', 'W5xdMCofWO5p', 'p2pdLCkBW6S', 'WOJdVmk2W4pcTW', 'eCkdW4VdPIi', 'W4NcV3ZcQ3q', 'gSoqma', 'xHNdMmkb', 'fmk+WRrKW50', 'W77dK2dIHl9s', 'y8kxW7/cJa', 'jHRcSu3dUG', 'WP/cMSkXW7pcGW', 'tKeIrfa', 'xHJdM8kBW7O', 'igFdKSknW68', 'WPdcImouc8k1', 'W4ZcGCo3fXm', 'WRaJoGGc', 'aZmCg8kE', 'W5tGTQdGTjFGTkdGTRO', '7724772e77+oWOVVV50', 'tmorW6C', 'WQNcHWS', 'W4xdL8oaWPny', 'W7ldHYvECG', 'W6BdOmkmw8oq', 'i8oAtq7dLG', 'WQ55zZNdSW', 'WRTMB33cNG', 'WRHOEJBdVq', 'cSoJW5BcP8kI', 'W4RcLmoAWQrk', 'cSoUx8k2W4fxxf7dSq', 'ECoJWRpdNKC', 'qmkuyConW6S', 'WROEpa4h', 'DCoMWOxdIuO', 'WQOsvCoxW7S', 'DmoXq0C', 'FSoMu8oYpW', 'WQVdJ8kal8kc', 'aSoAl8o6', 'WOtdImkSW6/dMq', 'qNOwFKi', 'W6NcUvBcJfy', 'kCoiWQW', 'uCkFWPS', 'g8oEi8oTWQ4', 'W5RdOSkQWR1J', 'yeFdMmoeWOuOfwFdPa', 'pSobWP3dGCo9', 'u8kxWOpdQmkF', 'cSk+fH58', 'W4JcV3pcRe0', 'WPpdRb5vW6q', 'lSk7W7FcSWTqW47dPJeoWOZdRG', 'CYSAW6r7', 'eSoDxqFdLW', 'WPlcGmom', 'WQaVW6pcNSo4', 'dmoVW5hcVSkR', 'FCo2xCoLlG', 'WO3cJmobamk1', 'lgnwWQOI', 'W5pdMHHovq', '8k+4P/ghMiJWKQQg8jwBJ8o0', 'emkyW4a', 'jYiI', 'W4dcHSoOe04', 'k8otWRRdK1/cICkjnmkYW6hdVG', 'ASk8bCkYBq', 'WP00DW', 'W6aNlG', 'W47cPmkOWPPX', 'WPu3W4BcR8oP', 'qmoLW4tcTmo6', 'WRhcGqNcTGe', 'kmojWOxdKmo2', 'seeI', 'kCoiWOBdHa', 'f8koW5BdSJC', 'W4pdISkAdCkG', 'gmoEi8oNWQK', 'WPRdT8k9W5dcIq', 'WRtcNqTJW7y', 'e8oJW5W', 'WQldSspcPLC', 'E8o6smoQpW', 'WRlcKqX6W78', 'W4/cH8oc', 'WQxdMhJcJCo2', 'er7cQuK', 'qKGwFxi', 'DqaAW6PQ', 'WONcPcTgW5W', '4PE14Pso4PEp4PAB4PwP', 'wCkGWORdHq', 'xmo2umoJoq', 'CxZcP3ZdPW', 'xCkUztGw', 'W4JdPxZcUgK', '8j+gJE+5Ta', 'uCkThSkRW50', 'WQ5OBt/dUG', 'WQldQZv7W4C', 'sCkFWOZdQ8k3', 'br7cQvZdVa', 'iSopWO4', 'WQldStNcOxm', 'bCoAoCoQWOS', 'kConWQpcHr0', 'WORdS8kJW4dcRq', 'A8onv2ay', 'W4ZcM0JcG2K', 'kSofWPRdLSoQ', 'k8kYWQ90W6C', 'W6JdO8k1ESoS', 'pK3cU2VdVW', 'WRBdQb/cGCok', 'kt4+Aeu', 'WPtdKVc9S7/cQaC', 'WOTDrbNdMq', 'hCo0W6BcS8k9', 'WRpdSSkalW', 'jI3dHX5E', 'oLxdTuddRq', 'eSorsGpcNW', 'CCoUWQZdPey', 'WPJcVIzQW6e', 'WQCJjG0H', 'f8oxW4/cOSox', '4PsK4PA74PEj4PAD4PE3', 'WRpcKrfRW54', 'WQZdGCk/emoDbNXYWPtcUq', 'CmkwW63cUXG', 'W6ldO8oLWQ5V', 'u8o9sviI', 'rSkVWQGXW4i', 'wrhdJSkvW7i', 'pCojWPVdLmoR', 'WP/dN8kWW6G', 'smk8hSk2W5C', 'WRldPGj4W48', 'WRBcKqWVW5O', 'W7RcNCo5rSo6', 'xmktWO7dQSku', 'WQe5W6tdLSoF', 'FfZdOCkxW6a', 'WQaRW6xcMSoc', 'qqNdGmkgW7i', 'WPNdN8kMW6JcUW', 'cmoQxSkGW5y', 'WRxdSH3dLCoh', 'C8kttqGQ', 'Bmo7hmoioW', 'W4yOFSo1W5O', 'pCovWOVdGCoX', 'W7NcICkoWRPn', 'WQ/dOHDZW48', 'e8kPWQS', 'nKVcMSk1', 'WQBdKh7cMmoG', 'WPpcUeRILlRIL5u', 'kuFcHSkOFq', 'lSouW6pcN8kF', 'WOXLWO/dRsK', 'cwpdLCknWQC', 'vmkLysSa', 'WRaNW6pcL8oj', 'WR3dNg3cNCo2', 'WPVcICo8p8kN', 'bSkjW5/dKZG', 'uCkQCdK', 'kxavEKe', 'WQddOZhdJSop', 'DYZcHG', 'gSk0WOFdUmkj', 'pKFcH8k9zG', 'r8kUDYKF', 'hCoXW5y', 'wCk+d8o1WOO', 'WPVdKpcyGi3INQm', 'WRdcNctcOZm', 'WQNdUshcP3u', 'WR3cGmohdCk+', 'WO5XW5xdR1Spfer5iSkacW', 'W6lcVwddRZy', 'p1hcH8k/CW', 'WQ8RW64', 'xmk8hSkN', 'kvtdTttcOG', '8ycuS/goT5dIHARIH5ZXIjEj', 'WQ7dHqnZW5K', 'W5VcTmk0WO0', 'WRZdQ8kBFa', 'hLlcGmkbW7i', 'WRjPEYxdUa', 'W7ZdGrnyEW', 'W5SQWOG', 'W6FdS8oPWRiL', 'Bmk+a+kvQokvUW', 'W7/cJmoVbCkY', '8jwzKFcPIQ0E8kE6RVcEQ5G', 'zmosyX0B', 'WP53BsldNW', 'WP/dHmk0re1bW5ZcGmkPCcil', 'WRaRW6/cJW', 'WPeHitKn', 'W5VcQ8oMWOhcKCo7W4vfW73cIG', 'WRddN8oJWRfB', 'WRJdNh7cMSo7', 'dcedsN8', 'j8oqWP3dNmo3', 'jmoppSoDWOe', 'WPWFW6BcQSoJ', 'wSkOhSk2W50', 'jwpdH8kkW6i', 'rCorWO/cPW', 'CtSiW68', 'FpcWOORcRVgmUQxXJRIf', 's8oWu0e0', '8y6RM/cUIOxWM6Ma8jgkPFcsQ5q', 'aHSwySk5', 'F8oMt8oU', 'WOz8WQFdTqy', 'urpcMg/dVa', 'WQFdR1ldR8od', 'WQxdTbFcGCo1', '77YQ776W77YuWQBVVBq', 'a8onoW', 'WR3dKh7cJmo9', 'bWOenSky', 'dCk+WR4', 'WO7dTXvKW4W', 'W5dcVmovCCor', 'WRWJkq0j', 'WRxdKWtcSGu', 'WQddOGhdGSoq', 'WQ3dQSkDz8kQ', '77YK7725772iWQFWNkgt4Ogd8jAXTG', '772F776r772X776HW6y', '8jgyS/c2QRBWUkM18jY7Vg0', 'umk4c8kMW5C', 'f8oIW4ddV8kI', '8jgsTEkbP/gpSiKZ77Yl77YW776Q', 'W5lcTmo9W4q0', 'c8o2W4NcU8k6', 'WRBdOGhdLmoo', 'h8kroSoVWQ4', 'WQPSEIpdSq', 'gr8ljSkH', 'WR/dU8kjzSoP', 'W5iIWOZcVq4', 'WPPT8yAgKVcNPBFWQRwc', 'WQ8vtCosW6S', 'WRlcQCoKdSku', 'bCkVWQ5+W58', 'bHSwn8kb', 'W73cMCo+s8oP', 'bGVcR0hdTW', 'ymkwW77cJqm', 'ASoKsum0', '8loMMUkeIpgpLylcJxa', '8joAMFcNUO3WSBMu8jkjKCk6', 'bXRcRL3dTq', 'WQ3dQSklFmoV', 'WP3cGmogd8kI', 'zsSiW6r9', 'W7LRzurb', 'mKFcLCk6Cq'];
    _0x31b1 = function () {
      return _0x2ae861;
    };
    return _0x31b1();
  }
  const config = require("../settings");
  const {
    cmd,
    commands
  } = require("../lib/command");
  const l = console.log;
  const {
    getBuffer,
    getGroupAdmins,
    getRandom,
    h2k,
    isUrl,
    Json,
    runtime,
    sleep,
    fetchJson,
    jsonformat
  } = require("../lib/functions");
  const Esana = require("@sl-code-lords/esana-news");
  var api = new Esana();
  const sirasanews = require("sirasa-news");
  const derananews = require("@kaveesha-sithum/derana-news");
  var tmsg = '';
  if (config.LANG === 'URDU') {
    tmsg = "Iss command say ap tech news dhek sakty hain..";
  } else {
    tmsg = "It gives Tech news.";
  }
  var tmsg3 = '';
  function _0x3d8c5c(_0x391ae6, _0x2c33de, _0x96e4e3, _0x1ec2b7, _0x4a3762) {
    return _0x222d(_0x391ae6 - 0x296, _0x1ec2b7);
  }
  if (config.LANG === 'URDU') {
    tmsg3 = "Iss command say ap IOS ke bary mein news ley sakty hain (Iphone).";
  } else {
    tmsg3 = "It gives IOS news.";
  }
  if (config.COMMAND_TYPE === "button") {
    const _0x54b59a = {
      pattern: "news",
      react: "🗃️",
      desc: "Get news",
      category: "search",
      use: ".news",
      filename: __filename
    };
    cmd(_0x54b59a, async (_0x58d459, _0x141a0e, _0x4e9346, {
      from: _0x3b7b4b,
      prefix: _0x33dad6,
      pushname: _0x578450,
      reply: _0x4696fd
    }) => {
      try {
        const _0x49450b = [];
        const _0x493f7c = new Map();
        for (let _0x1a34ba = 0; _0x1a34ba < 1; _0x1a34ba++) {
          const _0x2581fd = commands[_0x1a34ba];
          if (!_0x2581fd.dontAddCommandList && _0x2581fd.pattern !== undefined) {
            const _0x43f10c = _0x2581fd.category.toUpperCase();
            if (!_0x493f7c.has(_0x43f10c)) {
              _0x49450b.push(_0x43f10c);
              _0x493f7c.set(_0x43f10c, []);
            }
            _0x493f7c.get(_0x43f10c).push(_0x2581fd.pattern);
          }
        }
        const _0x26bab2 = [];
        for (const _0x2864a of _0x49450b) {
          const _0x440eeb = {
            header: "Select you want to see news",
            title: "Ios News",
            description: '',
            id: _0x33dad6 + "ios"
          };
          const _0xc8fe8f = {
            header: '',
            title: "wabeta News",
            description: '',
            id: _0x33dad6 + "wabeta"
          };
          const _0x258532 = {
            header: '',
            title: "Nasa News",
            description: '',
            id: _0x33dad6 + "nasanews"
          };
          const _0x258dff = {
            header: '',
            title: "Tech News",
            description: '',
            id: _0x33dad6 + "technews"
          };
          const _0x29fdf4 = {
            header: '',
            title: "Sirasa News",
            description: '',
            id: _0x33dad6 + "sirasanews"
          };
          const _0x1463dc = {
            header: '',
            title: "Esana News",
            description: '',
            id: _0x33dad6 + "esananews"
          };
          const _0x5c76d2 = {
            header: '',
            title: "Derana News",
            description: '',
            id: _0x33dad6 + "derananews"
          };
          const _0x106e69 = {
            header: '',
            title: "Hiru News",
            description: '',
            id: _0x33dad6 + "hirunews"
          };
          const _0x312be1 = {
            header: '',
            title: "Cricket News",
            description: '',
            id: _0x33dad6 + "cricketnews"
          };
          const _0x2f6e88 = {
            header: '',
            title: "Vehical News",
            description: '',
            id: _0x33dad6 + "vnews"
          };
          const _0x168197 = {
            header: '',
            title: "Mobile News",
            description: '',
            id: _0x33dad6 + "gmsnews"
          };
          _0x26bab2.push(_0x440eeb);
          _0x26bab2.push(_0xc8fe8f);
          _0x26bab2.push(_0x258532);
          _0x26bab2.push(_0x258dff);
          _0x26bab2.push(_0x29fdf4);
          _0x26bab2.push(_0x1463dc);
          _0x26bab2.push(_0x5c76d2);
          _0x26bab2.push(_0x106e69);
          _0x26bab2.push(_0x312be1);
          _0x26bab2.push(_0x2f6e88);
          _0x26bab2.push(_0x168197);
        }
        const _0x291e83 = {
          display_text: config.BTN,
          url: config.BTNURL,
          merchant_url: config.BTNURL
        };
        let _0x2b6456 = [{
          'name': "cta_url",
          'buttonParamsJson': JSON.stringify(_0x291e83)
        }, {
          'name': "single_select",
          'buttonParamsJson': JSON.stringify({
            'title': "Select news types",
            'sections': [{
              'title': "Please select a category",
              'highlight_label': "X - B Y T E",
              'rows': _0x26bab2
            }]
          })
        }];
        const _0x3e4766 = {
          image: "https://telegra.ph/file/a8caf4074bdc4e23e0895.jpg",
          header: '',
          footer: config.FOOTER,
          body: "`✦ 𝗡𝗘𝗪𝗦 𝗦𝗘𝗔𝗥𝗖𝗛 ✦`\n    "
        };
        const _0x27462e = {
          quoted: _0x141a0e
        };
        return await _0x58d459.sendButtonMessage(_0x3b7b4b, _0x2b6456, _0x4e9346, _0x3e4766, _0x27462e);
      } catch (_0x58063b) {
        _0x4696fd("*Error !!*");
        console.log(_0x58063b);
      }
    });
  }
  const _0x50a54b = {};

  _0x50a54b.pattern = "ios";
  _0x50a54b.react = '🍎';
  _0x50a54b.dontAddCommandList = true;
  _0x50a54b.filename = __filename;
  cmd(_0x50a54b, async (_0x3f7411, _0x309034, _0x354097, {
    from: _0xc8273,
    q: _0xff9324,
    reply: _0x173d8c
  }) => {
    function _0x59a117(_0x3e0a00, _0x10c920, _0x451525, _0x356334, _0x3484a5) {
      return _0x222d(_0x451525 + 0x16e - 0x296, _0x3484a5);
    }
    const _0x21a199 = {
      'GFNOK': function (_0x10922a, _0x31bb7b) {
        return _0x10922a !== _0x31bb7b;
      },
      'lByYG': function (_0x2700b8, _0xc4dea5) {
        return _0x2700b8 !== _0xc4dea5;
      },
      'EXFSN': "MuqIp",
      'XdKQr': "LxCsN",
      'HHvnf': function (_0x27cda1, _0x377ec7) {
        return _0x27cda1(_0x377ec7);
      },
      'AjPHW': function (_0x829ec0, _0x3f186f) {
        return _0x829ec0 === _0x3f186f;
      },
      'SKlTn': "jidbs",
      'xZRly': function (_0x569dca, _0x3b134e) {
        return _0x569dca(_0x3b134e);
      }
    };
    function _0x40a1a8(_0x386f29, _0x42c559, _0x518640, _0x3d626d, _0x488432) {
      return _0x222d(_0x386f29 - 0x303 + 0x2aa, _0x488432);
    }
    function _0x5cc3a5(_0x3ed56a, _0x114a6f, _0x502be5, _0x27b33e, _0x5ab55f) {
      return _0x222d(_0x27b33e + 0x261 + 0x16c, _0x5ab55f);
    }
    function _0x3ae494(_0x5e3739, _0xcfea2c, _0x5d9690, _0x427ce4, _0x157455) {
      return _0x222d(_0x427ce4 - 0x6b + 0x208, _0xcfea2c);
    }
    function _0x29e46e(_0x373a46, _0x3244a2, _0x38f0fe, _0x4320af, _0x4f5e7c) {
      return _0x222d(_0x4f5e7c + 0xb5 + 0x2aa, _0x4320af);
    }
    try {
      const _0x4d1c2e = await fetchJson("https://api.maher-zubair.tech/details/ios");
      let _0x2e8f03 = "X B Y T E  I O S  N E W S\n\n*🔖 Title:* " + _0x4d1c2e.result.title + "\n*⛓️ Link:* " + _0x4d1c2e.result.link + "\n*📚 Description:* " + _0x4d1c2e.result.desc;
      const _0x44eca3 = {
        url: _0x4d1c2e.result.images
      };
      const _0x11a974 = {
        image: _0x44eca3,
        caption: _0x2e8f03
      };
      const _0x17f6e8 = {
        quoted: _0x354097
      };
      return await _0x3f7411.sendMessage(_0xc8273, _0x11a974, _0x17f6e8);
      const _0x5e8253 = {
        text: '✅',
        key: _0x354097.key
      };
      const _0x392836 = {
        react: _0x5e8253
      };
      await _0x3f7411.sendMessage(_0xc8273, _0x392836);
    } catch (_0xbad4d5) {
      l(_0xbad4d5);
    }
  });
  const _0x380bd5 = {
    pattern: "wabeta",
    react: '✔️',
    dontAddCommandList: true,
    filename: __filename
  };
  cmd(_0x380bd5, async (_0x397443, _0x75b4f8, _0x11fbdc, {
    from: _0x126bec,
    q: _0x54ae83,
    reply: _0x4b6ed0
  }) => {
    function _0x37a739(_0x22500c, _0x3060ad, _0x4a5d97, _0x20c2a9, _0x426553) {
      return _0x222d(_0x22500c - 0x37 - 0x296, _0x4a5d97);
    }
    function _0x645319(_0x126ea6, _0x3eaf8b, _0x2f9f4f, _0x31fe69, _0x29e053) {
      return _0x222d(_0x126ea6 - 0x11c - 0x296, _0x2f9f4f);
    }
    const _0x41a81a = {
      'qfPZr': function (_0x4ebf9e) {
        return _0x4ebf9e();
      },
      'RZCou': function (_0x1479b0, _0x23c282) {
        return _0x1479b0(_0x23c282);
      },
      'FcRbD': function (_0x3aba9c, _0x2ecf70) {
        return _0x3aba9c(_0x2ecf70);
      },
      'KLQbD': function (_0x84efeb, _0x19299b) {
        return _0x84efeb === _0x19299b;
      },
      'VHyNl': "Hxcpf",
      'yOxAd': function (_0x4c0900, _0x476afe) {
        return _0x4c0900 === _0x476afe;
      },
      'SMols': "QHKkI"
    };
    function _0x49a42b(_0x466d30, _0x72dcb8, _0x47df2c, _0x207044, _0x1722d6) {
      return _0x222d(_0x466d30 - 0x1e2 + 0x3e4, _0x72dcb8);
    }
    function _0x13a362(_0x34cace, _0x2fe7ff, _0x247710, _0x1c7af5, _0x3d53b1) {
      return _0x222d(_0x247710 + 0xbb + 0x2aa, _0x1c7af5);
    }
    function _0x29342d(_0xe1eb28, _0x337e96, _0x2bdd67, _0x1491c0, _0xf7fdf6) {
      return _0x222d(_0x337e96 - 0x29 + 0x3e4, _0xe1eb28);
    }
    try {
      const _0x19b29e = await fetchJson("https://api.maher-zubair.tech/details/wabetainfo");
      let _0x51c7d9 = "X - B Y T E - W A - B E T A - N E W S\n\n*🥏 Title :* " + _0x19b29e.result.title + "\n*📅 Date :* " + _0x19b29e.result.date + "\n*🖥️ Platform :* " + _0x19b29e.result.subtitle + "\n*🔗 URL :* " + _0x19b29e.result.link + "\n*🗞️ Short Desc :* " + _0x19b29e.result.desc;
      const _0x549bd1 = {
        url: _0x19b29e.result.image
      };
      const _0x165ef3 = {
        image: _0x549bd1,
        caption: _0x51c7d9
      };
      const _0x54d238 = {
        quoted: _0x11fbdc
      };
      return await _0x397443.sendMessage(_0x126bec, _0x165ef3, _0x54d238);
      const _0x30005a = {
        text: '✅',
        key: _0x11fbdc.key
      };
      const _0x398273 = {
        react: _0x30005a
      };
      await _0x397443.sendMessage(_0x126bec, _0x398273);
    } catch (_0x37db6d) {
      l(_0x37db6d);
    }
  });
  const _0x40cd72 = {};
  function _0x3ff1bb(_0x326a9f, _0x5f1a54, _0xcbb524, _0x5c50d6, _0x33fbe9) {
    return _0x222d(_0x5f1a54 + 0x3e4, _0x326a9f);
  }
  _0x40cd72.pattern = "nasanews";
  _0x40cd72.react = '📡';
  _0x40cd72.dontAddCommandList = true;
  _0x40cd72.filename = __filename;
  cmd(_0x40cd72, async (_0x355cf0, _0x2a25db, _0x417c41, {
    from: _0x4986be,
    q: _0x38b155,
    reply: _0x5682cd
  }) => {
    function _0x4407e2(_0x4e4f21, _0x5674b8, _0x32d059, _0x529c41, _0x260b9d) {
      return _0x222d(_0x529c41 - 0x356 + 0x208, _0x5674b8);
    }
    function _0x1ba70e(_0x5417d5, _0x2963e3, _0x2eb044, _0x5d1c1a, _0x5f5af6) {
      return _0x222d(_0x5417d5 + 0x1b0 - 0x296, _0x5f5af6);
    }
    function _0x1c3314(_0x2ba1ab, _0x40ec6f, _0x2c2f59, _0x32479f, _0x183c3a) {
      return _0x222d(_0x2ba1ab - 0x516 + 0x3e4, _0x40ec6f);
    }
    const _0x168504 = {
      'WQOpy': "1|3|2|4|0",
      'DpRis': function (_0x2de612, _0x37e9ff) {
        return _0x2de612(_0x37e9ff);
      },
      'DmrhG': function (_0x568282, _0x26caa2) {
        return _0x568282 !== _0x26caa2;
      },
      'jRFus': "dlTXn",
      'jprpe': "yVSGj",
      'KUSLJ': function (_0x209ae3, _0x40ed79) {
        return _0x209ae3(_0x40ed79);
      },
      'sDbpg': function (_0x540ae9, _0x34f746) {
        return _0x540ae9 === _0x34f746;
      },
      'epAjd': "cfHxn",
      'FxVuO': function (_0x220a32, _0x3957ab) {
        return _0x220a32(_0x3957ab);
      }
    };
    function _0x173ab3(_0x5dce89, _0x18c4e2, _0x1bec66, _0x55b766, _0x2a02a6) {
      return _0x222d(_0x2a02a6 - 0x2b1 + 0x3e4, _0x18c4e2);
    }
    function _0x933a67(_0x2dd4aa, _0x144064, _0x1ab4c3, _0x4407b2, _0x85208c) {
      return _0x222d(_0x1ab4c3 - 0x2bd + 0x16c, _0x144064);
    }
    try {
      const _0x15f0ce = await fetchJson("https://api.maher-zubair.tech/details/nasa");
      const _0x5f3746 = "X - B Y T E - N A S A - N E W S\n\n🪄 𝙏𝙄𝙏𝙇𝙀: " + _0x15f0ce.result.title + "\n📆𝘿𝘼𝙏𝙀: " + _0x15f0ce.result.date + "\n🚀 𝙑𝙀𝙍𝙎𝙄𝙊𝙉: " + _0x15f0ce.result.service_version + "\n🔖𝙐𝙍𝙇: " + _0x15f0ce.result.url + "\n📝 𝙀𝙓𝙋𝙇𝘼𝙉𝘼𝙏𝙄𝙊𝙉: " + _0x15f0ce.result.explanation;
      const _0x1b618d = {
        url: _0x15f0ce.result.hdurl
      };
      const _0x581780 = {
        image: _0x1b618d,
        caption: _0x5f3746
      };
      const _0x461c5d = {
        quoted: _0x417c41
      };
      return _0x355cf0.sendMessage(_0x4986be, _0x581780, _0x461c5d);
      const _0x1e391d = {
        text: '✅',
        key: _0x417c41.key
      };
      const _0x126d0b = {
        react: _0x1e391d
      };
      await _0x355cf0.sendMessage(_0x4986be, _0x126d0b);
    } catch (_0x383630) {
      l(_0x383630);
    }
  });
  const _0x8b831b = {
    pattern: "technews",
    react: '📡',
    dontAddCommandList: true,
    filename: __filename
  };
  cmd(_0x8b831b, async (_0x4ac683, _0x17369e, _0x1b7f99, {
    from: _0x2a44df,
    q: _0x5781ac,
    reply: _0x1bd983
  }) => {
    function _0x30bc2a(_0x4f5171, _0x5583e9, _0x1d49bb, _0x55d26b, _0x271a2b) {
      return _0x222d(_0x1d49bb - 0x321 + 0x16c, _0x5583e9);
    }
    function _0x1146ae(_0x1a566d, _0x37c2ca, _0x3fd9b2, _0x1bf794, _0x3a6d9c) {
      return _0x222d(_0x1bf794 - 0x23e + 0x2aa, _0x37c2ca);
    }
    function _0x4105b6(_0x539445, _0x25cbc9, _0x588e3b, _0x19395f, _0x2a22e7) {
      return _0x222d(_0x539445 + 0xd8 - 0x296, _0x2a22e7);
    }
    function _0x48cc3a(_0x28acab, _0x10294d, _0x32f317, _0x545e7a, _0x459076) {
      return _0x222d(_0x545e7a - 0x57 - 0x296, _0x28acab);
    }
    function _0x3f1789(_0x449201, _0x1126ee, _0x4a0dc9, _0x2c0f58, _0x179de1) {
      return _0x222d(_0x449201 - 0x32b + 0x208, _0x179de1);
    }
    const _0x18851b = {
      'VRFMQ': "Select you want to see news",
      'GSVPB': function (_0x25a61a) {
        return _0x25a61a();
      },
      'KQIDQ': function (_0x3cad6d, _0x1589d6) {
        return _0x3cad6d(_0x1589d6);
      },
      'RpiSG': function (_0x33d6a8, _0x33a818) {
        return _0x33d6a8(_0x33a818);
      },
      'QPJNM': function (_0x173041, _0x55195c) {
        return _0x173041 === _0x55195c;
      },
      'WUxov': "mXjWR",
      'mkBHx': "tech-news-scraper",
      'NosDa': function (_0x105fe5, _0x217970) {
        return _0x105fe5 < _0x217970;
      },
      'CvTxq': function (_0x1da286, _0x2489ca) {
        return _0x1da286 !== _0x2489ca;
      },
      'JhxwI': "enMxc",
      'lQGYr': "2|4|0|1|3",
      'VIZDz': function (_0x36d98e, _0x5dcbbf) {
        return _0x36d98e(_0x5dcbbf);
      },
      'BPeLe': function (_0x41e03f, _0x4f259d) {
        return _0x41e03f !== _0x4f259d;
      },
      'blISw': "fhmCJ",
      'OybvE': "nPMqE",
      'pwNhG': function (_0x535bd8, _0x4bb8d7) {
        return _0x535bd8(_0x4bb8d7);
      }
    };
    try {
      const _0xe7ddac = require("tech-news-scraper");
      const _0x32f91c = await _0xe7ddac.allNews();
      let _0x66b63f = "👨‍💻 ＶＡＪＩＲＡ ＴＥＣＨ ＮＥＷＳ 👨‍💻\n\n";
      for (let _0x726ab0 = 0; _0x726ab0 < 16; _0x726ab0++) {
        _0x66b63f += "*⛓️ No:* " + _0x32f91c.result[_0x726ab0].no + "\n";
        _0x66b63f += "*📃 Title:* " + _0x32f91c.result[_0x726ab0].title + "\n";
        _0x66b63f += "*📚 CatName:* " + _0x32f91c.result[_0x726ab0].catname + "\n";
        _0x66b63f += "*🕒 Time:* " + _0x32f91c.result[_0x726ab0].date + "\n";
        _0x66b63f += "*📎 Link:* " + _0x32f91c.result[_0x726ab0].link + "\n\n--------------------------------------------\n\n\n";
      }
      return await _0x1bd983(_0x66b63f);
      const _0x3ffdf6 = {
        url: _0x32f91c.result[i].img
      };
      const _0xd11cc9 = {
        image: _0x3ffdf6,
        caption: _0x66b63f
      };
      const _0x204598 = {
        quoted: _0x1b7f99
      };
      return await _0x4ac683.sendMessage(_0x2a44df, _0xd11cc9, _0x204598);
      const _0xbcb038 = {
        text: '✅',
        key: _0x1b7f99.key
      };
      const _0x5bef43 = {
        react: _0xbcb038
      };
      await _0x4ac683.sendMessage(_0x2a44df, _0x5bef43);
    } catch (_0x10cb17) {
      _0x1bd983();
      l(_0x10cb17);
    }
  });
  const _0x926436 = {
    pattern: "sirasanews",
    react: "🎙️",
    dontAddCommandList: true
  };
  function _0x1ad359(_0x4281ad, _0x5ea0e9, _0x2b34f1, _0xe1617a, _0x4c8c2e) {
    return _0x222d(_0x4281ad + 0x2aa, _0x5ea0e9);
  }
  _0x926436.filename = __filename;
  cmd(_0x926436, async (_0x7b5551, _0x188a6d, _0x1a4d57, {
    from: _0x13af31,
    q: _0x2d7c42,
    reply: _0x9012f7
  }) => {
    const _0x12b9f7 = {
      'PmDAE': function (_0x114d4e) {
        return _0x114d4e();
      },
      'pLCzB': function (_0x265e84, _0x2acd11) {
        return _0x265e84 !== _0x2acd11;
      },
      'rcwuw': "vagoq",
      'lBQmC': "NfatT",
      'WUghI': function (_0x602be7, _0x10c767) {
        return _0x602be7(_0x10c767);
      }
    };
    const _0x3715ca = await sirasanews();
    function _0x1968f2(_0x301346, _0x4a5bdf, _0x3fd638, _0x147ced, _0x276345) {
      return _0x222d(_0x3fd638 + 0x240 + 0x16c, _0x301346);
    }
    function _0x241d88(_0x2f5814, _0x55f8ae, _0x15e479, _0x147d82, _0x956a30) {
      return _0x222d(_0x147d82 - 0x41e + 0x208, _0x956a30);
    }
    function _0x875794(_0x37fdc4, _0x4bf271, _0x1bbe3c, _0x49d762, _0x43c3ba) {
      return _0x222d(_0x49d762 - 0x4e + 0x3e4, _0x1bbe3c);
    }
    function _0xd900f0(_0x102d7c, _0x161bd4, _0xb0c31f, _0x4d25b8, _0x198e6a) {
      return _0x222d(_0xb0c31f + 0xe1 + 0x16c, _0x102d7c);
    }
    function _0x26597b(_0x580702, _0x2b6400, _0x168648, _0x597b59, _0x5382a1) {
      return _0x222d(_0x580702 - 0x2da + 0x16c, _0x2b6400);
    }
    try {
      const _0x31cecf = "⛶ X - B Y T E - S I R A S A  N E W S ⛶    \n🌹⃝⃘̉̉̉̉̉̉🧚 *𝕋𝕀𝕋𝕃𝔼:* " + _0x3715ca.result.title + "\n\n🌹⃝⃘̉̉̉̉̉̉🧚 *𝔻𝔸𝕋𝔼 𝔸ℕ𝔻 𝕋𝕀𝕄𝔼* : " + _0x3715ca.result.dateandtime + "\n\n🌹⃝⃘̉̉̉̉̉̉🧚 *𝔻𝔼𝕊ℂℝ𝕀𝕃𝕋𝕀𝕆ℕ:* " + _0x3715ca.result.description + "\n\n🌹⃝⃘̉̉̉̉̉̉🧚 *ℕ𝔼𝕎𝕊 𝕃𝕀ℕ𝕂:* " + _0x3715ca.result.link;
      const _0x11880c = {
        url: _0x3715ca.result.image
      };
      const _0x1acc21 = {
        image: _0x11880c,
        caption: _0x31cecf
      };
      const _0x2ca9b4 = {
        quoted: _0x1a4d57
      };
      await _0x7b5551.sendMessage(_0x13af31, _0x1acc21, _0x2ca9b4);
      const _0x450310 = {
        text: '✅',
        key: _0x1a4d57.key
      };
      const _0x3717ba = {
        react: _0x450310
      };
      await _0x7b5551.sendMessage(_0x13af31, _0x3717ba);
    } catch (_0x1ea765) {
      _0x9012f7();
      l(_0x1ea765);
    }
  });
  const _0xefb52c = {
    pattern: "esananews",
    react: "🎙️"
  };
  function _0x188e75(_0x4c5faf, _0x203345, _0xb6ba4, _0x4d42c7, _0xc8019d) {
    return _0x222d(_0xc8019d + 0x16c, _0x4d42c7);
  }
  _0xefb52c.dontAddCommandList = true;
  _0xefb52c.filename = __filename;
  cmd(_0xefb52c, async (_0xd80dde, _0x30e153, _0x4e7da9, {
    from: _0x2801b1,
    q: _0x34d868,
    reply: _0x18826d
  }) => {
    function _0x525103(_0x3f5186, _0x3501a3, _0x3e5167, _0x42cdcf, _0x4a3e33) {
      return _0x222d(_0x4a3e33 + 0x20d - 0x296, _0x42cdcf);
    }
    function _0x393d62(_0x56ad9a, _0x2e6b4f, _0x5e4edd, _0x42fd5d, _0x351c52) {
      return _0x222d(_0x2e6b4f - 0x10 + 0x16c, _0x56ad9a);
    }
    function _0x3a10f1(_0xe360c4, _0x245480, _0xf0f4df, _0x40c594, _0x5b898e) {
      return _0x222d(_0xf0f4df + 0x12a - 0x296, _0xe360c4);
    }
    const _0x36d479 = {
      'bhGXL': function (_0x462acd, _0x3d5283) {
        return _0x462acd || _0x3d5283;
      },
      'RMpAv': function (_0x3c87ee) {
        return _0x3c87ee();
      },
      'DdPNR': function (_0x28c84c, _0x1ce860) {
        return _0x28c84c(_0x1ce860);
      }
    };
    function _0x5ef2e1(_0x4c4e1e, _0x1d4f1b, _0x2e7dfd, _0x3f38b6, _0x473130) {
      return _0x222d(_0x2e7dfd - 0x45b + 0x16c, _0x1d4f1b);
    }
    function _0x239462(_0x15da7f, _0x2bb2d9, _0x575010, _0x2415d2, _0x495c11) {
      return _0x222d(_0x15da7f + 0x62e - 0x296, _0x2415d2);
    }
    try {
      const _0x75bb2 = await api.latest_id();
      const _0x4eb708 = _0x75bb2.results.news_id;
      let _0x1d38ce = _0x34d868 || _0x4eb708;
      const _0x401ba9 = await api.news(_0x1d38ce);
      const _0x55f68a = _0x401ba9.results;
      const _0x4d0e4d = {
        url: _0x55f68a.COVER
      };
      const _0x575cfe = {
        image: _0x4d0e4d,
        caption: "\n*┠─❲ 👩🏻‍🎨 X - B Y T E 🗞️❳* \n\n*┃◉* *⇨ ᴛɪᴛᴇʟ :*\n " + _0x55f68a.TITLE + "\n\n*┃◉* *⇨ ᴅᴀᴛᴇ :*\n " + _0x55f68a.PUBLISHED + "\n\n*┃◉* *⇨ ᴜʀʟ :*\n " + _0x55f68a.URL + "\n\n*┃◉* *⇨ Description :*\n " + _0x55f68a.DESCRIPTION + "\n\n*𝙿𝙾𝚆𝙴𝚁𝙳 𝙱𝚈 𝚅𝙰𝙹𝙸𝚁𝙰 𝚈𝚃 ®*\n\n"
      };
      const _0x28dac8 = {
        quoted: _0x4e7da9
      };
      const _0x47e7a9 = await _0xd80dde.sendMessage(_0x2801b1, _0x575cfe, _0x28dac8);
      const _0x54ef73 = {
        text: '✅',
        key: _0x4e7da9.key
      };
      const _0x3d2746 = {
        react: _0x54ef73
      };
      await _0xd80dde.sendMessage(_0x2801b1, _0x3d2746);
    } catch (_0x3d2c6f) {
      _0x18826d();
      l(_0x3d2c6f);
    }
  });
  const _0x2b63e2 = {
    pattern: "derananews",
    react: "🎙️",
    dontAddCommandList: true,
    filename: __filename
  };
  cmd(_0x2b63e2, async (_0x5a4a84, _0x2e82e1, _0x5b1bdf, {
    from: _0x956a7c,
    q: _0x9e4189,
    reply: _0x27797f
  }) => {
    function _0x7eaa31(_0x52df3e, _0x269e78, _0xf161a5, _0x26e9f4, _0x1accdd) {
      return _0x222d(_0x1accdd + 0xfd - 0x296, _0x269e78);
    }
    function _0x122ce1(_0x29d660, _0xe8f816, _0x27ad66, _0x2c5087, _0x173f54) {
      return _0x222d(_0xe8f816 + 0xe2 + 0x2aa, _0x173f54);
    }
    const _0x6116c5 = {
      'FXITY': function (_0x5412e6) {
        return _0x5412e6();
      },
      'XQqQO': function (_0x5c2d9a, _0x1af128) {
        return _0x5c2d9a(_0x1af128);
      }
    };
    const _0x181ef4 = await derananews();
    function _0x3e847f(_0x4f6781, _0x4eaba0, _0x574514, _0x18cb13, _0xf0f09b) {
      return _0x222d(_0x574514 - 0x14c + 0x16c, _0x18cb13);
    }
    function _0x43af9b(_0x1df03a, _0x35ae4d, _0x289c89, _0x378714, _0x4ef21f) {
      return _0x222d(_0x378714 + 0x122 - 0x296, _0x4ef21f);
    }
    function _0x5532da(_0x2663b3, _0x19c96d, _0x419517, _0x3fe736, _0x52ce26) {
      return _0x222d(_0x19c96d - 0x255 + 0x2aa, _0x52ce26);
    }
    try {
      const _0x2d7630 = " X - B Y T E - D E R A N  N E W S\n    \n🌹⃝⃘̉̉̉̉̉̉🧚 *𝕋𝕀𝕋𝕃𝔼:* " + _0x181ef4.title + "\n\n🌹⃝⃘̉̉̉̉̉̉🧚 *ℕ𝔼𝕎𝕊 𝕃𝕀ℕ𝕂:* " + _0x181ef4.link + "\n\n🌹⃝⃘̉̉̉̉̉̉🧚 *𝔻𝔼𝕊ℂℝ𝕀𝕃𝕋𝕀𝕆ℕ:* " + _0x181ef4.description;
      const _0x23e410 = {
        url: _0x181ef4.image
      };
      const _0x53767f = {
        image: _0x23e410,
        caption: _0x2d7630
      };
      const _0x2f581f = {
        quoted: _0x5b1bdf
      };
      await _0x5a4a84.sendMessage(_0x956a7c, _0x53767f, _0x2f581f);
      const _0x2b3185 = {
        text: '✅',
        key: _0x5b1bdf.key
      };
      const _0x2f9afe = {
        react: _0x2b3185
      };
      await _0x5a4a84.sendMessage(_0x956a7c, _0x2f9afe);
    } catch (_0x2472a5) {
      _0x27797f();
      l(_0x2472a5);
    }
  });
  const _0x28c113 = {
    pattern: "hirunews",
    react: '🔖',
    dontAddCommandList: true,
    filename: __filename
  };
  function _0x443b25(_0x440cc6, _0x453ae9, _0x5a7b99, _0x4535b0, _0x52d59b) {
    return _0x222d(_0x5a7b99 + 0x208, _0x453ae9);
  }
  cmd(_0x28c113, async (_0x1e570a, _0x2222b8, _0x42ce4, {
    from: _0x2fa092,
    q: _0x5f57b7,
    reply: _0x4cebc5
  }) => {
    function _0x523874(_0x5a7c50, _0x3df52a, _0x3b238d, _0x13a094, _0x411f56) {
      return _0x222d(_0x411f56 - 0x2b5 + 0x16c, _0x5a7c50);
    }
    function _0x1582ce(_0x2516b3, _0x1fd384, _0x422859, _0xd04467, _0x1f50b2) {
      return _0x222d(_0x1fd384 - 0x529 + 0x3e4, _0xd04467);
    }
    function _0x5b62bf(_0x2bac07, _0x30234b, _0x5f0e26, _0x2d6784, _0x5f1846) {
      return _0x222d(_0x5f0e26 + 0x8a + 0x16c, _0x30234b);
    }
    function _0x86fb1f(_0x403740, _0x45de4d, _0x5a2fb9, _0x52686c, _0x234327) {
      return _0x222d(_0x5a2fb9 - 0x2e9 + 0x3e4, _0x45de4d);
    }
    const _0x246132 = {
      'YiHHv': function (_0x550842, _0x1f4d54) {
        return _0x550842(_0x1f4d54);
      },
      'QyQTE': "hirunews-scrap",
      'hkFAD': function (_0x4f1048) {
        return _0x4f1048();
      }
    };
    function _0x59a498(_0x460fc0, _0x2d8b52, _0x46aae3, _0x3cfec2, _0x3ae8eb) {
      return _0x222d(_0x3cfec2 - 0x234 + 0x208, _0x460fc0);
    }
    try {
      const _0x38e13f = require("hirunews-scrap");
      var _0x5111b6 = new _0x38e13f();
      const _0x4a4cf5 = await _0x5111b6.MainNews();
      const _0x26419f = _0x4a4cf5.results;
      const _0x3d5f71 = _0x26419f.title;
      const _0x28fd70 = _0x26419f.news;
      const _0x38927e = _0x26419f.date;
      const _0x4550ba = _0x26419f.thumb;
      const _0x2d47b1 = {
        url: _0x4550ba
      };
      const _0x3f9e1d = {
        image: _0x2d47b1,
        caption: "\n X - B Y T E - H I R U N  N E W S\n\n📍➣*" + _0x3d5f71 + "* \n●━━━━━━━━━━━━━━━━━━━━━●  \n📃➣" + _0x28fd70 + " \n●━━━━━━━━━━━━━━━━━━━━━● \n📅➣" + _0x38927e + "\n●━━━━━━━━━━━━━━━━━━━━━●\n\n🗞️ *News From hirunews.lk*\n\n🔗 *Create By Hamza*\n\n📍 *SL News*\n\n\n●━━━━━━━━━━━━━━━━━━━━━●"
      };
      const _0x1aac60 = {
        quoted: _0x42ce4
      };
      const _0x42b7d7 = await _0x1e570a.sendMessage(_0x2fa092, _0x3f9e1d, _0x1aac60);
      const _0x5d3f72 = {
        text: '📰',
        key: _0x42b7d7.key
      };
      const _0x56f7f9 = {
        react: _0x5d3f72
      };
      await _0x1e570a.sendMessage(_0x2fa092, _0x56f7f9);
    } catch (_0x377837) {
      _0x4cebc5();
      l(_0x377837);
    }
  });
  const _0x4f56f7 = {
    pattern: "cricketnews",
    react: "🎙️",
    dontAddCommandList: true,
    filename: __filename
  };
  cmd(_0x4f56f7, async (_0x58b3e9, _0x5b5a2f, _0x3453a0, {
    from: _0x2e7ee0,
    q: _0x49485a,
    reply: _0x3e4163
  }) => {
    function _0x1c76c3(_0x2a0914, _0x12050b, _0x305bd7, _0x2c7e6d, _0x47fa07) {
      return _0x222d(_0x2c7e6d - 0x418 + 0x16c, _0x305bd7);
    }
    const _0x27e6b7 = {
      'wMyYs': function (_0x37fb3d, _0x2f0e40) {
        return _0x37fb3d(_0x2f0e40);
      },
      'DqXUI': "https://api.cricapi.com/v1/currentMatches?apikey=f68d1cb5-a9c9-47c5-8fcd-fbfe52bace78",
      'zMrlr': function (_0x37835b, _0x5a7397) {
        return _0x37835b < _0x5a7397;
      },
      'nBrEJ': function (_0x385b9a, _0x4d3a6d) {
        return _0x385b9a + _0x4d3a6d;
      },
      'kuEgn': function (_0x572abb, _0x3e0c46) {
        return _0x572abb + _0x3e0c46;
      },
      'veWyt': "\n*Match Name  :* ",
      'GNuoe': "\n*Match Status  :* ",
      'WKNox': "\n*Match  Date   :* ",
      'dwvjX': function (_0x88eb99, _0x4e0aea) {
        return _0x88eb99 + _0x4e0aea;
      },
      'fjKTR': "\n*Match Started :* ",
      'hJugs': "\n*Match Ended:* ",
      'yDMIp': function (_0x2781aa, _0x3ad7b8) {
        return _0x2781aa(_0x3ad7b8);
      },
      'ICHVM': function (_0x572632) {
        return _0x572632();
      }
    };
    function _0x47797a(_0x2d16a3, _0x279386, _0x415c80, _0x432821, _0x1b8506) {
      return _0x222d(_0x415c80 - 0x127 - 0x296, _0x432821);
    }
    function _0x118f2b(_0x254f9b, _0x5a0626, _0x266d44, _0x5f5544, _0x57ad08) {
      return _0x222d(_0x57ad08 - 0x379 + 0x3e4, _0x266d44);
    }
    function _0x44e774(_0x3d5378, _0x1cd58d, _0x5e1c44, _0x5060c3, _0x354d11) {
      return _0x222d(_0x5e1c44 + 0x5b2 - 0x296, _0x3d5378);
    }
    function _0x5aec1b(_0x52e0f0, _0xce442a, _0x2f93bc, _0x80b60d, _0x22e93d) {
      return _0x222d(_0x80b60d - 0x5c8 + 0x3e4, _0x52e0f0);
    }
    try {
      _0x3e4163("*_Please Wait, Getting Cricket Info_*");
      const _0x468265 = await fetch("https://api.cricapi.com/v1/currentMatches?apikey=f68d1cb5-a9c9-47c5-8fcd-fbfe52bace78");
      const _0x190e36 = await _0x468265.json();
      console.log(_0x190e36);
      for (let _0x377b05 = 0; _0x377b05 < _0x190e36.data.length; _0x377b05++) {
        let _0x2678d3 = _0x377b05 + 1;
        _0x49485a += "\n*--------------------- MATCH " + _0x377b05 + "-------------------*";
        _0x49485a += "\n*Match Name  :* " + _0x190e36.data[_0x377b05].name;
        _0x49485a += "\n*Match Status  :* " + _0x190e36.data[_0x377b05].status;
        _0x49485a += "\n*Match  Date   :* " + _0x190e36.data[_0x377b05].dateTimeGMT;
        _0x49485a += "\n*Match Started :* " + _0x190e36.data[_0x377b05].matchStarted;
        _0x49485a += "\n*Match Ended:* " + _0x190e36.data[_0x377b05].matchEnded;
      }
      return await _0x3e4163(_0x49485a);
      const _0x1dd040 = {
        text: '✅',
        key: _0x3453a0.key
      };
      const _0x4f2808 = {
        react: _0x1dd040
      };
      await _0x58b3e9.sendMessage(_0x2e7ee0, _0x4f2808);
    } catch (_0x244206) {
      _0x3e4163();
      l(_0x244206);
    }
  });
