function _0x5bd1(_0x596b27, _0x52ea44) {
    const _0x5b4ed9 = _0xa865();
    _0x5bd1 = function (_0x440f2f, _0x505710) {
      _0x440f2f = _0x440f2f - 419;
      let _0x4f3b1d = _0x5b4ed9[_0x440f2f];
      if (_0x5bd1.SoSBJS === undefined) {
        var _0x42f104 = function (_0x1ba2be) {
          let _0x2d4fd7 = '';
          let _0x12a9cd = '';
          let _0xc2f9ce = 0;
          let _0x52f666;
          let _0x31a81a;
          for (let _0x347e9c = 0; _0x31a81a = _0x1ba2be.charAt(_0x347e9c++); ~_0x31a81a && (_0x52f666 = _0xc2f9ce % 4 ? _0x52f666 * 64 + _0x31a81a : _0x31a81a, _0xc2f9ce++ % 4) ? _0x2d4fd7 += String.fromCharCode(255 & _0x52f666 >> (-2 * _0xc2f9ce & 6)) : 0) {
            _0x31a81a = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/='.indexOf(_0x31a81a);
          }
          let _0x4d4002 = 0;
          for (let _0x4973af = _0x2d4fd7.length; _0x4d4002 < _0x4973af; _0x4d4002++) {
            _0x12a9cd += '%' + ('00' + _0x2d4fd7.charCodeAt(_0x4d4002).toString(16)).slice(-2);
          }
          return decodeURIComponent(_0x12a9cd);
        };
        const _0x250081 = function (_0x9af6a2, _0x4aeec3) {
          let _0x52d431 = [];
          let _0x1d0160 = 0;
          let _0x537b39;
          let _0x409ed1 = '';
          _0x9af6a2 = _0x42f104(_0x9af6a2);
          let _0x271dac;
          for (_0x271dac = 0; _0x271dac < 256; _0x271dac++) {
            _0x52d431[_0x271dac] = _0x271dac;
          }
          for (_0x271dac = 0; _0x271dac < 256; _0x271dac++) {
            _0x1d0160 = (_0x1d0160 + _0x52d431[_0x271dac] + _0x4aeec3.charCodeAt(_0x271dac % _0x4aeec3.length)) % 256;
            _0x537b39 = _0x52d431[_0x271dac];
            _0x52d431[_0x271dac] = _0x52d431[_0x1d0160];
            _0x52d431[_0x1d0160] = _0x537b39;
          }
          _0x271dac = 0;
          _0x1d0160 = 0;
          for (let _0x5eb739 = 0; _0x5eb739 < _0x9af6a2.length; _0x5eb739++) {
            _0x271dac = (_0x271dac + 1) % 256;
            _0x1d0160 = (_0x1d0160 + _0x52d431[_0x271dac]) % 256;
            _0x537b39 = _0x52d431[_0x271dac];
            _0x52d431[_0x271dac] = _0x52d431[_0x1d0160];
            _0x52d431[_0x1d0160] = _0x537b39;
            _0x409ed1 += String.fromCharCode(_0x9af6a2.charCodeAt(_0x5eb739) ^ _0x52d431[(_0x52d431[_0x271dac] + _0x52d431[_0x1d0160]) % 256]);
          }
          return _0x409ed1;
        };
        _0x5bd1.xJBFgJ = _0x250081;
        _0x596b27 = arguments;
        _0x5bd1.SoSBJS = true;
      }
      const _0x40aedc = _0x5b4ed9[0];
      const _0x53d48b = _0x440f2f + _0x40aedc;
      const _0x323706 = _0x596b27[_0x53d48b];
      if (!_0x323706) {
        if (_0x5bd1.ZtzOWy === undefined) {
          _0x5bd1.ZtzOWy = true;
        }
        _0x4f3b1d = _0x5bd1.xJBFgJ(_0x4f3b1d, _0x505710);
        _0x596b27[_0x53d48b] = _0x4f3b1d;
      } else {
        _0x4f3b1d = _0x323706;
      }
      return _0x4f3b1d;
    };
    return _0x5bd1(_0x596b27, _0x52ea44);
  }
  (function (_0x19db22, _0x39f6b4) {
    const _0x2b2391 = _0x19db22();
    while (true) {
      try {
        const _0xf167da = -parseInt(_0x5bd1(465, '85T5')) / 1 + -parseInt(_0x5bd1(954, '$Eg3')) / 2 * (-parseInt(_0x5bd1(802, 'b^3U')) / 3) + parseInt(_0x5bd1(1151, 'PhmY')) / 4 + parseInt(_0x5bd1(921, 'fabJ')) / 5 * (-parseInt(_0x5bd1(950, 'GU[U')) / 6) + -parseInt(_0x5bd1(1227, '3yTR')) / 7 + -parseInt(_0x5bd1(438, '[e0v')) / 8 * (parseInt(_0x5bd1(790, 'KVZ*')) / 9) + parseInt(_0x5bd1(959, 'fabJ')) / 10;
        if (_0xf167da === _0x39f6b4) {
          break;
        } else {
          _0x2b2391.push(_0x2b2391.shift());
        }
      } catch (_0x5195a7) {
        _0x2b2391.push(_0x2b2391.shift());
      }
    }
  })(_0xa865, 975851);
  function _0x2c1360(_0x230f37, _0x50bbec, _0x562440, _0x2deb0c, _0x466d91) {
    return _0x5bd1(_0x2deb0c - 0x13a, _0x50bbec);
  }
  function _0x4b04c6(_0x485807, _0x164514, _0x50e92a, _0x47f8ce, _0x2aba63) {
    return _0x5bd1(_0x485807 + 0x1f3, _0x2aba63);
  }
  const config = require("../settings");
  const {
    cmd,
    commands
  } = require("../lib/command");
  const {
    getBuffer,
    getGroupAdmins,
    getRandom,
    h2k,
    isUrl,
    Json,
    runtime,
    sleep,
    fetchJson
  } = require("../lib/functions");
  const apkdl = require("../lib/apkdl");
  function _0x4cb8e6(_0x390545, _0x18bfee, _0xcdce3e, _0x57ddb8, _0x1e709f) {
    return _0x5bd1(_0x57ddb8 + 0xe9, _0x1e709f);
  }
  function _0xa865() {
    const _0x34cabb = ['aeiyC8k0', 'pSkVWQdcHmkp', 'FSkuW6C', 'W4ddLXOAW6W', 'W6RcKqu', 'WPeXsa', 'W6awn1GN', 'W6VcG3VcMa', 'ztztW4/cOa', '4BAK4BwbYl7HTjpHTPS', 'WQ4nWQTDnq', 'lrxcNSkbW6K', 'W7RcHMpcMuq', 'W6/cLHRcPa', 'eGHlsa', '8j+rVUkaRFc1SBC2W5JdIdi', 'W5ddLmoBWPPn', 'c8omWPztDW', 'W73dSJu+', 'WPWCW4rFnW', 'W6NdUGCkW4m', 'WRdcH8o0Cvu', 'CMbjW4/cJG', 'pXtcIqVcMG', 'W6v0W7ldRq', 'WOWhW5TPlG', '4BEM4Bs04BEKWQdcHa', 'WRdcOCkrW5nW', 'nGNcH8k1W48', 'W4tdKSohWO9p', 'WP/dS8oTtgy', 'W6m6n8oQoG', 'Y5NHTBZdH+g3Oog2Iq', 'WQWXxmkZjG', 'kSkPWPircq', 'W6SMsq', 'W6hcSaa6Aa', 'AcZdSY0g', 'WRlcOmkiW5n8', 'WOaZWRq9W4e', 'WR0leSomdq', 'WQtcKSoWBvu', 'WPlcKSkpWRdcGW', 'hUg2L+g3H+g2S+g2RW', '4PwFCwqG8l2qUa', 'W4ddLmon', 'W7WoW7xdPa', 'FCMzYyldU+g3Iq', 'W7hdJSoxb0W', 'WPFdVSoBvMq', 'w3nnW6C', 'W6bWW6y', 'Dbq6rmoo', 'WPFcGSk/WR7cNG', 'W5BdT0VcKCkn', 'ca/cJaZcMa', 'Bx4YW5pcOW', 'W6nAFIJdIG', 'WPlcLSkx', '4Ps74PsO4PwM4PAe4PES', 'DNnsW5NcPq', 'YRhcUUg3Nog2SEg2Ra', 'WQKnWRS', 'eWJcHSkIW60', '4Bwm4Bw44BEJqSQa', 'W6xdIN/cI8oq', 'W73dPZCNW5S', 'W4VcKd8VDG', 'W6u6WOinW70', 'WO47WOHApG', 'WQT9WQWOWRe', 'WPVcH8kiWQlcKG', 'WOVdMtycWR8', 'W5hdISokege', 'CrOEEG', 'WQ3dLGuSWOK', 'aL4nyG', 'se0iW6dcRG', 'WOdcLSkEWPnDyCkHgSo/', 'emoiW6BcIuO', 'W7/cKKVcN0C', 'WQ7cNXVcHfu', 'yH3dNqOU', 'tcnzWQPu', '8jQPU/c9Ui7dSJnh', 'DXJcH8kcW6G', 'kCkLWRxcRW', 'oZr/zGa', 'WPJcJmkoW6Pm', 'W41AtG', 'WQDpW4TGW6O', 'qc8Gx8oA', 'W7y1W5v1W64', 'fSkIzSkQ', 'WPKtimo5jG', 'jCkfhfhdJa', 'D0zUW5FdNW', 'WOOJWPHH', 'WOOBW4vxpG', 'W7PpC8kQymojW7BdRSoLW7zai8oY', 'yJLdW4xcOq', 'wxToW6K', 'W4Hhusi', 'xLSvW6xcIW', 'W6BdHwFcL8o0', 'W4y5WRKSW4O', 'i8k5kLW', 'WQr+W5vtW4e', 'sYndWPTp', 'W7FcOHaV', 'B2rz', 'WRFcKSkBWPxcPW', 'W4BWURUc8k+6QVcLUy7WPRUe', 'W7aUW799W5q', 'W6dcSWKeAq', 'WR/dImoyW5VdQG', 'WPnlWO8', 'WORcG8kPW4q', 'AdtdQIa', 'WP/cSmoVC2a', 'WQuFWOyOWQm', 'BJLwW4tcQa', 'CmklW6BdVSoY', 'W4BdGSogWP9N', 'iSk5i3RdMW', 'emk0W6JdMSob', 'lSovWPq', 'WRGOWPq0WRu', '4PwX4Ps34Pw34Psh4PEr', 'W6n0W6VdU8ox', 'tmo/WRtdG8oe', 'rcnj', 'CgKJAW4', 'W6zwEZ3dRa', 'nXb6Bcq', '4PA14PwiWOlcPa', 'lSkKnW', 'lWhcJWVcMW', 'WPG9wW', 'iCkAWQGTaW', 'W7fZWPmLWQi', 'dCkIySkPCG', 'YBhcLEg2Vog1Iog0Gq', 'WOdcJ8kWWO/cJW', 'B8kYl1xdIq', 'vSoUWRpdHSoB', 'ur8JySkI', 'W6RcQqX7Fq', 'qcLpWQbD', 'AYS4zmoA', 'BX58WRrB', 'dmo5WQvEBa', 'lCkjWQm', 'sMb6W4/cMa', 'ESkbE0O', 'WP7cVmoBqgi', 'WQe14PI+WOlIN7S', 'WOvyWO/dS8ou', 'W64KW54', 'W7JdHxJcGCo2', 'W7uJWOW9W7e', 'W6q0ehi0', 'W5FdJSoD', 'WPxcS8kZW73cRG', 'gXRcKaJcOG', 'WOxdSs0vWRG', 'WRTqW4a', 'zHqaFSoj', 'm1W7Dmk4', 'lN5bW5RcVa', 'WPVcICkc', 'DSkWW6FdP8kU', 'YyjH4BsR4BEd4Bsy', 'tLOk', 'aSkQCmkJ', 'WR/cOhb+WOXwsrG8r8oEaSo+xa', 'WR7cLrJcV34', 'WOxcI8kZW4RcNW', 'tXFWOQoIW7fu', 'W5m4qKXE', 'WOddLmoFiW', 'ue8ZW57cNa', 'W6ldRKFcVCow', 'W78fWR8', 'W5BdI2RcLCoY', 'WPq9qe8', 'WQrEW5D5', 'W5ddGSokhWm', 'o8olWPbNuW', 'dSoOWQfBAG', 'W5xdS1tcLW', 'rHqzzmoK', 'W7jmzIe', 'WPBdK8olW7ddIG', 'W6nasJ3dIa', '4BAvY7pQNACr', 'W6THW5DWW6e', 'y3LnW7xcQW', 'zSkCW43dNmkX', 'WQJcGSkGWRNcTW', 'ESkjzv3cUq', '8jEyVVcwURmy8jw7PpcPUAK', 'W5CNbw0y', 'W6zDvIBdGa', 's10vW6W', '4BAcfog0Mog1Jmkn', 'WR3dI8oNW6e', 'W50/x1fc', 'A0qdW6xcNW', 'yJddTcy', 'bmkEWQSUgW', 'W6ddVmoqWRW8W4dcLYnSW4LZBCoEEG', 'W5xdHSofe0G', 'WPGpW7nXhG', 'jWxcGG', 'W7tdKJuyW40', 'mSkjWRpdNau', 'WQuvzw5t', 'k1pcJmkaW6e', 'WRxdG8oLWRJdNW', 'W78IWRa5W4G', 'WR/HT67HTAZdRmQQ', 'jmo2puddJG', 'W6ZcIGFcQ18', 'WQlcQSklW6Hi', 'lSk0WQlcQCkm', 'i8oDWP9WvW', 'x1yzy8kJ', 'WOnkWPddU8od', 'n3G4u8ku', 'Yz7dR+g3VUg2Icu', 'W6jMCqDb', 'W7RdTJ06', 'WPFcOmojrwa', 'WONcMCkqteziW5tcLIhcVW', 'W4HyWPpdSq', 'W5pdJSoeWP5e', '4PAJ4PA24PAS4PAb4PAJ', 'WR8yWOOkWRS', 'W7pcKaBcJ3y', '4Bs14BsyYyRiGUg2Jq', '8lIGHMpdHJRdQW', 'C8kwW6u', 'W5hdGxVcMq', 'aH5rW6lcIa', 'xKKiW4hcIa', '776F776j77Y577+tWRC', 'qIvCWQuv', 'WRhcSHpXG7c/hG', 'zvLKW47cRq', 'emo+WQRdMCom', 'W6JcK2BcLgG', 'iCozWPXY', 'zHqzzmoK', 'W5nWWQeWW5q', 'WP/cQGhdMpc6OAi', 'W6L+xqbb', 'W5NcO8kUWOpcVa', 'YP824BsKYkxjLq', '6P6Ju+QDP+g0Vog1KW', 'kCkmuCkv', 'AeNdNmoBWRHPW64bfWldI2e', 'W7j4W7ddRa', '4PA24PwP4PAZ4PEk4PE0', 'gIH7AqS', 'W6FcH8kjW5Oa', 'mrxcNmki', 'kCoxWP5JrG', 'WOHscmoC', 'WO4QxuHF', '8y2aTEkdTVcVKAVdGmk6', 'mmkLWR/cUmkb', 'WQddTYGHW5e', 'o8kEWRK+dG', 'Bh9oW4e', '6P6ZYl/HTj/HT4r3', 'fI1LuJ4', 'jYjdvG4', 'W7hcGGtcQr0', 'WP/cJ8ksWRO', 'W7RdHmoZW7FdSa', 'WOhdUZrQWR8', 'W6BdOaO7W7K', 'W7yKW4i8W6K', 'iLmzCmk8', 'v2DuW7BdOG', 'W58ksJ91', 'WRWVWPC', 'W78qa2W0', 'W4WzW6NcKmo7', 'W5NdJSogWPa', 'YzhHT4JHT6dcRmQC', 'WQNdLSoZW7hdSW', 'W7CHsCkSiW', 'WORdM8ofW7VdQa', 'WPm/qKq', 'W48XWRfPW70', '4PEg4PwS4PEF4PsU4Pwu', 'W7RcRHNcPx8', 'Amkzve7cSa', 'tHGduSoo', 'WPzyWPFdRSob', 'W5K1WPOyW40', 'W7ipxmkegW', 'qJRdScSd', 'kCkiAKRcPq', 'nCkLl1xdKG', 'W6JdIehdMhnsW6pdNxpdUW', 'WQRdRWOIWOK', 'Y7BHTlNHTjJHTy7cLW', 'W7T0W6VdVmot', 'v35bW57cVW', 'WO0qmSo2oq', 'WPOhW65xdq', 'cdTgWQvm', 'W7hdP0L6nG', 'W7hcOGK4Aa', 'W6RcTbW', 'WRzpW4W7', 'WP3WPjk34OcJ8kQrLZBVV7JVV6K', 'jW1Jusq', 'z0H2W4BdNq', 'WPFcICklWR/cNW', 'WR/cQCkkWQW', 'W7hcGGtcQq', 'W4qYhhib', 'W6/dT8odWP56', 'oCkAWQWPhW', 'W45hWR/WVzgt', 'W5iPW4zOW7m', 'h8kEWQevgW', 'WQxHTz3HTR/HTjNHTOa', '4PA14PAG4Psl4PEY4PAx', 'W6H6W6RdPmos', 'W4abCW', '4PAG4Pwq4PEv4Pwj4PAK', 'WOmuWOldQmoh', 'W5CBFxn+', 'WOrAW4TSW6O', 'W4C/WQCW', 'mtv1', 'qKjUW7/cNG', 'W7NcJGtcO1C', 'u0eqW6e', 'WP7cICky', 'eemezSkH', 'nrxcHmkg', 'tYviWR0', 'lmozWOvYra', 'WQ7HTPBHTylHTA7HTRi', 'B8kyW6hdPSk5', 'W73dT1ZcHSo9', 'fxfbW7BdQa', 'WQy8WP8', 'nvGaACk9', 'WR3cOmkc', 'oaxcTCkzW6K', 'W6z0W7hdRmo6', '4BsZ4Bwl4BsRW74y', 'auieBW', 'W6hdPZ8ZFq', '4PA24PEo4Psq4PsA4PAo', 'pmozWOfN', 'W5CkahyK', 'W6zwyIFdGq', 'a1iwzmkL', 'W4u5bh00', 'WRpdKCoJW53dTq', 'xCkTW4W', 'WPRcMfxcT3a', 'yCoCWPX4rW', 'W6FdPmoGW5eG', 'WPFcJmojqwS', 't0qdWQtdGq', 'WQxcQSkDW7G', 'W7xcJqpcHgi', 'WQRcTCkOWP7cOq', 'gfOwymk0', 'ysjiWQSy', 'W482W7uOW5q', '4PEuW41c4Psk8jILUG', 'W7hcSMdcUMG', 'W43HTRxHTQNHTz8K', 'nmkTWQZcVmkm', 'W6XyEcW', 'nX3cH8ki', 'jqxcRsZcPa', 'y2jjW4xcOG', '8l6FS8kT4PQ9WQddMa', 'W5tdL8obW5yD', 'W71QW4SmWORcQ8klW6VdOa', 'pWxcLqBcTG', 'j3y9tSkd', 'WO3dQmotW57dUG', '4Pwp4PAP4PEs4PED4PAi', 'fog2UUg3H+g2VmUc', 'W7RdR2pcU8ou', 'qK0PW5xcHq', 'WOvwWO7dHCod', 'ptnTwbi', 'W6VcVqyvsG', 'WORdTY4H', 'wYLpWRzB', 'Y57kNmQT4BAS4BwG', 'lCksWQSTfG', 'emkuW7GkeG', 'W67dPZ8ZFq', 'DSkkW7y', 'vmosWQRdS8oo', 'k8oJuSkvra', 'W60zqIhdJa', 'pahcJXBcKq', '4Pwz4Pw84PEQ4PET4PAm', 'WQ7cGmkUW7RcOq', 'WPldUZG+', 'W5JdIVgoOyRdMa4', 'W7ZcGH3cPvW', '8ysMQ++6Uq', 'W6PCDc3dIa', 'W5JcNCoFqwm', 'dCoUD8kQEG', 'EwS3W4VcIG', '4PEM4Ps54PEJ4PAA4PAK', 'pmoDWP9ZBG', 'W7fCEY3dOa', 'FmooWOK', 'WOpdVtrQWR8', 'W74Aofa', 'W60aW6hdRq', 'WOldGSozjNa', '4BEY4BEzY5dkPog0HW', 'WQSLW4zSW6S', 'W6BdTIqQW5a', 'W5ZdU1/cIW', 'W60GW5nVW6e', 'jCksWRy2', 'wqCaW7hcGG', 'WPlcHCko', '8lwBKSo18k+lLpcvMQVWSRIZ', 'p8kwWPj4tG', 'WPVdKCoxlg8', 'W7OaWR4SW7q', 'ESkAW7BcRCk5', 'BmkCW6ZdQCkv', 'uCo7WQm', 'CmozW5xdPCk5', 'WRNdLSoGW4FdQa', 't8ojnSoW8jUHTG', 'mSkHWQNdU8ki', 'WPlcJ8k/W5S', 'FmooWONdO8o6', 'WQvOWQ3dLmot', 'D1ldGa', 'WQFdJHagWPC', 'rdqHxSon', 'WQTqjmoOpG', 'W7tcL2ZdKg0', 'W4xcIcCpwq', 'jCkXowddOa', 'W6XfW4ZdKCo4', 'WP3cSSoE', 'WRBdJCoM', 'W7GCguKx', 'W6D8W7hdOW', 'W5iuW6hdVMa', 'lrdcJ8onWQe', 'W5JXIAUn8jszT/goU6/WSBUC', 'i8kfWQi', 'kSkpWRKcdW', 'W41EtsD1', 'W5jWW7rOWO4', 'W4FcLCk78k6KK24', 'lZjJCWi', 'pSkVWQdcHmkE', '4PA84PAR4PAK4Pw04PsT', 'WQddKmoOW6hdIq', 'W4muwa0', 'WOroWOVdU8oq', 'fJpcGSkKW48', 'W5RdHmolaeG', 'WR46WR4hWPC', 'WRdcTSoorsC', 'W50/x0Or', '4PAs4PwZ4Pww4Ps74Pwt', 'WPldOmoGW7pdKW', 'W7tcHHa', '4PIu4PAs4Ps54PEY4PEL', 'W7FcTbdcHxW', 'w8kBW47dUmkx', 'WPr+W7naW4y', 'WQNILkJILAJILzVILjW', 'WQ7dLSoOW7BdUG', 'W73jPEg1TEQFKEg0GW', 'pmk0WOlcLSkV', 'WOBcOmoBvhC', 'psz8CW4', 'W7FdPWy+AW', 'emo7WRFdNCkA', 'W5i1WRqQW5a', 'W6xdI8onWPPz', 'ESkMW7hdQmk0', 'WR3cTCkTWP7cIG', 'WOqnW48', 'mbCNs8kq', 'yWSEzSoH', 'W4JdT1FcLSkO', '8j+2Uo+5Oq', 'bemdAmk/', 'kmklWRm', 'WRBcO8kRW6ZcRa', 'rY1kW6r+', 'WP3dICkkWR/cLW', 'W4xdJmkiWPje', 'WQpcQSkeW69X', 'BZJdPIik', 'bv4dA8k0', 'j8keAKRcVG', 'WQNdMSogkwG', 'ihvbW57cQq', 'W4fDvIDX', 'WQNcIq0+Ea', 'WQW+WO8', 'WOWjW4jtpG', 'WOjCWPddUq', 'tWfSW7FkHG', 'wvn0W77cUq', 'j8kAWRu4', 't8oYWQBdNmok', 'WQ40WP05', 'ltn+BGK', '8yoWM8kA4BsK4BsF4BEw', 'hLytj8kw', '4Psy4PsW4PAR4PsY4PAK', 'W7aWxmkGoq', 'eaTdrIm', 'zWGDA8oV', 'WRPiW49OW70', 'oSokWP0', 'W4W/WRqTW5C', 'W68uW77dQuC', 'WPKBteDG', 'W7ddP8otW4RdKG', 'WO0RxeK', 'W7e8r8kM', '4P+Fu1ZWKB+HWQS', '4BAU4BAN4Bsl4BE/WRC', 'WRX14P2W4PMS4Pwn', 'kCorWP1Ytq', 'YOZHT67HT4dcHCoY', 'bqRWKlcU4Oci8jcHJSkh4BEx', 'WRtdMSkregW', 'FSkjW7ldOCkX', 'W6CYW7uEW4W', 'W7FdT0BcNSov', 'WPpdQJqLWRa', 'wNLvW6pdVq', 'iLiBySkY', 'WPpcNSkZW4dcLG', 'W6ZcLXVcPv0', 'W7ZcJatcK1u', 'W4LTrqBdPq', 'WPBcSU+8J8ohW4u', 'WO3cPG3dH8k9DvLKrCoy', 'W6ZdOSo8WQ9F', 'WPy7vG', 'pXdcLWVcGa', '4Pwp4PA44PEX4Psx4PsJ', 'W40MjfDZ', 'W7LWW77dQ8oc', 'p8kyW7ldPSo4', 'WOFdQJmRWQ4', 'EthcRSonW40', 'W4FcQcpcG1e', 'W4X8WRhdImoR', 'WOSjWQXDnq', 'W5BdMa8bW5C', 'EEg1Vog3SUg3TCkS', 'WOlcJ8k0W4W', 'g8k2WPJcI8kL', 'ue0F', 'CtWBAmoT', 'W53cH8kmWRRcMG', 'WRnqW5bNW6u', 'WPK7xei', 'W4WXWQy9W5e', 'j8kCWQBcIdC', 'bYasWRdcVen3W4tcKCkzaG', 'WOeOeSoSpW', 'W4Tdwd8', '4PEV4PwO4PA2', 'imoUrCkFuG', 'W7S+W6ldUe4', 'DHqTB8op', 'WRxcL8omv08', 'nSkcWQxcLSkR', 'CmkoW6RdRmkS', 'tCkpFftcUq', '4PEZ4PEM4PE84PEr4PEZ', 'WO7cOW/cMSksvNXeAW', 'W5ddT0a', '4Bwp4BEWYzJHTQ9a', 'pZNcJZdcOG', 'W7jYW5FdVmos', 'ASkkW6C', 'W6tcRG4I', 'DmooWOxdG8oy', 'uSoZWQNdNq', 'WPZdJ8kHW4/dTq', '8yA3UU+7Ra', 'W4e+WQewW5e', '4PAb4PAF4PA14PEC4Pwv', 'WOBcVmo5qua', 'rNSaW73cPa', 'WP/dKmoqjha', 'CgntW4i', 'BmktEfVcSG', 'WRyhW7/WLlkX', '4PsF4PE54PAc4PAn4PEy', 'WQ9iW45EW5e', 'WR/cLrhcMq', 'WPjvW7bnW5a', 'WRefW77dQKW', 'ACkDW6tdPSkZ', 'W7NdKsqHW6W', 'W6C2sCoJla', 'W77cLYBcGxu', '4PAC4Ps84PAp4Pw+4Pse', 'WRbpWR7dSuS', 'WQlQNAtjL+g3OEg1IG', 'nSknWR/dNa', 'W6xcRGq+CG', 'W7RdJCoNf1u', 'pSkVWQdcHmkq', 'WRS4WPOJWQq', 'BrOkkSok', 's8oToCkPDG', 'W5NcK3ZcKqO', 'zCkzAMNcTW', 'ACoXW7H3oW', 'WReQWPixWOG', '4PAF4PEJ4PwP4PEm4PsZ', 'lCkjWQpcIae', 'WQjDEJ7dGW', 'WOdcG8ksWRxcVG', 'FCkfk1VdTq', 'W6KgW5tdMMu', 'nrxcHmkgWQi', 'A8kkW6pdVCkO', 'WQZdV8o4fuu', 'W7LJW7BdRCo0', 'lsz8DW', 'WP4+WP5LiW', 'gXnFusW', 'WQedWQ1x', '4PwU4PEk4PAx4PEM4PE4', 'zIxcIrdcMW', 'amkWzCk7Da', 'W6DkzIJdIG', 'WR3dVSo1cYq', 'WQ7dMGhcMwG', '8yIaLLxdIKXF', 'Dmoz8l+XHW', 'W7BdSuxcVmoG', 'vh9f', 'WOdcG8kRW4RcLG', 'WQ3cMWhcLh0', 'W5BdPvhcK8kr', 'l8k3i0a', 'lCopWPL2vW', 'zN9mW4/cOG', 'zbqbFSoT', 'C34hW6RcIq', 'W7ldUfZcQ8kv', 'gcjFtbu', 'kudcJbdcNq', '4Ocz4BsL4Bw6YjVHT7C', 'mtbKzHm', 'WOWpW5VWR5c1', '8yclTW8lEeu', '4PA14PAG4Psl4PEY4PI4', 'bWJcVqBcUa', 'W7BdV8olahG', 'jSkbWRtdMaW', 'v0Cb', 'W6ztof4K', 'BSo2WQldL8oB', 'WRXDEuSY', 'W7VdN8oTWQLz', 'lmkjWQRdJq', 'lCkWWQhcSSkk', 'wSojWPxdGSog', 'W6D1tSkMiq', 'zttdSYai', 'W43dPYWusW', 'WRNcRSkrW79K', 'wLGnWQtcIa', 'WOldKCoc', 'YlVlMSQBYApHTkq', 'ESk0W7ldPmku', 'W78epLON', 'tYWawSo/', 'AmoYW7/dR8oACgzVW5/dVtzWBHi', 'W7/dVu7cNmkj', 'i8kZWRuyha', 'zYxdTW', 'jSk5pfW', 'wh1e', 'WRjCW5m', 'cCo3WR5dzG', 'y3LnW7xcUW', 'tfLNW6u', 'zSkkW7BdOSkQ', 'W7vrDd3dNG', '8yIeUE+5UG', 'WP4XqN5w', '4PAG4PU/4P6y', 'WORdQCkSW5ZdKG', 'WPOEcNnDDmkaW4lcK8kw', 'WONdQs4MWRe', 'oXpcJSku', 'dYxcHSkoW7q', 'W79MW77dUmog', 'W79nCSkUeSkJWO3dOmobW5S', 'W78vW6ldVfi', 'g8oOWQvXya', 'WR7cRSkbWQXd', 'WR/dR8oNa1q', 'bI1EWQ8y', 'W4ZdOmoNWQxIL7G', 'W60eW7/dUw8', 'W60IvCkIoq', 'WP/cH8kI8ygKVsK', 'tcnaWRb5', 'WOpcK8kpWRK', 'W73cJs3cMxW', 'C3DqW5O', 'CcnHAam', 'B3DeWORcLq', '8l2QVmk/WQldV8ol', 'W5OoW6BdS04', 'jCkbWQhdKq', 'WOhcVrBcHmke', 'YyNHTBVlMCk44Bws', 'WPZdPSoGvgW', 'pINcLbVcNG', 'W53dM8ou', 'kColWRxcU8kFsstcJavQ', 'mCkVWRldIGu', 'sYndWPTb', 'W63cHGJcR0C', 'uCo0jSkwsCo1W5yoW70', 'WO3dUZK', 'pZndsIe', 'WOpcMCk0W47cNW', '8y67HCo/tJtdHG', 'WPKydhi2cSodWPFcKmkjdWfcWQi', 'WRlcJmktW4ZcRq', 'WOddTYWVWRa', 'W7maW7/dUw4', 'WR7dI0BdKNK', 'WRO4WPuKWP0', 'WOeOWQLDha', 'W4FdSmodnwS', 'cc1EWQ8y', 'W4VdP0RcMG', 'WRujWRfkgq', 'se0iW6dcOq', 'dCkIzSkQAG', 'WR1Fk8o9iG', 'xuCjW7dcIq', 'WRFdH8oZW7VdTq', 'eJBcQmkRW4i', '4BEg4Bs54BEPY7diPa', 'WRrRWPVcT/cxSze', 'YQRHTj3HTlJHTOxiJq', 'W695W7pdOCoy', 'WQuqiG', 'W5NdIwxcMq', 'oaJcG8kcW6i', 'mCkDW6/dOSk8', 'W43dNSolaeG', 'oCkoWQS1', 'WQ7dI8o1W7tdUa', 'W7dcK3e', 'zhLxW4tcOa', 'mCknWQBdMGm', 'wNTeWQZdVq', 'DL1TW4/dJa', 'WOxdSs0vWRK', 'WO7dICoPW5tdQW', 'W5tdISon', 'WPuLW6X/ka', 'rY1k', 'z8khkWddVq', 'k8kfWQBdJWu', 'kJrTDXC', 'bSkTWPxcGMO', 'WRdcRmkoW61I', 'kmkYWQe', 'sL0pW6FcHW', 'yW8DA8o4', 'CJddVZe', 'W7/cQ8kiW6nH', 'W6/cGH3cUfy', 'WQSGW4L4W7i', 'W4NdMmob', 'kUg0JUg0R+g2I+g3IW', 'W5nlFrhdVG', 'C3noW47cGq', 'W5lcGedcTKa', 'WPxdMbG5WRC', 'wMbz', 'WPHjW6XMW6G', 'cSkQCSo0yW', 'CCkkW4NdPCk5', 'femwj8kg', 'WQ5sW4HT', 'WR7dI8oYW6JdSq', 'j8kBWRtdIqC', 'B8kmW7hdPq', 'WRxcRSkrW60', 'W5tdLglcNCo5', '8lIGJ0NdPMFcOG', 'WPvqWO3dVCoi', 'uJybWOVdPG', 'W61GDXre', 'WPxcI8k3W58', 'W5azngJcHW', 'W5pcLSkqWRdcIG', 'WQlcU8kxW6vR', 'W7n/tcOL', 'l1VVVypVVk7cQa', '8yg5M8kA8jszU/goU67WSBUq', 'WOJHTz3jJgdcNG', '4PED4PE64Pw14PEG4Psy', 'WRVdTmo7dLy', 'sSo/WR/dGG', 'WQeAjmo8ma', 'CYBdOG', 'WPZdTmoobge', 'WRtdG8oSW70', 'FCkjF1BcSa', 'WQXtWQpcRXpdHSoGWQtdVa7cNW', 'W70FWQ0dWQm', 'zr4AkSoP', 'WPWWw35e', 'W6iOW4fL', 'W7DzW6KyymoBtmkfWRRdO8ouoa'];
    _0xa865 = function () {
      return _0x34cabb;
    };
    return _0xa865();
  }
  if (config.COMMAND_TYPE === "button") {
    const _0x151be0 = {
      pattern: "happymod",
      react: "🗃️",
      desc: "Download apk in happymod",
      category: "download",
      use: ".happymod",
      filename: __filename
    };
    cmd(_0x151be0, async (_0x33abaf, _0x3c7aad, _0x524d02, {
      from: _0x3dc651,
      q: _0x1f429c,
      pushname: _0x251759,
      reply: _0x3f3f61
    }) => {
      try {
        const _0x3c8b52 = require("caliph-api");
        const _0x4b8be8 = await _0x3c8b52.search.happymod(_0x1f429c);
        const _0x35a6a3 = [];
        for (let _0x5112b0 of _0x4b8be8.result) {
          _0x35a6a3.push({
            'header': _0x5112b0 + 1,
            'title': '' + _0x5112b0.title,
            'description': "📬 *Title - " + _0x5112b0.title + "* \n🔗 _Url : " + _0x5112b0.link + '_',
            'id': ".dapk " + _0x5112b0.link + _0x1f429c
          });
        }
        const _0x576846 = {
          display_text: config.BTN,
          url: config.BTNURL,
          merchant_url: config.BTNURL
        };
        let _0x228c6a = [{
          'name': "cta_url",
          'buttonParamsJson': JSON.stringify(_0x576846)
        }, {
          'name': "single_select",
          'buttonParamsJson': JSON.stringify({
            'title': "Select news types",
            'sections': [{
              'title': "Please select a category",
              'highlight_label': "X-BYTE",
              'rows': _0x35a6a3
            }]
          })
        }];
        const _0x3e1f88 = {
          image: config.LOGO,
          header: '',
          footer: config.FOOTER,
          body: "> ❍⚯────────────────────⚯❍ \n🎲 *𝙷𝙰𝙿𝙿𝚈 𝙼𝙾𝙳𝚂 𝙰𝙿𝙺 𝚂𝙴𝙰𝚁𝙲𝙷 𝙻𝙸𝚂𝚃*  🎲\n⚡ *x-byte Happy ᴍᴏᴅꜱ ꜱᴇᴀʀᴄʜ ᴇɴɢɪɴᴇ* ⚡\n❍⚯────────────────────⚯❍"
        };
        return await _0x33abaf.sendButtonMessage(_0x3dc651, _0x228c6a, _0x524d02, _0x3e1f88);
      } catch (_0x51e0f9) {
        _0x3f3f61("*Error !!*");
        console.log(_0x51e0f9);
      }
    });
    const _0x30318e = {
      pattern: "fmmods",
      react: "🗃️",
      desc: "get applications",
      category: "download",
      use: ".fmmods",
      filename: __filename
    };
    cmd(_0x30318e, async (_0x4e3afd, _0x2154d1, _0x26b4aa, {
      from: _0x4e7edf,
      q: _0x484ba6,
      pushname: _0x4550ab,
      reply: _0x47edda
    }) => {
      try {
        let _0x4da396 = (await fetchJson("https://X-BYTE-api-7967fdc132a8.herokuapp.com/downloader/fmmods")).data;
        const _0x203fcb = [];
        for (var _0xd92531 = 0; _0xd92531 < 1; _0xd92531++) {
          _0x203fcb.push({
            'header': '',
            'title': "Beta Whatsapp",
            'description': "Download Beta Whatsapp",
            'id': ".dmod " + _0x4da396.com_whatsapp.link + '+' + _0x4da396.com_whatsapp.name
          });
          _0x203fcb.push({
            'header': '',
            'title': "Fm Whatsapp",
            'description': "Download Fm Whatsapp",
            'id': ".dmod " + _0x4da396.com_fmwhatsapp.link + '+' + _0x4da396.com_fmwhatsapp.name
          });
          _0x203fcb.push({
            'header': '',
            'title': "Gb Whatsapp",
            'description': "Download Gb Whatsapp",
            'id': ".dmod " + _0x4da396.com_gbwhatsapp.link + '+' + _0x4da396.com_gbwhatsapp.name
          });
          _0x203fcb.push({
            'header': '',
            'title': "Yo Whatsapp",
            'description': "Download Yo Whatsapp",
            'id': ".dmod " + _0x4da396.com_yowhatsapp.link + '+' + _0x4da396.com_yowhatsapp.name
          });
        }
        const _0x49874d = {
          display_text: config.BTN,
          url: config.BTNURL,
          merchant_url: config.BTNURL
        };
        let _0x22cfcf = [{
          'name': "cta_url",
          'buttonParamsJson': JSON.stringify(_0x49874d)
        }, {
          'name': "single_select",
          'buttonParamsJson': JSON.stringify({
            'title': "Select news types",
            'sections': [{
              'title': "Please select a category",
              'highlight_label': "X-BYTE",
              'rows': _0x203fcb
            }]
          })
        }];
        const _0xdd47b = {
          image: config.LOGO,
          header: '',
          footer: config.FOOTER,
          body: "> 📥 X-BYTE APKDL 📥\n\n\t APPLICATION DOWNLOADER 📥"
        };
        return await _0x4e3afd.sendButtonMessage(_0x4e7edf, _0x22cfcf, _0x26b4aa, _0xdd47b);
      } catch (_0x165fa2) {
        _0x47edda("*Error !!*");
        console.log(_0x165fa2);
      }
    });
    const _0x3ab1f1 = {
      pattern: "dmod",
      dontAddCommandList: true,
      filename: __filename
    };
    cmd(_0x3ab1f1, async (_0x9fe009, _0x157c78, _0x16e428, {
      from: _0x1d03a5,
      l: _0x3ffa4f,
      quoted: _0x33270e,
      body: _0x486aae,
      isCmd: _0x30037d,
      command: _0x4ebce6,
      args: _0x3db76b,
      q: _0x34e2aa,
      isGroup: _0x207be2,
      sender: _0x1718ec,
      senderNumber: _0x215676,
      botNumber2: _0x1b0313,
      botNumber: _0x40a02a,
      pushname: _0x217aec,
      isMe: _0x6d53,
      isOwner: _0x12675d,
      groupMetadata: _0x126b46,
      groupName: _0x41f7ba,
      participants: _0x1b0004,
      groupAdmins: _0x16537f,
      isBotAdmins: _0x4c25d6,
      isAdmins: _0x4ee3a0,
      reply: _0x440156
    }) => {
      try {
        const _0x257803 = {
          text: '📥',
          key: _0x157c78.key
        };
        const _0x38ce83 = {
          react: _0x257803
        };
        await _0x9fe009.sendMessage(_0x1d03a5, _0x38ce83);
        let [_0x226f5b, _0x2dc8f7] = _0x34e2aa.split`+`;
        const _0x12b41c = {
          url: _0x226f5b
        };
        const _0x458db1 = {
          quoted: _0x157c78
        };
        await _0x9fe009.sendMessage(_0x1d03a5, {
          'document': _0x12b41c,
          'fileName': _0x2dc8f7 + ".apk",
          'mimetype': "application/vnd.android.package-archive"
        }, _0x458db1);
        const _0x2adef0 = {
          text: '✔',
          key: _0x157c78.key
        };
        const _0x22d3a5 = {
          react: _0x2adef0
        };
        await _0x9fe009.sendMessage(_0x1d03a5, _0x22d3a5);
      } catch (_0x39b4be) {
        _0x440156("*ERROR !!*");
        _0x3ffa4f(_0x39b4be);
      }
    });
    const _0x401d6c = {
      pattern: "apk2",
      react: "🗃️",
      desc: "get applications",
      category: "download",
      use: ".apk2 whatsapp",
      filename: __filename
    };
    cmd(_0x401d6c, async (_0x207362, _0x1bb7e4, _0x31bdee, {
      from: _0x4b66a2,
      q: _0x26b0ef,
      pushname: _0x4a19a3,
      reply: _0x20247f
    }) => {
      try {
        const _0x26a2c5 = await apkdl.search(_0x26b0ef);
        const _0x586c35 = [];
        for (var _0x3f3204 = 0; _0x3f3204 < _0x26a2c5.length; _0x3f3204++) {
          _0x586c35.push({
            'header': _0x3f3204 + 1,
            'title': '' + _0x26a2c5[_0x3f3204].name,
            'description': '',
            'id': ".dapk " + _0x26a2c5[_0x3f3204].id
          });
        }
        const _0x4b08b8 = {
          display_text: config.BTN,
          url: config.BTNURL,
          merchant_url: config.BTNURL
        };
        let _0x928414 = [{
          'name': "cta_url",
          'buttonParamsJson': JSON.stringify(_0x4b08b8)
        }, {
          'name': "single_select",
          'buttonParamsJson': JSON.stringify({
            'title': "Select news types",
            'sections': [{
              'title': "Please select a category",
              'highlight_label': "X-BYTE",
              'rows': _0x586c35
            }]
          })
        }];
        const _0xd8d206 = {
          image: config.LOGO,
          header: '',
          footer: config.FOOTER,
          body: "> 📥 X-BYTE APKDL 📥\n\n\t APPLICATION DOWNLOADER 📥"
        };
        return await _0x207362.sendButtonMessage(_0x4b66a2, _0x928414, _0x31bdee, _0xd8d206);
      } catch (_0x310746) {
        _0x20247f("*Error !!*");
        console.log(_0x310746);
      }
    });
    const _0x2bbb0c = {
      pattern: "apk",
      react: "🗃️",
      desc: "apk download.",
      category: "download",
      use: ".apk whatsapp",
      filename: __filename
    };
    cmd(_0x2bbb0c, async (_0x3a6694, _0x421633, _0x38253e, {
      from: _0x3fb80e,
      q: _0xc8c099,
      pushname: _0x47e1fd,
      reply: _0x3254d8
    }) => {
      try {
        const _0x123a3c = {
          text: "*Need apk name...*"
        };
        const _0x57f8ac = {
          quoted: _0x421633
        };
        if (!_0xc8c099) {
          return await _0x3a6694.sendMessage(_0x3fb80e, _0x123a3c, _0x57f8ac);
        }
        const _0x29a54b = await apkdl.download(_0xc8c099);
        let _0x2f1e08 = "[X - B Y T E]\n*APK-DOWNLOADER*\n\n *📚 ᴀᴘᴘ ɴᴀᴍᴇ: " + _0x29a54b.name + "*\n *📈 ᴀᴘᴘ ꜱɪᴢᴇ: " + _0x29a54b.size + "*\n \n─────────────────────────────";
        let _0x39cd70 = [{
          'name': "cta_url",
          'buttonParamsJson': JSON.stringify({
            'display_text': "see in playstore",
            'url': _0xc8c099,
            'merchant_url': _0xc8c099
          })
        }, {
          'name': "quick_reply",
          'buttonParamsJson': JSON.stringify({
            'display_text': "Download apk 📥",
            'id': ".dapk " + _0xc8c099
          })
        }, {
          'name': "quick_reply",
          'buttonParamsJson': JSON.stringify({
            'display_text': "Info of apk 📊",
            'id': ".apkinfo " + _0xc8c099
          })
        }];
        const _0x41b591 = {
          image: config.LOGO,
          header: '',
          footer: config.FOOTER,
          body: _0x2f1e08
        };
        return await _0x3a6694.sendButtonMessage(_0x3fb80e, _0x39cd70, _0x38253e, _0x41b591);
      } catch (_0x1e418d) {
        _0x3254d8("*Error !!*");
        console.log(_0x1e418d);
      }
    });
  }
  const _0x4ecc38 = {
    pattern: "dapk",
    dontAddCommandList: true,
    filename: __filename
  };
  cmd(_0x4ecc38, async (_0x35f9a1, _0x5e0337, _0x5ab8ad, {
    from: _0x3925e2,
    q: _0x481907,
    reply: _0x4267e3
  }) => {
    try {
      const _0x3bdf4b = {
        text: '📥',
        key: _0x5ab8ad.key
      };
      const _0x262a69 = {
        react: _0x3bdf4b
      };
      await _0x35f9a1.sendMessage(_0x3925e2, _0x262a69);
      const _0x3fe63b = {
        text: "*Need apk link...*"
      };
      const _0x74fee7 = {
        quoted: _0x5ab8ad
      };
      if (!_0x481907) {
        return await _0x35f9a1.sendMessage(_0x3925e2, _0x3fe63b, _0x74fee7);
      }
      const _0x4fd22c = await apkdl.download(_0x481907);
      const _0x4c5a40 = {
        url: _0x4fd22c.dllink
      };
      const _0x2d8466 = {
        quoted: _0x5ab8ad
      };
      let _0x883089 = await _0x35f9a1.sendMessage(_0x3925e2, {
        'document': _0x4c5a40,
        'mimetype': "application/vnd.android.package-archive",
        'fileName': _0x4fd22c.name + '.' + "apk",
        'caption': "*X-BYTE POWERED BY TALKDROVE \nCreated by Hamza*"
      }, _0x2d8466);
      const _0x2bac2f = {
        text: '📁',
        key: _0x883089.key
      };
      const _0x39fc41 = {
        react: _0x2bac2f
      };
      await _0x35f9a1.sendMessage(_0x3925e2, _0x39fc41);
      const _0x3d8e7a = {
        text: '✔',
        key: _0x5ab8ad.key
      };
      const _0x407c0a = {
        react: _0x3d8e7a
      };
      await _0x35f9a1.sendMessage(_0x3925e2, _0x407c0a);
    } catch (_0x4476fa) {
      _0x4267e3("*ERROR !!*");
      l(_0x4476fa);
    }
  });
  const _0x528fbc = {
    pattern: "apkinfo",
    dontAddCommandList: true
  };
  function _0x173f25(_0x2bf392, _0x248188, _0x357167, _0x2c7958, _0x40f020) {
    return _0x5bd1(_0x40f020 + 0x8c, _0x357167);
  }
  _0x528fbc.filename = __filename;
  function _0x5e6bef(_0x3e2247, _0x55ab80, _0x194029, _0x4bd21f, _0x257f65) {
    return _0x5bd1(_0x194029 - 0x2d6, _0x55ab80);
  }
  cmd(_0x528fbc, async (_0x2aab4e, _0x2d0370, _0x55b4bf, {
    from: _0x4e3348,
    q: _0x1de7c0,
    reply: _0x4f7ca9
  }) => {
    try {
      const _0x5a70a1 = {
        text: 'ℹ️',
        key: _0x55b4bf.key
      };
      const _0x4cce43 = {
        react: _0x5a70a1
      };
      await _0x2aab4e.sendMessage(_0x4e3348, _0x4cce43);
      const _0x55a5e6 = {
        text: "*Need apk link...*"
      };
      const _0x4a0b3a = {
        quoted: _0x55b4bf
      };
      if (!_0x1de7c0) {
        return await _0x2aab4e.sendMessage(_0x4e3348, _0x55a5e6, _0x4a0b3a);
      }
      const _0x3228f7 = await apkdl.download(_0x1de7c0);
      let _0x5b2fcb = "╔═══════════════════╗\n*║🤳X-BYTE PLAYSTORE-SEARCH*\n╚═══════════════════╝\n\n*📚 ᴀᴘᴘ ɴᴀᴍᴇ: " + _0x3228f7.name + "* \n\n*📈 ᴀᴘᴘ ꜱɪᴢᴇ(ᴍʙ): " + _0x3228f7.size + "*\n\n*📱 ʟᴀꜱᴛ ᴜᴘᴅᴀᴛᴇᴅ: " + _0x3228f7.lastup + "*\n\n*📦 ᴅᴇᴠᴇʟᴏᴘᴇʀ: " + _0x3228f7["package"] + "* \n\n_*◯──────────────────────────────────◯*_";
      const _0x5bfabf = {
        url: _0x3228f7.icon
      };
      const _0x4da354 = {
        image: _0x5bfabf,
        caption: _0x5b2fcb
      };
      const _0x2d9f7b = {
        quoted: _0x55b4bf
      };
      await _0x2aab4e.sendMessage(_0x4e3348, _0x4da354, _0x2d9f7b);
      const _0x214e2f = {
        text: '✔',
        key: _0x55b4bf.key
      };
      const _0xf516a7 = {
        react: _0x214e2f
      };
      await _0x2aab4e.sendMessage(_0x4e3348, _0xf516a7);
    } catch (_0x7b7847) {
      l(_0x7b7847);
    }
  });