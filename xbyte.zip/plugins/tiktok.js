

(function (_0x10065b, _0x2e2791) {
  const _0x18d18b = _0x10065b();
  while (true) {
    try {
      const _0x24d20a = parseInt(_0x2c54(372, '$$HG')) / 1 * (parseInt(_0x2c54(861, 'i2v$')) / 2) + parseInt(_0x2c54(615, 'dBgG')) / 3 + parseInt(_0x2c54(618, 'gIt4')) / 4 * (parseInt(_0x2c54(656, 'JtWb')) / 5) + -parseInt(_0x2c54(782, 'RHE]')) / 6 * (parseInt(_0x2c54(613, 'bmXB')) / 7) + -parseInt(_0x2c54(413, 'dEVW')) / 8 * (parseInt(_0x2c54(585, '$$HG')) / 9) + parseInt(_0x2c54(467, 'DF8]')) / 10 + parseInt(_0x2c54(649, '%6jm')) / 11;
      if (_0x24d20a === _0x2e2791) {
        break;
      } else {
        _0x18d18b.push(_0x18d18b.shift());
      }
    } catch (_0x55aa42) {
      _0x18d18b.push(_0x18d18b.shift());
    }
  }
})(_0x56f0, 725309);
function _0x5d9e83(_0x5257d0, _0x481831, _0x26fb64, _0x4ffda0, _0x17f14b) {
  return _0x2c54(_0x4ffda0 - 0x25b, _0x26fb64);
}
function _0x2c54(_0x25bf00, _0x39994c) {
  const _0x392bd8 = _0x56f0();
  _0x2c54 = function (_0x1689ba, _0xfc36eb) {
    _0x1689ba = _0x1689ba - 340;
    let _0x18d951 = _0x392bd8[_0x1689ba];
    if (_0x2c54.CDbOsX === undefined) {
      var _0x5397be = function (_0x234d70) {
        let _0x2eac6b = '';
        let _0x24f0f9 = '';
        let _0x223074 = 0;
        let _0x3a8bc9;
        let _0x4dc886;
        for (let _0x17a3b5 = 0; _0x4dc886 = _0x234d70.charAt(_0x17a3b5++); ~_0x4dc886 && (_0x3a8bc9 = _0x223074 % 4 ? _0x3a8bc9 * 64 + _0x4dc886 : _0x4dc886, _0x223074++ % 4) ? _0x2eac6b += String.fromCharCode(255 & _0x3a8bc9 >> (-2 * _0x223074 & 6)) : 0) {
          _0x4dc886 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/='.indexOf(_0x4dc886);
        }
        let _0x5cfc37 = 0;
        for (let _0xc47885 = _0x2eac6b.length; _0x5cfc37 < _0xc47885; _0x5cfc37++) {
          _0x24f0f9 += '%' + ('00' + _0x2eac6b.charCodeAt(_0x5cfc37).toString(16)).slice(-2);
        }
        return decodeURIComponent(_0x24f0f9);
      };
      const _0x3173ff = function (_0x160adc, _0x3a8eae) {
        let _0x546e3f = [];
        let _0x11e119 = 0;
        let _0x2266b7;
        let _0x4ce995 = '';
        _0x160adc = _0x5397be(_0x160adc);
        let _0x5cc640;
        for (_0x5cc640 = 0; _0x5cc640 < 256; _0x5cc640++) {
          _0x546e3f[_0x5cc640] = _0x5cc640;
        }
        for (_0x5cc640 = 0; _0x5cc640 < 256; _0x5cc640++) {
          _0x11e119 = (_0x11e119 + _0x546e3f[_0x5cc640] + _0x3a8eae.charCodeAt(_0x5cc640 % _0x3a8eae.length)) % 256;
          _0x2266b7 = _0x546e3f[_0x5cc640];
          _0x546e3f[_0x5cc640] = _0x546e3f[_0x11e119];
          _0x546e3f[_0x11e119] = _0x2266b7;
        }
        _0x5cc640 = 0;
        _0x11e119 = 0;
        for (let _0x5a0b73 = 0; _0x5a0b73 < _0x160adc.length; _0x5a0b73++) {
          _0x5cc640 = (_0x5cc640 + 1) % 256;
          _0x11e119 = (_0x11e119 + _0x546e3f[_0x5cc640]) % 256;
          _0x2266b7 = _0x546e3f[_0x5cc640];
          _0x546e3f[_0x5cc640] = _0x546e3f[_0x11e119];
          _0x546e3f[_0x11e119] = _0x2266b7;
          _0x4ce995 += String.fromCharCode(_0x160adc.charCodeAt(_0x5a0b73) ^ _0x546e3f[(_0x546e3f[_0x5cc640] + _0x546e3f[_0x11e119]) % 256]);
        }
        return _0x4ce995;
      };
      _0x2c54.BddnWd = _0x3173ff;
      _0x25bf00 = arguments;
      _0x2c54.CDbOsX = true;
    }
    const _0x41a7aa = _0x392bd8[0];
    const _0x241b3f = _0x1689ba + _0x41a7aa;
    const _0x38ca87 = _0x25bf00[_0x241b3f];
    if (!_0x38ca87) {
      if (_0x2c54.FUBPrS === undefined) {
        _0x2c54.FUBPrS = true;
      }
      _0x18d951 = _0x2c54.BddnWd(_0x18d951, _0xfc36eb);
      _0x25bf00[_0x241b3f] = _0x18d951;
    } else {
      _0x18d951 = _0x38ca87;
    }
    return _0x18d951;
  };
  return _0x2c54(_0x25bf00, _0x39994c);
}
const config = require("../settings");
const {
  cmd,
  commands
} = require("../lib/command");
const {
  getBuffer,
  getGroupAdmins,
  getRandom,
  h2k,
  isUrl,
  Json,
  runtime,
  sleep,
  fetchJson
} = require("../lib/functions");
const cheerio = require("cheerio");
const fetch = require("node-fetch");
async function dlPanda(_0x42746a) {
  try {
    const _0x6890c5 = {
      image: [],
      video: []
    };
    const _0x1242b5 = await fetch("https://dlpanda.com/id?url=" + _0x42746a + "&token=G7eRpMaa");
    const _0x2fa2ba = await _0x1242b5.text();
    const _0x2abd63 = cheerio.load(_0x2fa2ba);
    _0x2abd63("div.hero.col-md-12.col-lg-12.pl-0.pr-0 img, div.hero.col-md-12.col-lg-12.pl-0.pr-0 video").each(function () {
      const _0x124172 = _0x2abd63(this);
      const _0x1b3bab = _0x124172.is("video");
      const _0x72981e = _0x1b3bab ? _0x124172.find("source").attr("src") : _0x124172.attr("src");
      const _0x427327 = _0x72981e.startsWith('//') ? "https:" + _0x72981e : _0x72981e;
      _0x6890c5[_0x1b3bab ? "video" : "image"].push({
        'src': _0x427327,
        'width': _0x124172.attr("width"),
        ...(_0x1b3bab ? {
          'type': _0x124172.find("source").attr("type"),
          'controls': _0x124172.attr("controls"),
          'style': _0x124172.attr("style")
        } : {})
      });
    });
    return _0x6890c5;
  } catch (_0x14cb9a) {
    console.error("Error fetching data:", _0x14cb9a);
  }
}
if (config.COMMAND_TYPE === "button") {
  const _0x43f32a = {
    pattern: 'tt',
    alias: ["tiktok"],
    react: '💫',
    dontAddCommandList: true,
    filename: __filename
  };
  cmd(_0x43f32a, async (_0x63454e, _0x28d782, _0x2ad37f, {
    from: _0x2b8561,
    l: _0x34d419,
    quoted: _0xda11f1,
    body: _0x275b77,
    isCmd: _0xbb4056,
    command: _0x3ce774,
    args: _0x3f702d,
    q: _0x5a80a6,
    isGroup: _0x638365,
    sender: _0x36bdaf,
    senderNumber: _0x2b6d06,
    botNumber2: _0xd6f8d5,
    botNumber: _0x11d4e4,
    pushname: _0x501196,
    isMe: _0x6949c2,
    isOwner: _0x3ce9bb,
    groupMetadata: _0x953731,
    groupName: _0x2cc455,
    participants: _0x224019,
    groupAdmins: _0x350285,
    isBotAdmins: _0x40a925,
    isAdmins: _0x3bd956,
    reply: _0x512efd
  }) => {
    try {
      if (!_0x5a80a6) {
        return await _0x512efd("*Please give me a tiktok url!*");
      }
      let _0x2e12fa = await fetchJson("https://api.tiklydown.eu.org/api/download?url=" + _0x5a80a6);
      const _0x4c7c38 = "乂 TIKTOK DL\n *◦ Title :* " + _0x2e12fa.title + "\n *◦ Date:* " + _0x2e12fa.created_at + "\n *◦ Duration :* " + _0x2e12fa.video.duration + "\n\n";
      let _0xb93a8a = [{
        'name': "cta_url",
        'buttonParamsJson': JSON.stringify({
          'display_text': "Watch on TikTok",
          'url': _0x5a80a6,
          'merchant_url': _0x5a80a6
        })
      }, {
        'name': "quick_reply",
        'buttonParamsJson': JSON.stringify({
          'display_text': "Without Watermark",
          'id': ".ttdl " + _0x2e12fa.video.noWatermark
        })
      }, {
        'name': "quick_reply",
        'buttonParamsJson': JSON.stringify({
          'display_text': "With Watermark",
          'id': ".ttdl " + _0x2e12fa.video.watermark
        })
      }, {
        'name': "quick_reply",
        'buttonParamsJson': JSON.stringify({
          'display_text': "Audio",
          'id': ".tikmp3 " + _0x2e12fa.music.play_url
        })
      }];
      const _0x47a6b2 = {
        image: _0x2e12fa.video.cover,
        header: '',
        footer: "POWERED BY TALKDROVE",
        body: _0x4c7c38
      };
      return _0x63454e.sendButtonMessage(_0x2b8561, _0xb93a8a, _0x2ad37f, _0x47a6b2);
      const _0x1ad335 = {
        text: '✅',
        key: _0x28d782.key
      };
      const _0x57359c = {
        react: _0x1ad335
      };
      await _0x63454e.sendMessage(_0x2b8561, _0x57359c);
    } catch (_0x49c99c) {
      if (!_0x5a80a6) {
        return _0x512efd("*Please give me words to search*");
      }
      const _0x4f4c78 = await dlPanda(_0x5a80a6);
      const _0x1da76 = {
        quoted: _0x28d782
      };
      const _0x52d1b0 = {
        quoted: _0x28d782
      };
      if (0 === _0x4f4c78.video.length) {
        for (let _0x2bffa0 = 0; _0x2bffa0 < _0x4f4c78.image.length; _0x2bffa0++) {
          await _0x63454e.sendMessage(_0x2b8561, {
            'image': {
              'url': _0x4f4c78.image[_0x2bffa0].src
            },
            'caption': "POWERED BY TALKDROVE"
          }, _0x1da76);
        }
      } else {
        for (let _0x244c05 = 0; _0x244c05 < _0x4f4c78.video.length; _0x244c05++) {
          await _0x63454e.sendMessage(_0x2b8561, {
            'video': {
              'url': _0x4f4c78.video[_0x244c05].src
            },
            'caption': "POWERED BY TALKDROVE"
          }, _0x52d1b0);
        }
      }
      console.log(_0x49c99c);
    }
  });
  const _0x4d3570 = {
    pattern: "tiktoksearch",
    alias: ["tiks"],
    use: ".tiktoksearch <query>",
    react: '🍟',
    desc: "Search and DOWNLOAD VIDEOS from xnxx.",
    category: "download",
    filename: __filename
  };
  cmd(_0x4d3570, async (_0x33ebd7, _0x576640, _0x1ed48b, {
    from: _0xbb4ec1,
    l: _0x4ee623,
    quoted: _0x475c07,
    body: _0x278dee,
    isCmd: _0xaa3fda,
    command: _0x251b9f,
    args: _0x4e8de7,
    q: _0x1c70c1,
    isGroup: _0x2b35fa,
    sender: _0x5a095b,
    senderNumber: _0x3b4ed9,
    botNumber2: _0x25ae96,
    botNumber: _0x1cb9e4,
    pushname: _0x489451,
    isMe: _0xdfc9af,
    isOwner: _0x170d72,
    groupMetadata: _0x3cc7aa,
    groupName: _0xd875c4,
    participants: _0x342c3e,
    groupAdmins: _0xca06d3,
    isBotAdmins: _0x2ae34a,
    isAdmins: _0x215146,
    reply: _0x154c7e
  }) => {
    try {
      if (!_0x1c70c1) {
        return _0x154c7e("*Please give me words to search*");
      }
      let _0x4bad5e = await fetchJson("https://apis-starlights-team.koyeb.app/starlight/tiktoksearch?text=" + _0x1c70c1);
      let _0x367bb8 = _0x4bad5e.data;
      const _0x2e1423 = {
        quoted: _0x576640
      };
      if (_0x367bb8.length < 1) {
        return await _0x33ebd7.sendMessage(_0xbb4ec1, {
          'text': "*I couldn't find anything :(*"
        }, _0x2e1423);
      }
      var _0xe5e0b2 = [];
      _0x367bb8.map(_0x42c76f => {
        const _0x5ccee6 = {
          title: '' + _0x42c76f.title,
          description: "Info : " + _0x42c76f.url + " \n " + _0x42c76f.region + " Rigion \n " + _0x42c76f.creator,
          id: ".ttsdl " + _0x42c76f.nowm
        };
        const _0x36c64b = {
          rows: [_0x5ccee6]
        };
        _0xe5e0b2.push(_0x36c64b);
      });
      const _0x536d2f = [{
        'name': "single_select",
        'buttonParamsJson': JSON.stringify({
          'title': "Tap Here!",
          'sections': _0xe5e0b2
        })
      }];
      const _0x1a5784 = {
        image: "https://cdn.vox-cdn.com/thumbor/-C8qLMHXZ2H1kC1-PTOEkYWoOSI=/0x0:2040x1360/2000x1333/filters:focal(1020x680:1021x681)/cdn.vox-cdn.com/uploads/chorus_asset/file/23951403/STK051_VRG_Illo_N_Barclay_10_tiktok.jpg",
        header: '',
        footer: "POWERED BY TALKDROVE",
        body: "乂 *T T - S E A R C H* "
      };
      return _0x33ebd7.sendButtonMessage(_0xbb4ec1, _0x536d2f, _0x1ed48b, _0x1a5784);
    } catch (_0x1c5820) {
      console.log(_0x1c5820);
      const _0x2b3b5e = {
        text: "*Error !!*"
      };
      const _0x513caf = {
        quoted: _0x576640
      };
      await _0x33ebd7.sendMessage(_0xbb4ec1, _0x2b3b5e, _0x513caf);
    }
  });
}
const _0x3c3a5c = {
  pattern: "ttdl",
  alias: ["tiktokdl"],
  react: '💫'
};
function _0x540b72(_0x51be37, _0x45aff8, _0x1ebed1, _0x2ab5c6, _0x24ced8) {
  return _0x2c54(_0x51be37 - 0x2ec, _0x45aff8);
}
function _0x56f0() {
  const _0x96f84f = ['WQNdVrFcPG', 'mWm2sq', 'WPBdUmkeW74', 'kd/cIqdcGq', 'mmoyW5RdKCo3', 'W59wBYT3', 'jNxcTJLA', 'lgddHHHb', 'WOzeW7PMka', 'WPWVF8oRgW', 'WQeBWOHKFG', 'uXRcRSkA', 'W5PAzsPA', 'CY7cVrO0F34', 'W4qdWRC7WQK', 'm8kOW5xcNLi', 'AshcH1/dGW', 'WOmqW4hdU8oL', 'eCkuWONcSSk5', 'aSkfW7G0WQS', 'WPlcTmkcWR4N', 'EhBcM8o+', 'WR3dGmo3W6G9', 'lcVdTJGp', 'WOzrWOFdLc8', 'n8kxW6NcQSkV', 'W5LRxmoCsG', 'fSkmW7VdQfG', 'jSkSW7i', 'W4PqzMfS', 'W6CsWQpcRJq', 'qJBdOmo+pq', '4BwA4BwKFUg1Uog2Pq', 'k8k+vmk8W7O', 'W5jErwOd', 'd8oVnCoaiq', 'W4fnWPPXW5K', 'pCkOsCk5W5a', 'WQGopSkOWPG', 'xx3cSNVdVG', 'mCkVW4mhWOa', 'r8oEWQjZW7DVW6nvWR4fnZu', 'cSozW4NdTmo2', 'W69DzCo4W63dP8k8qSo2hSoUpG', 'pSk+wCkbW4a', 'WQCvnq', 'WPGkox0RsM94W7ddJ8kAW6ddGG', 'WPepmx8O', '8yI4ImkNWRyrlq', 'BCkeW6xcPuy', 'WPJcRmkdW6Lr', 'WOxdQCkxW6vF', 'WOPaBNCb', 'WOGroe/cHW', 'WOtdQCkEW6H9', '4BAm4BwcW5RWQPcr4Oke8jsbNG', 'uZ3cHmobWRW', 'WPHrWPtcKa', 'zCosWPHgga', 'mruTcW', 'WQKeFSkVWRO', 'WOHAcSohWP8', 'oSkaW7RcOCk4', 'W4xcLSkTWPxdSW', 'WQerpa', 'kSkUsCkhW5y', 'F8oeW4W', 'WOpcTmkDW79Z', 'ExnQdxW', 'eg7dOs9d', 'W6WKjv7dKq', 'o8kVw8khW4i', 'v8kZW5i', 'WRqFWOy', 'v8kRB8oFpq', 'WOFdUCkdW6q', 'W7tcI8kPfmkU', 'hSkrW6FcSrNcLmoRWO08fmomyh/dIG', 'W4/dL8kSWPtdPW', 'WOFdRCkEW6Hr', 'dSoVmSoliW', 'W7u2WQXhxW', 'ybpcGG', 'W7hcIxBdNIC', 'W4fhWQdcLxNdRmkQ', 'W7DIWOftW54', 'W6GGWPqGoa', 'WRCtbCkDWQa', 'WPOzWOhdLgG', 'WQKgyae', 'WOrgW7PjgW', 'WOK+smkVWRG', 'BIZdLq', 'W6vIWODDW5C', 'W6rVWOCrW4S', 'u191nxW', 'nmoDW5ZdU8kZ', 'BgRcIa', 'WRRdLmoqW7iT', 'WRNdImkJW6vx', 'W7LmuY1v', 'W4u0WPa+W7y', 'YRtiOEg2H8k84Bwz', 'vmkOW5P+Eq', 'WRKFW5hdMSo9', 'DSkVtSkRW5m', 'W7z1WP8', 'vmoVnColiW', 'W5OOWPi', 'WObBWO3cGa', 'kY3cVZqy', 'WOCbybFdHa', 'cHeUbSop', 'W41qztPz', 'WQaijKldJa', 'i2xcIsNdQq', 'jKyWwSkd', 'cwNdTG0J', 'WQ4Fkfm', 'Bfb+fCol', 'WPDrWPVcGhW', 'juRdPYbp', 'WP5xW78', 'r8kOaCo/aG', 'WQLeFCkpW60', 'W5OPWRGtWPy', 'fCo3mG', 'WOVdMCo7WO7dOG', 'sSokWRJdRey', 'dSovW4BdTW', 'Ah3cIa', 's8kUC8kCFab9kN7dQSklWOqE', '4BEl4Bw3WPdWSyoH4Ok+8lEsLG', 'fSkxwCkvW5K', '4BwZW4ZiISUpW6q', '4BAy4BsdW5pHTkxHTRG', 'cgNcLJ/dPG', 'bMJcVa', 'rmoCWQDWWRW', 'W6BcTei', 'Y6BlJ+g3UNtHTBq', 'W6GMWOX6eq', 'rwzUBau', 'WRBcG8oTfSoP', 'W6xdP8kzWPVdUq', 'isZcTdzx', 'W518WRVcT0C', '8ykJPokdVFc8KOVcJEg3S+g2SEg1HW', 'W47dISkPWPxdUq', 'amkfW7CLWQS', 'WRCFxG', 'xtBcQSoMDq', '4Bwk4BwPnpcBSBxIG5BXJRoB', 'WPmpBMOp', 'pCkesCk9W5S', 'hmo0lSoBkG', 'W4XkAc9m', 'W5WUW7tcRYu', 'jCkhp2/cUa', 'ngddKHi', 'WRVdGSoZ', 'WRhcKI7dOa', '8lwQVmo/W7H4WRG', 'WQ5xf8ohWQu', 'E8okWQddOuC', 'saRcSG', 'W4PLWQ/dVvS', 'geuvxCkI', 'WRhcKG7dRmoh', 'o04lz8kt', 'qHJcSSovWQS', 'WRCenW', 'kSk/sCo4W4m', 'WRVdVrdcShq', 'gKj2zGO', 'lCo6nComjW', 'WRddTrlcSrC', 'bSkuWPlcUCkZ', 'eSoxW4FdI8oC', 'e8oWWOOTjmkaWQ07pfuVqhJdQa', 'WOSEC8o6da', 'Y5/lMog3MSoN4Bwn', 'ngiyD8kP', 'WRNcL0VdQqi', 'W5LNWOyVWRG', 'W5b0jmoZhq', 'ycVcLSoBWP8', 'bMNcTSoWla', 'bSknW6C0WQe', 'WQNdVqJcUt4', 'W6e+WRa9fa', 'W7hcKmoU', 'oCkBW6BcQG', 'b8ovW5ZdSSkP', 'b3pcPSkGpG', 'ASk9ASkiW5b4WPa', 'lthcRtHx', 'W6/dJCkPWPVdVW', 'bCkjW70KWOK', 'mqeQf8oh', 'W5D3WRZcSI4', 'W6Tzymk0W6m', 'W5DnWOD7W50', 'qSkwdmoUbq', 'WRGFW57dNCoe', 'W5WrWR7cSdO', 'xSk3mCo5mW', 'yJBcI8o9WO0', 'WQFcHapdM8ob', 'm2xcGsNdQa', 'wZxdPmkihSoUnfCf', 'W7TQtSovwq', 'W5JcL8k4WPldPa', 'WRBdPXNcTcK', 'k8kVw8kQW4m', 'WOlcRSkQW5HW', 'WQrjWRBcRhS', 'W5eQWRmFWRm', 'WRGSsJVcLW', 'EmkramoNoG', 'W7/cKJFcRCoN', 'yN3cNH7dMa', 'zCoyW41teG', 'pmkBjgFcSW', 'WQ8okmk4', 'zmosW5Lcbq', 'aNlcOCk5lG', 'WPBdI8o2W544', 'uCkgWPVcQ8kIW4vWW4ZdJCkDW4RcK8kPxa', 'pae0F3G', 'WR0TBH3cOq', 'AmkLW5fvuq', 'qSoAWQddOue', 'W7nRrSottW', 'oMmqD8kV', 'jCk0W7xcKxG', 'W5v/WRzSW6u', 'W65GWPK7fa', 'W7f0W4LyW5a', 'l8kOW7NcSaK', 'hCkpbwJcLq', 'jqO0gd0', '8kIPM8kOW6tcMSo0', 'WP/cS8keW6Li', 'jhGE', 'jmkeWOeuqa', 'WRZcKtJdTmoS', 'ECoIWPxdRg0', 'W79Ga8kswa', 'W7DMtmoA', 'F8oeWPvsbq', 'W59HWRVcVG', 'y0lcQfNdIa', 'W5zgWRjBW7O', 'WRirgq', 'lGf7', '4BAW4BsrW7/HT4NHTk8', 'WRmrvmkcWQ0', 'WOjIDSotWRe', 'nhNcIJJdOG', 'WP7dOCkrW6Tv', 'WPm7zCo7oa', 'W6fOWPDh', 'ANBcGCo2W5S', 'WRRcJIRdRmou', 'WOvHWQVcOuW', 'W4bKD8ozW6O', '4BwprmQnYP09', 'nmkhow/cRW', 'W59WWQFcPG', 'W73dKmkYWQJdUq', 'WRGoW4ldKmoN', 'r8kwbSoSbG', 'WRpcMdFdQSoh', 'mM4IC8kV', 'W59ZWQ3cS0i', 'WPblWOFcLxO', 'WOzwW7jyeW', 'WRaWySkqWR8', 'W6btzYfh', 'mCkpe2hcSq', 'WPRdJ8kLW6Dy', 'WRqgWPDI', 'j8keWOSsxG', 'WOyxWOjICG', 'j1XZsWG', 'D8odW4Xt', 'xCkscCoSdW', 'pXDX', 'WP4GW67dPrNdPaFcPs9Evdi', 'lY17w3e', 'WOONFMKq', 'WPO5cg/dSG', 'WQRdVrJcOtm', 'W5vVWPPSW40', 'WRKvW4FdIG', 'WQyBCGJcLW', 'WRhcPCo7cSkO', 'WPHwWRnDhW', 'WPX8W4jBoW', 'bSkzW6aO', 'ESovW49kpW', 'DCk0W6DcwW', 'umkKW594yG', 'W4HKASoD', 'WR0fkvJdHa', 'zMlcLa', 'aSobW4ZdUSo8', 'WRXNW5/ILQZdUq', 'd8oBW48', 'W7HcENldRSkcW4S4WRa', 'uG3cP8ocWRG', 'W490WQVcSW', 'W7mxv8kcWQS', 'WRGznCkTWQe', 'xCowWRVdVu0', 'WPhcK8k1W6Xe', 'i8kUW7NcO2G', 'pXa0rxW', 'W7K9WPy', 'e8oyW4NdQSom', 'tW3dSG', 'WQNdVrFcOtq', 'WQNdJ8oRW7m1', 'FmomWRNILQBdPa', 'WR4yi8kTWRi', 'WRjqk8k14PAs', 'ECkAg8o4cW', 'W7tcRKhdTq', 'WOODBG', 'WQ5AbSogW6y', 'E8kFowxcQa', 'wCkBWOFdSSoJ', 'h27dVCk0iG', 'W5CZWOe4', 'jwpcLmk0oa', 'WRGgWQz+sW', 'WQGBW4ddJCoG', 'jMpcIgpdSG', 'wSokWRddReC', 'nLVcJdJdRW', 'WP0OBSo+aa', 'W6D7WRFcVNG', 'WPDmWPdcLxO', 'WROtsCkd', 'W711smkDxq', 'WRJdImoRW7K6', 'nmkLceRcVW', 'YRhlQ+g1KmoS4BEy', 'WRVcMrRdOSoE', 'WPOGtvJcOa', 'c0JcUHJdNG', 'la14zNG', 'agVdV8k9kq', 'WR0gWPDGyG', 'x8ogWRRdRwO', 'g3PPEG0', 'W5PnAa', 'pCkPx8o5', 'c8oaW5ZdO8oG', 'WRldJSoG', 'avL1za', 'D8kZlSoyaa', 'W5K1WRSpW5q', 'W7lcS1pdVG', 'W6vryYji', 'oaf1CwK', '5lUqjWxdPHW', 'd8kzW5ugWQK', 'kKpcTGxcUG', 'WPZdHIZcVGG', 'WPRcRmkiW6ji', 'WQ/cNc3dUCow', 'W61jeCoxW6m', 'W6ldLCoUW7CG', 'W6ugWP4JaW', 'WOVdNSk+WO7dQa', 'jq4BlSop', 'mGuWnSoe', 'W7lcJCoOh8kI', 'agVdV8k8kG', 'qxfsnwe', 'mw3cLYddRG', 'WOa5WQXuEW', 'iW9aFxy', 'WObxWP7cMx4', 'W4nHWQVcOLS', 'h8k1W4dcKbu', 'WQeSWP46vW', 'E1yLis7dQSkqmvtcU00Q', 'm8kDW68', 'W7tdRSkjWR3dLa', 'WQmNWRrJsq', 'k3FcG8kvjG', 'Ed7cIW0qDuy', 'u8k0W5fVCW', 'qmkdW7xcQai', 'WOahxXtcLG', 'WPukWRpcOcK', 'DwdcHKm', 'W5PGWRdcPK0', 'ibqQeq', 'WPRcTSkj', '4BEowSIPYlBcQq', 'x8ogWRRdRwu', 'jCkQp3JcIG', 'pSkYvmk8', 'n2/cJwZcUW', 'W7/cHmokf8kQ', 'WOudDrBcKG', 'umkyW7WRWQe', 'WQOFi17dMa', 'wSo2WOpdUNa', 'WOeKWRLwEa', 'W4j4WR7cTu0', 'CmoEW5rehW', '8kQHOUkbSpcBSAbM4BEe4BEs4Bwh', 'wmoxWR3dP08', 'lmkgW7RcP8kK', 'W592W6fyhW', 'W6/cKSoO', 'e8kGW6FdT2e', 'mCkRtSkXW5G', 'W5GcWQeeeW', 'aJlcQH8B', 'iHq3dmom', 'WPtdVq7cLXG', 'WQCxWOjZzq', 'WOiVnSonW7S', 'W7GVWQWMWQS', 'W5G5WQJcRa', 'z8kvW7DnBG', 'WO8kbCkUWPG', 'WOXdW7y', 'gmoUWPf4CG', 'j8kgWOWxq8k7vatcJCkkzSoepSk9', 'WQTXsCo1F8oOWQa', 'WR7dUWRcScK', 'pSo2e8ogbG', 'W4iIWO0+', 't8kUCmkyFGCxf2tdJmk4WRa', '8ykrLUkdUpgcKRxcHEg3P+g1JUg0Ha', 'W418WRpcT0y', 'WQ8cjmkGWRa', 'WROpW5/dJCoS', 'WQJdPHa', 'raRcTCorWQS', 'W4XSpCkSqSomDCkDW53cL8kFWPOD', 'W7DUWODsW5O', 'cSkmtSk0W7y', 'h8o6lmkbja', 'W4nBF8ooW6y', '4BA24BwkW5xWRBkX4Oon8lsqLG', 'CWNcI8orWQ0', 'W7ZdMCkVWP/dUq', 'ALZdKavz', 'mgmBAW', 'fmo0jCokyG', 'fmoHW7hcPuy', 'CdZcPmoDWOC', 'hCkZW5tcNgW', 'W5HxWRRcTei', 'WRZdOaJcPW', 'WRavqa', 'eSk/vCkwW7a', 'W5TMySoMvq', 'W5HkzdP9', 'uSkgWOBdO8o/', 'jSklW6hcICkF', 'rxnWEWS', 'WR7dM8kJW455', 'wCorWRG', 'vejSkh0', 'WR0Dzq', 'fvjspwxcQmoq', 'mSkCW4ifWQ8', '4BAW4BA8W7VHT6hHTOW', 'WQmxW4n9Da', 'aYRdOSo+pq', 'hCkVW4xcLfi', 'jSk1W6pcPq', 'C8oeW4TafG', 'p1fYwca', 'cmkeW7ZcJN4', 'WOJcR8kEW7DZ', 'WOf6WO3cKxy', 'bConrSoObq', 'ySoNW4XXoa', 'WPe7BW', 'uCkcWP7cOmkLW4bWWRldOSkmW5NcNmkE', 'WQ/dSr3cTI8', 'WP7dV8ke', '4BwV4Bs7iVcDGiZIGz7XJPou', 'CCoEW55y', 'kYZcRY8', 'smo2WOpdGqO', 'rmoxWQFcPfW', 'WR0kAbZcQq', 'qv9ZlG', 'W4fKoCojW7e', 'A3JcJcFdQG', 'nqKQd8oh', 'WQ4FrSkeWRG', 'WQLlCCoTW78', 'tSo2WOddNIe', 'D8oBW5faaG', 'aSomW4hdVmoG', 'WOZcGCoeWRWC', 'h8kNW4dcLfi', 'WRaFsCkaWRG', 'tSkKW5b8yG', 'W57cKSo7f8k1', 'W4C8WQNdPZq', 'WQZcMhNdQSoA', 'W6lcSKJdUay', 'W4LYASoFW7K', 'W4fVvSosW7O', 'WPj3z8o4wq', 'W6jZWODm', 'WPfsW6Dl', '5lMGW6hdQLjD', 'WQ8FouBdMq', 'W7OMWP4XfG', 'ngSroSoQ', 'se5MohC', 'WPeDyWJcIa', 'WPxdTCkjW6SZ', 'WRjJrSoawq', 'W4hdTmodW7PX', 'nSkwWRFcU8k4', 'W6JcLmoWfmkI', 'o8onW73cVmkM', 'gCkmFSkUW7G', 'W6mHW5PEwq', 'WQ8FsCkdWOe', 'WPdcMdFdHmou', 'WQ4+zCkwWRW', 'WQeuWPfXEW', 'fmkTaCoSaW', 'WPHPWPhcH0K', 'AIe0uZ0', 'WPHrWPi', 'WOyCD38y', 'WOddRCkeW6Lc', 'iI3cTJ8y', 'WOClAx0y', 'lXhcTbqB', 'bHKRdCoq', 'rbJcTCovW6W', 'n8kIx8k6WPK', 'Y7JkH+g0R8ks4BsX', 'a8kEW78', 'WPldV8kdW61x', 'DxlcHCkP', 'jSkZW7VcVK4', 'vmoOWPZcNrS', 'vvLRFtG', 'otC6jCk+', 'pSkEW6hcR8k5', 'j8olCs/dTG', 'WOGXf8osW70', 'W4P4WRO', 'WQ/cTf3dThe', 'oSkJW5ieW6q', 'bGP8FK0', 'pmk+sCk7W4u', 'BSoBWQFcRCkU', 'cmoaW4FdUmk9', 'W6VcGCo9dmkI', 'W5qSWQ7cTq', '8lUPRGFcPIRcUa', 'WP0jpNOGtqLfW5ddKSklW5e', 'WQSQp8k6WOm', '8yYWH+kaI/cHKz9c4BA/4BsO4BAy', '4BAWEmMdYyHG', 'W77cPKNdQc8', 'WOX6kSk+xG', 'zSocW4Tj', 'eCo+oa', 'adZcNtKc', 'ACk1W6pdPGK', 'WPzhWRnFaG', 'e8oWnCoaja', 'sddcOSohWRy', 'WR1sWOj+Dq', 'eCorW4/dUSo8', '8yIZIEkcIVc4K69/4BwG4BAF4BAB', '4BAgj8MQYRhcNW', 'yv5Jnx0', 'WRhdUXS', 'uCkSlCoCeW', 'WQZcIq3dTmoE', 'y2dcN0tdUG', 'WQ7dSrlcSry'];
  _0x56f0 = function () {
    return _0x96f84f;
  };
  return _0x56f0();
}
_0x3c3a5c.dontAddCommandList = true;
_0x3c3a5c.use = ".tt1 <tiktok link>";
_0x3c3a5c.filename = __filename;
cmd(_0x3c3a5c, async (_0x548989, _0x334da4, _0x16fd48, {
  from: _0x310eb6,
  l: _0x31daa2,
  quoted: _0x3f267e,
  body: _0x43cf90,
  isCmd: _0x200521,
  command: _0x15d6d8,
  args: _0x422a09,
  q: _0x5a652d,
  isGroup: _0x4c0469,
  sender: _0xaa8930,
  senderNumber: _0x244d1f,
  botNumber2: _0x425304,
  botNumber: _0x1b592e,
  pushname: _0x5666a0,
  isMe: _0x4ea9d5,
  isOwner: _0x57df1b,
  groupMetadata: _0x2d83db,
  groupName: _0x5050d7,
  participants: _0x1f2a35,
  groupAdmins: _0x3d3795,
  isBotAdmins: _0x212d0b,
  isAdmins: _0x4b8419,
  reply: _0x550133
}) => {
  try {
    if (!_0x5a652d) {
      return await _0x550133("*Please give me a tiktok url!*");
    }
    const _0x206494 = {
      url: _0x5a652d
    };
    const _0x3dde13 = {
      video: _0x206494,
      caption: "POWERED BY TALKDROVE"
    };
    const _0x107191 = {
      quoted: _0x334da4
    };
    await _0x548989.sendMessage(_0x310eb6, _0x3dde13, _0x107191);
    const _0xfa2570 = {
      text: '✅',
      key: _0x334da4.key
    };
    const _0xd5cfa6 = {
      react: _0xfa2570
    };
    await _0x548989.sendMessage(_0x310eb6, _0xd5cfa6);
  } catch (_0x2a00a7) {
    _0x550133("*Error !!*");
    console.log(_0x2a00a7);
  }
});
const _0x463229 = {
  pattern: "tikmp3"
};

function _0x5b2a4c(_0x3b88fa, _0x525f17, _0x3379b5, _0x444886, _0x51bdb6) {
  return _0x2c54(_0x444886 + 0x87, _0x51bdb6);
}
_0x463229.alias = ["tiktokmp3"];
_0x463229.react = '💫';
_0x463229.dontAddCommandList = true;
_0x463229.filename = __filename;
cmd(_0x463229, async (_0x303e1f, _0x2875e1, _0x396dce, {
  from: _0x2b232c,
  l: _0x558396,
  quoted: _0x3578a4,
  body: _0x27616c,
  isCmd: _0x1657d1,
  command: _0x3bb9f5,
  args: _0x4331db,
  q: _0x44f3b5,
  isGroup: _0xac5691,
  sender: _0x449bc8,
  senderNumber: _0x4280cd,
  botNumber2: _0x26a547,
  botNumber: _0x4892e6,
  pushname: _0x4b6c1b,
  isMe: _0xb53fd,
  isOwner: _0x49fa31,
  groupMetadata: _0x20aa26,
  groupName: _0x285963,
  participants: _0x3f8b9f,
  groupAdmins: _0x8470ca,
  isBotAdmins: _0x27295d,
  isAdmins: _0x5279dd,
  reply: _0x4d0818
}) => {
  try {
    if (!_0x44f3b5) {
      return await _0x4d0818("*Please give me a tiktok url!*");
    }
    const _0x417a7f = {
      url: _0x44f3b5
    };
    const _0x139b73 = {
      audio: _0x417a7f,
      mimetype: "audio/mpeg"
    };
    const _0x542422 = {
      quoted: _0x2875e1
    };
    _0x303e1f.sendMessage(_0x2b232c, _0x139b73, _0x542422);
  } catch (_0x105584) {
    _0x4d0818("*Error !!*");
    console.log(_0x105584);
  }
});
function _0x3369b5(_0x5d2aac, _0x3bc5da, _0x3d30c7, _0x179118, _0x21bf69) {
  return _0x2c54(_0x3d30c7 - 0x40, _0x5d2aac);
}
function _0x579fcb(_0xfebb9e, _0x2323dc, _0x474dd9, _0x2ba4f1, _0x4c336f) {
  return _0x2c54(_0x2323dc + 0x2e, _0xfebb9e);
}
const _0x2dec0b = {
  pattern: "ttsdl",
  react: '🍟',
  dontAddCommandList: true,
  filename: __filename
};
cmd(_0x2dec0b, async (_0x1f1b00, _0x467c70, _0x2650c1, {
  from: _0x54e7b6,
  l: _0x2a598a,
  quoted: _0x256fdb,
  body: _0x445c99,
  isCmd: _0x16ba16,
  command: _0x2efea8,
  args: _0x2b8645,
  q: _0x1291fb,
  isGroup: _0x4511db,
  sender: _0xdee346,
  senderNumber: _0x41c807,
  botNumber2: _0x5d6e14,
  botNumber: _0x24f006,
  pushname: _0x28f6e2,
  isMe: _0x2aac5d,
  isOwner: _0x38355b,
  groupMetadata: _0x231833,
  groupName: _0x3f8afd,
  participants: _0x65b3ce,
  groupAdmins: _0x50d208,
  isBotAdmins: _0x165a30,
  isAdmins: _0x25c4dd,
  reply: _0x7a6fbe
}) => {
  try {
    if (!_0x1291fb) {
      return _0x7a6fbe("*Please give me direct url !!*");
    }
    const _0xdbb0e2 = {
      url: _0x1291fb
    };
    const _0x7e127f = {
      video: _0xdbb0e2,
      caption: "POWERED BY TALKDROVE"
    };
    const _0x255c55 = {
      quoted: _0x467c70
    };
    await _0x1f1b00.sendMessage(_0x54e7b6, _0x7e127f, _0x255c55);
  } catch (_0x40e666) {
    _0x7a6fbe("*Error !!*");
    console.log(_0x40e666);
  }
});
