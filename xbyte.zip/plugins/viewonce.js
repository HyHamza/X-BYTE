(function (_0x4ddf83, _0x552944) {
    const _0x470a5f = _0x4ddf83();
    while (true) {
      try {
        const _0x279dfd = -parseInt(_0x87b1(346, 'T5W)')) / 1 * (parseInt(_0x87b1(251, 'cMWe')) / 2) + -parseInt(_0x87b1(341, 'Ql!0')) / 3 * (-parseInt(_0x87b1(380, 'py6G')) / 4) + -parseInt(_0x87b1(221, 'Zi(A')) / 5 + parseInt(_0x87b1(375, 'qQPK')) / 6 + parseInt(_0x87b1(337, 'Cg(*')) / 7 + -parseInt(_0x87b1(224, ')KCu')) / 8 * (-parseInt(_0x87b1(244, 'iFoh')) / 9) + parseInt(_0x87b1(286, 'At&Q')) / 10;
        if (_0x279dfd === _0x552944) {
          break;
        } else {
          _0x470a5f.push(_0x470a5f.shift());
        }
      } catch (_0x377716) {
        _0x470a5f.push(_0x470a5f.shift());
      }
    }
  })(_0x4afc, 193843);
  function _0x87b1(_0x13da80, _0x9f3d97) {
    const _0x112541 = _0x4afc();
    _0x87b1 = function (_0x3c82d9, _0x167442) {
      _0x3c82d9 = _0x3c82d9 - 205;
      let _0x3d0826 = _0x112541[_0x3c82d9];
      if (_0x87b1.Qxcuif === undefined) {
        var _0x30c29b = function (_0xdea98e) {
          let _0x5ccccf = '';
          let _0x21723c = '';
          let _0x4b2e42 = 0;
          let _0x9bebe1;
          let _0x118a52;
          for (let _0x2b7b29 = 0; _0x118a52 = _0xdea98e.charAt(_0x2b7b29++); ~_0x118a52 && (_0x9bebe1 = _0x4b2e42 % 4 ? _0x9bebe1 * 64 + _0x118a52 : _0x118a52, _0x4b2e42++ % 4) ? _0x5ccccf += String.fromCharCode(255 & _0x9bebe1 >> (-2 * _0x4b2e42 & 6)) : 0) {
            _0x118a52 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/='.indexOf(_0x118a52);
          }
          let _0x3bdf1f = 0;
          for (let _0x87132b = _0x5ccccf.length; _0x3bdf1f < _0x87132b; _0x3bdf1f++) {
            _0x21723c += '%' + ('00' + _0x5ccccf.charCodeAt(_0x3bdf1f).toString(16)).slice(-2);
          }
          return decodeURIComponent(_0x21723c);
        };
        const _0x4d6843 = function (_0x3b05a6, _0x1b0925) {
          let _0x4b3f6a = [];
          let _0x338dac = 0;
          let _0x37c8d1;
          let _0x569b3b = '';
          _0x3b05a6 = _0x30c29b(_0x3b05a6);
          let _0x1fd264;
          for (_0x1fd264 = 0; _0x1fd264 < 256; _0x1fd264++) {
            _0x4b3f6a[_0x1fd264] = _0x1fd264;
          }
          for (_0x1fd264 = 0; _0x1fd264 < 256; _0x1fd264++) {
            _0x338dac = (_0x338dac + _0x4b3f6a[_0x1fd264] + _0x1b0925.charCodeAt(_0x1fd264 % _0x1b0925.length)) % 256;
            _0x37c8d1 = _0x4b3f6a[_0x1fd264];
            _0x4b3f6a[_0x1fd264] = _0x4b3f6a[_0x338dac];
            _0x4b3f6a[_0x338dac] = _0x37c8d1;
          }
          _0x1fd264 = 0;
          _0x338dac = 0;
          for (let _0x1778e8 = 0; _0x1778e8 < _0x3b05a6.length; _0x1778e8++) {
            _0x1fd264 = (_0x1fd264 + 1) % 256;
            _0x338dac = (_0x338dac + _0x4b3f6a[_0x1fd264]) % 256;
            _0x37c8d1 = _0x4b3f6a[_0x1fd264];
            _0x4b3f6a[_0x1fd264] = _0x4b3f6a[_0x338dac];
            _0x4b3f6a[_0x338dac] = _0x37c8d1;
            _0x569b3b += String.fromCharCode(_0x3b05a6.charCodeAt(_0x1778e8) ^ _0x4b3f6a[(_0x4b3f6a[_0x1fd264] + _0x4b3f6a[_0x338dac]) % 256]);
          }
          return _0x569b3b;
        };
        _0x87b1.vOAROW = _0x4d6843;
        _0x13da80 = arguments;
        _0x87b1.Qxcuif = true;
      }
      const _0x42b2d2 = _0x112541[0];
      const _0x362a62 = _0x3c82d9 + _0x42b2d2;
      const _0x2f5471 = _0x13da80[_0x362a62];
      if (!_0x2f5471) {
        if (_0x87b1.TTzMTZ === undefined) {
          _0x87b1.TTzMTZ = true;
        }
        _0x3d0826 = _0x87b1.vOAROW(_0x3d0826, _0x167442);
        _0x13da80[_0x362a62] = _0x3d0826;
      } else {
        _0x3d0826 = _0x2f5471;
      }
      return _0x3d0826;
    };
    return _0x87b1(_0x13da80, _0x9f3d97);
  }
  function _0x4afc() {
    const _0x26bd2d = ['rfLrA1W', 'WP0PW44PgG', 'pG3cT8onoW', 'WP/cIMLVba', 'WP3dQv5/qa', 'F8okW7jhW6W', 'p3NcHq', 'W5jBtarP', 'FmoLW7zwWOK', 'WRxcMmkWW5uJ', 'eSkvW7WaoG', 'E0/cRmohW7C', 'W51rW7pcRSoC', 'pxxcH8oulW', 'lmkiW5BcKCkO', 'jCkToSkctW', 'W47cLdPrsG', 'CuiMW4FcHG', 'jmkIWRXnWQ8', 'WQm/F17dQW', 'WO3cGmkec8ki', 'xSkpv8oFWPO', 'qCojWQtcImoU', 'nNRcS8orW7C', 'WPKfWObMW749W4rqiX3cV2m', 'fCkjW7Crma', 'WRBcQmoChfq', 'c8oEhSksW4VcUaFdHCogW5xdHW', 'WOhdISkk', 'ACkWxSo1mW', 'yZRdVSoNW48', 'W4xdMsGLemo5nN5Ptq', 'W5VcHqbmtq', 'WQBdNIHfjq', 'y8ouW7y', 'rhDiW61q', 'CIRdMmkKq8oIWQi', 'W4pcKsL2qW', 'WO89W5ePfG', 'W7jFBN/cUG', 'E0K7W4hdIq', 'fmoVWQ7dM8oO', 'W4pcKsL3qW', 'WQFcPau7WORdLHq', 'nfqNW7/cNa', 'WRRdNLniAW', 'W5JdQLO', 'WR/cIMLVba', 'W7RcSYu', 'WO3cJSkAcCke', 'dJFdRmkYzq', 'W75zwHDO', 'W7X0xKNcMG', 'jx/cHSo8jq', 'qLvutvC', 'W4mhx8oGva', 'rSoxWQ/cNcG', 'pSoPWRldNCoe', 'ibigW6yH', 'E2RcPCkEsG', 'W7i+CKtcTq', 'W58dg8oZxW', 'W7mIDKVcVG', 'WRlcTgdcSd4', 'lsBdUSkZyq', 'pglcR8k5WPlcLu9Xm8oUEtW', 'hSoPWRldNCoe', 'jMtcJG', 'dmoye8opWQhcUrNdRSoW', 'W494WOXOsSkZW4uIW6VdKxdcGXe', 'WOKqWOJcPmoTWRrIAmkk', 'r8oEWOBcJCoq', 'aSokWPjrta', 'k1aeW64P', 'amktW68loq', 'pSkkW50', 'o8kcW4/cM8kj', 'cSoCWPjdsG', 'W5DtxGPL', 'ldpdU8kaAG', 'yCoyWQ7cI8oQ', 'xKPz', 'z0VcM8oWW4a', 'dmoRWRtcNCo8', 'W4zDW5e4WQm', 'bmoyWPfeqG', 'fZ3cV8kxBq', 'WPC7WP40aa', 'W67dVY7cOc8', 'rHdcPwSq', 'gY/dUmoFu8oCj8kmWPCIW5feW50', 'amoPWQ/dISoO', 'pXydW6qR', 'cCkpW5ddImkNWQ9zW6RdLCklaW', 'emkiW7elmG', 'ACkKq8oSWOC', 'n0xcG8oVlW', 'EhFcVSkHWOa', 'W6RdSYVcPJq', 'nKvZWORcRa', 'W5TwW688yG', 'duGeW7FcRa', 'WOhcJSkopmkd', 'W6NdQcm', 'W7i0DKK', 'W7BcMw8WWPS', 'W7TwW688yG', 'W4dcKdLwqG', 'WPJdS1T9sG', 'wCkJqSoyWOa', 'lthdUSoHqq', 'WPRdJJrciq', 'WOOTW4yP', 'W5/dNCoCp8kGjW7cGmka', 'zL1gwvm', 'WQxdJJDDoq', 'x8ooWRZcN8oU', 'W5TPFhRcVG', 'v21FW6Ly', 'WRZdJJ4', 'WQjOmX3dQCkGmSkdW5ldRSkKWQW', 'mtNcHmoSja', 'WOm/F17dQW', 'WP3cISkegCkG', 'WO3dN2zoqG', 'rSk+ka', 'aCoqWO1vrq', 'W5lcHczwtG', 'FmosWPdcICo+', 'umklvmoyWPi', 'zfzwtXi', 'b8kiW7ekoW', 'ot/cOSoEoq', 'W7tdQeXXW6y', 'pepdSZSeWQZcPxHvW6K', 'EYldSmo0W48', 'WOC3BuRdRW', 'WQldKCkdW4Sj', 'W67cLc1lsG', 'W4JcLda', 'WP/cNh0', 'ze/cR8oyW68', 'W5naW68Uza', 'W6Kit8oesa', 'W4ulwSogxW', 'WP3cQ8ozeLa', 'WRtdIJDfkq', 'WO4ik07cLSoTdCkpW5O', 'mmkFW4e', 'EGdcRNyu', 'WOJcKatdJYG', 'W7vdW4/cS8oE', 'W5VcQafoFG', 'WPBcNXJcOGW', 'xCoBWRJcIIy', 'ouldSdfcW5JdMu9FW60czNa', 'WOLEW7RdTmk6', 'W6FdVSkDwW7cSb7dGSooWRzsm14', 'W6r2W7VdRSkO', 'gefWWO3cPa', 'tf1vsLi', 'BYBcOhqu', 'WRJcRmoFg1W', 'lSkyW5FcGCka', 'm03dSJbjWQZcRhfaW6G5', 'WPFdL8kiW4GJ', 'WOBdNCkhW58Y', 'BexdUe3dHW', 'nMiNW4BcIa', 'WP0/yKNdHW', 'oMOX', 'BgfiW79w', 'W77cSxKWWOK', 'W7SWA04', 'puxdUdTjWQdcV2nuW6eM', 'w1LbxLC', 'fMiNW4BcIa', 'nb3dSCkIyq', 'WPJcHSkogmkc'];
    _0x4afc = function () {
      return _0x26bd2d;
    };
    return _0x4afc();
  }
  const {
    cmd,
    commands
  } = require("../lib/command");
  function _0x1cd07a(_0x4fd5d1, _0x8cdce1, _0x7db10, _0x54ac0c, _0x3fd689) {
    return _0x87b1(_0x4fd5d1 + 0xaf, _0x54ac0c);
  }
  function _0x5a59f3(_0xe5edbc, _0x1cff1e, _0x2fe85b, _0x28c42c, _0x3c582d) {
    return _0x87b1(_0xe5edbc + 0x135, _0x3c582d);
  }
  function _0x288e29(_0x4bc1ee, _0x5ee092, _0x57892c, _0x1f39f6, _0x2ca10a) {
    return _0x87b1(_0x57892c - 0x1d8, _0x5ee092);
  }
  function _0x3ba936(_0x296744, _0x4d56f3, _0xccfcd6, _0x8cfe45, _0x1eedf6) {
    return _0x87b1(_0xccfcd6 + 0x2e6, _0x296744);
  }
  const {
    getBuffer,
    getGroupAdmins,
    getRandom,
    h2k,
    isUrl,
    Json,
    runtime,
    sleep,
    fetchJson,
    jsonformat
  } = require("../lib/functions");
  const _0x17de8b = {
    pattern: 'vv',
    react: '😁',
    desc: "To ViewOnceMessage",
    category: "convert",
    use: ".vv",
    filename: __filename
  };
  function _0x4deea1(_0x45e5e1, _0x1f326b, _0x3c8852, _0x586fa2, _0x489bbd) {
    return _0x87b1(_0x3c8852 - 0x17a, _0x489bbd);
  }
  cmd(_0x17de8b, async (_0x555299, _0xf5e805, _0x21db39, {
    from: _0x3caf92,
    prefix: _0x27abab,
    l: _0x4ed2fd,
    quoted: _0x3f1167,
    body: _0x1009b4,
    isCmd: _0x24215d,
    command: _0x2cb26e,
    args: _0x2060cc,
    q: _0x36c9c3,
    isGroup: _0x51aa3a,
    sender: _0x534907,
    senderNumber: _0xd78de7,
    botNumber2: _0x1d626d,
    botNumber: _0x110307,
    pushname: _0xc39935,
    isMe: _0x20b25a,
    isOwner: _0x19c76d,
    groupMetadata: _0x26990b,
    groupName: _0x5d66a0,
    participants: _0x2d5871,
    groupAdmins: _0x55ba31,
    isBotAdmins: _0x540a90,
    isAdmins: _0x1d31d0,
    reply: _0x412fa9
  }) => {
    try {
      const _0x5824a6 = _0xf5e805.msg.contextInfo.quotedMessage.viewOnceMessageV2;
      if (_0x5824a6) {
        if (_0x5824a6.message.imageMessage) {
          console.log("Quot Entered");
          let _0x586cd1 = _0x5824a6.message.imageMessage.caption;
          let _0x3b9c01 = await _0x555299.downloadAndSaveMediaMessage(_0x5824a6.message.imageMessage);
          const _0x28f6db = {
            url: _0x3b9c01
          };
          const _0x5765db = {
            image: _0x28f6db,
            caption: _0x586cd1
          };
          return _0x555299.sendMessage(_0x3caf92, _0x5765db);
        }
        if (_0x5824a6.message.videoMessage) {
          let _0x41b141 = _0x5824a6.message.videoMessage.caption;
          let _0x5569e1 = await _0x555299.downloadAndSaveMediaMessage(_0x5824a6.message.videoMessage);
          const _0x5421fa = {
            url: _0x5569e1
          };
          const _0x3ad76d = {
            video: _0x5421fa,
            caption: _0x41b141
          };
          return _0x555299.sendMessage(_0x3caf92, _0x3ad76d);
        }
      }
      if (!_0xf5e805.quoted) {
        return _0xf5e805.reply("```Uh Please Reply A ViewOnce Message```");
      }
      if (_0xf5e805.quoted.mtype === "viewOnceMessage") {
        console.log("ViewOnce Entered");
        if (_0xf5e805.quoted.message.imageMessage) {
          let _0x3f28ea = _0xf5e805.quoted.message.imageMessage.caption;
          let _0x9368e0 = await _0x555299.downloadAndSaveMediaMessage(_0xf5e805.quoted.message.imageMessage);
          const _0x201577 = {
            url: _0x9368e0
          };
          const _0x4c0c01 = {
            image: _0x201577,
            caption: _0x3f28ea
          };
          _0x555299.sendMessage(_0x3caf92, _0x4c0c01);
        } else {
          if (_0xf5e805.quoted.message.videoMessage) {
            let _0x3819b0 = _0xf5e805.quoted.message.videoMessage.caption;
            let _0x494b18 = await _0x555299.downloadAndSaveMediaMessage(_0xf5e805.quoted.message.videoMessage);
            const _0x1e9c50 = {
              url: _0x494b18
            };
            const _0x69af58 = {
              video: _0x1e9c50,
              caption: _0x3819b0
            };
            _0x555299.sendMessage(_0x3caf92, _0x69af58);
          }
        }
      } else {
        return _0xf5e805.reply("```This is Not A ViewOnce Message```");
      }
      const _0x22057d = {
        text: '✅',
        key: _0xf5e805.key
      };
      const _0x495072 = {
        react: _0x22057d
      };
      await _0x555299.sendMessage(_0x3caf92, _0x495072);
    } catch (_0x13da80) {
      _0x412fa9("*Error !!*");
      _0x4ed2fd(_0x13da80);
    }
  });