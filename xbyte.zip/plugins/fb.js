(function (_0xcc1633, _0x4f4dec) {
    const _0x8b7890 = _0xcc1633();
    while (true) {
      try {
        const _0x361392 = -parseInt(_0x10e0(343, 'WhhJ')) / 1 * (-parseInt(_0x10e0(345, 'd4]S')) / 2) + -parseInt(_0x10e0(352, 'BVxA')) / 3 + -parseInt(_0x10e0(291, 'op78')) / 4 + parseInt(_0x10e0(304, '7T[V')) / 5 + -parseInt(_0x10e0(281, 'x4Pt')) / 6 * (parseInt(_0x10e0(342, 'Rg&Q')) / 7) + -parseInt(_0x10e0(305, 'xj2q')) / 8 * (parseInt(_0x10e0(277, '#Ije')) / 9) + parseInt(_0x10e0(208, 'xj2q')) / 10 * (parseInt(_0x10e0(254, 'xj2q')) / 11);
        if (_0x361392 === _0x4f4dec) {
          break;
        } else {
          _0x8b7890.push(_0x8b7890.shift());
        }
      } catch (_0x57fc6a) {
        _0x8b7890.push(_0x8b7890.shift());
      }
    }
  })(_0x3dd1, 383541);
  const config = require("../settings");
  function _0x360288(_0xbf151, _0x5167cf, _0x4f5bc0, _0x371691, _0x386bce) {
    return _0x10e0(_0x5167cf + 0x2f5, _0xbf151);
  }
  const {
    cmd,
    commands
  } = require("../lib/command");
  function _0x1b622b(_0x4fa559, _0x5a7237, _0x4bf59d, _0x5eeeff, _0x181e68) {
    return _0x10e0(_0x5a7237 - 0x22b, _0x5eeeff);
  }
  const {
    getBuffer,
    getGroupAdmins,
    getRandom,
    h2k,
    isUrl,
    Json,
    runtime,
    sleep,
    fetchJson
  } = require("../lib/functions");
  function _0x339331(_0x4a082c, _0x41c720, _0x50be75, _0x5e55c8, _0x1deb18) {
    return _0x10e0(_0x4a082c - 0x15b, _0x5e55c8);
  }
  const getFbVideoInfo = require("fb-downloader-scrapper");
  function _0x3dd1() {
    const _0x40fc5c = ['AJaD', 'W6etW5lcOfq', 'D3yfDCox', 'W4muy8oEW4JdMfi', 'f8owhvurWR8kW6tcISoShCkz', 'W4RdQGy9ha', 'r3tdJSksq8okW6W', 'W4ZdRWKW', 'WOVcSmoSa2S', 'W5JcRYVdU0m', 'WR9zWPxdOde', 'pSkCW5i', 'EhWl', 'WOHtpCk4oCkHWPNdU2BdPv/dVq', 'W5r3W6ldM8kI', '8ycwK/cqHyJWVAwP8jMfUVctPBe', 'WOBdIehdSeC', 'W4xdPWyL', 'W5ddJCkoAtZdLgnVjK5DfMy', 'z8oBlSonW5a', 'gCkjzsrq', 'WRNdS8krxSos', 'zZ3cV8oTqq', 'WOVdImkDvCoI', 'CtRcVSoLsa', 'cGiMfmoP', 'WRnHDq', 'cmkDW4pdPCkO', 'W4RdLrORtW', 'W4HMW7pdJmo9', 'WPddOgFdSKG', 'WOTfW6JdJSkY', 'WOFdGqyJiG', 'cbLQW6y', 'da9pWPJcNa', 'wIDVWPtcUmkzWQS', 'u1ldIfqC', 'WOdcMCowkhe', 'WRhcIqnNCq', 'CSobkCoAW7O', 'W7BdHSkMvmoI', 'W6dcOSkxBSoWWQXhWO4', 'WPldTW7cR8ob', 'WO5SoCopWR4', 'ovCDB8kr', 'lSomuq', 'jhbt', 'W7xdQSkx', 'vCkJEcjA', '8yUhPVgdHz3WQQsP8lYuU/c7TAm', 'WQFcMSokmMW', 'WPzcW6/dMSkM', 'W6ddK8kMxSoR', 'WRCaW43dRCoN', 'WP/dT2hcT0C', 'W6RdRGhcJa', 'r8kcsafg', 'WQCVg2eC', 'W74/W6VdMSkl', 'W43dHd/cOSoe', 'W7RdSCkrBCoo', 'WRdcH8ooWQD1', 'WPpcKmopmgK', 'WQ8Shq', 'WRnLoG7dMG', 'WOpcRhHje3hdVLdcTa', 'WP1cW67dLG', 'W4tdGb0GBq', 'yUkDQmoS8l6xV/cHL50', 'WO/cSYv4sq', 'W5XYW4FdQHS', 'WRddOCkkf8on', 'DSkuaLnl', 'WQTHhMWk', 'Ahnxbum', 'W5JdOWeTjW', 'eGHxWP/cQa', 'W4tdMXLGmG', '8kkkMSkZWQbTW5K', 'mSkmCmkkWQm8W4VdRHKBWPtdNq4', 'DIVcVSkSrW', 'W7ZdRHpcJmoX', 'sCkEW5e0AG', 'WQ3cNmo9smoP', 'v8kktWfl', 'W6VdPmkSuHe', 'W6yDW5bqW4q', 'W6JcOCoFa8kyW7WFWRype8onzqi', 'WRddVSkgvSoz', 'W5e2WODVW5C', 'W4HMW6RdKCkG', 'WOxdTxBdVKq', 'W4T8W6/dKmkM', 'WPWVkHldLG', 'W5tdGayMBq', 'vr3dGv5r', 'WP/dRgxdSe8', 'WQ8tW7xdRSkr', 'WO5rWO3dPJC', 'rXNdGqdcJG', 'WOxcRJZcPb0', 'WOGuAmocW5e', 'W7RdTmkOBSoN', 'WOldSXtcQmoK', 'mSocqHqB', 'WOxdVH/cOG', 'iIhcOSkSya', 'W63dUrpcN8o1', 'W7tdU8oRf18', 'pxFcUCkHDa', 'W7pcI8oiW7zKn13cRmktW4m3hW', 'bai1gmoH', 'WQuLWRxcNmovWR1Wu8oCW7ddL2u', 'W4ngaCkNWRxcU3RdRhhdV1pdUa', 'm3BdVCk5eKi/WPKLWPKypKG', 'WQGOfMLj', 'W5vjdSk3WO5Wjh3cNCk4AmofWPK', 'WOeBumoN', '8lsLQLtWRQEu8jY2LVc+TyW', 'urpdLW3cLG', 'B8kNDdb9', 'W4LMhZtdSmo3WPG', 'W7hcJCkeWPGmyftcRG', 'WRZcVCo6gq', 'WPlcS1D6vCkrWPFdKSkCW48hFq', 'WReaW47dQCoSW6XOWPqfBHBcGW', 'W4fLmW', 'yxWtEmof', 'W5GmqSk/oG', 'WQWJWQi', 'W5xcLfvUkq', 'jCokubK', 'WO/cGSoAW6ra', 'WRRdT8kw', 'W6ZdTSkv', 'W5P7W6/dMSkP', 'y3GgB8ou', 'W4FcUttcPbGEkGpcSSkgnIhdLW', 'W6dcOCozFmoCWQbaWO0G', 'rXtdSbBcJG', 'WQiNW4ZdJmk3', 'W5u0W64', 'W48WF0NcJq', 'W5eZW63cL0a', 'WRddJKVdG28', 'W4BdUJz2', 'W7RdOWFcGSoN', 'WQeXW53dMSk3', '8jABJwDDW4xdVW', 'hHj+W7JcVG', 'FxdcNmk4Fq', 'WRKuW4ldRCkZ', 'WQpdNmksWRv2', 'W6NdK8kCWRy2W6RcSKfkvZKy', 'DcqwWPlcIq', 'aCo0nSokWPe', 'WOTqpSk4ia', 'W7/cK8oyW6SJ', 'WPJdL0ZdKuq', 'ntGwdwC', 'WOpcJXbSCG', 'WOxcKmom', '8j22LVgoLAKg4P2wAq', 'g8kdEh1g', 'zdWC', 'W44AeCk7mW', 'WOJcKCoAm3S', 'DrG8WOhcGq', 'W7LYW6ldGmko', 'WP7dUrhdOSok', 'WQq2W7VdL8k1', 'W4iCxmkJW5q'];
    _0x3dd1 = function () {
      return _0x40fc5c;
    };
    return _0x3dd1();
  }
  function _0x10e0(_0x3086ad, _0x3875d7) {
    const _0x2c962c = _0x3dd1();
    _0x10e0 = function (_0x5e75ea, _0x5f18a3) {
      _0x5e75ea = _0x5e75ea - 199;
      let _0x200eb4 = _0x2c962c[_0x5e75ea];
      if (_0x10e0.EVFuvi === undefined) {
        var _0x352c3b = function (_0x139f9c) {
          let _0x35ce10 = '';
          let _0x19f373 = '';
          let _0x839929 = 0;
          let _0x4369b9;
          let _0x38f3ce;
          for (let _0x531eb4 = 0; _0x38f3ce = _0x139f9c.charAt(_0x531eb4++); ~_0x38f3ce && (_0x4369b9 = _0x839929 % 4 ? _0x4369b9 * 64 + _0x38f3ce : _0x38f3ce, _0x839929++ % 4) ? _0x35ce10 += String.fromCharCode(255 & _0x4369b9 >> (-2 * _0x839929 & 6)) : 0) {
            _0x38f3ce = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/='.indexOf(_0x38f3ce);
          }
          let _0x2e0ad1 = 0;
          for (let _0x1b7505 = _0x35ce10.length; _0x2e0ad1 < _0x1b7505; _0x2e0ad1++) {
            _0x19f373 += '%' + ('00' + _0x35ce10.charCodeAt(_0x2e0ad1).toString(16)).slice(-2);
          }
          return decodeURIComponent(_0x19f373);
        };
        const _0x4c2ce2 = function (_0x37fc48, _0x1e772e) {
          let _0x1b3cea = [];
          let _0x2aa194 = 0;
          let _0x39df76;
          let _0x245b00 = '';
          _0x37fc48 = _0x352c3b(_0x37fc48);
          let _0x15cfb1;
          for (_0x15cfb1 = 0; _0x15cfb1 < 256; _0x15cfb1++) {
            _0x1b3cea[_0x15cfb1] = _0x15cfb1;
          }
          for (_0x15cfb1 = 0; _0x15cfb1 < 256; _0x15cfb1++) {
            _0x2aa194 = (_0x2aa194 + _0x1b3cea[_0x15cfb1] + _0x1e772e.charCodeAt(_0x15cfb1 % _0x1e772e.length)) % 256;
            _0x39df76 = _0x1b3cea[_0x15cfb1];
            _0x1b3cea[_0x15cfb1] = _0x1b3cea[_0x2aa194];
            _0x1b3cea[_0x2aa194] = _0x39df76;
          }
          _0x15cfb1 = 0;
          _0x2aa194 = 0;
          for (let _0x493009 = 0; _0x493009 < _0x37fc48.length; _0x493009++) {
            _0x15cfb1 = (_0x15cfb1 + 1) % 256;
            _0x2aa194 = (_0x2aa194 + _0x1b3cea[_0x15cfb1]) % 256;
            _0x39df76 = _0x1b3cea[_0x15cfb1];
            _0x1b3cea[_0x15cfb1] = _0x1b3cea[_0x2aa194];
            _0x1b3cea[_0x2aa194] = _0x39df76;
            _0x245b00 += String.fromCharCode(_0x37fc48.charCodeAt(_0x493009) ^ _0x1b3cea[(_0x1b3cea[_0x15cfb1] + _0x1b3cea[_0x2aa194]) % 256]);
          }
          return _0x245b00;
        };
        _0x10e0.hJDFkp = _0x4c2ce2;
        _0x3086ad = arguments;
        _0x10e0.EVFuvi = true;
      }
      const _0x3d1dad = _0x2c962c[0];
      const _0x3e9c68 = _0x5e75ea + _0x3d1dad;
      const _0xd3d6e1 = _0x3086ad[_0x3e9c68];
      if (!_0xd3d6e1) {
        if (_0x10e0.KoYAnk === undefined) {
          _0x10e0.KoYAnk = true;
        }
        _0x200eb4 = _0x10e0.hJDFkp(_0x200eb4, _0x5f18a3);
        _0x3086ad[_0x3e9c68] = _0x200eb4;
      } else {
        _0x200eb4 = _0xd3d6e1;
      }
      return _0x200eb4;
    };
    return _0x10e0(_0x3086ad, _0x3875d7);
  }
  function _0x35e7c0(_0x1413a4, _0x24ecf4, _0x5a87c9, _0x5327a5, _0x185d44) {
    return _0x10e0(_0x5327a5 - 0x1ed, _0x185d44);
  }
  function _0x594136(_0x6c83c6, _0x316304, _0x274fe5, _0x99f55f, _0x405529) {
    return _0x10e0(_0x316304 + 0x312, _0x99f55f);
  }
  if (config.COMMAND_TYPE === "button") {
    const _0x4c2ce2 = {
      pattern: 'fb',
      alias: ["facebook"],
      use: ".fb https://www.facebook.com/100029474354770/videos/837567391064603/",
      react: '🎥',
      desc: "Download videos from facebook",
      category: "download",
      filename: __filename
    };
    cmd(_0x4c2ce2, async (_0x2e0ad1, _0x1b7505, _0x37fc48, {
      from: _0x1e772e,
      q: _0x1b3cea,
      prefix: _0x2aa194,
      reply: _0x39df76
    }) => {
      if (!_0x1b3cea || !_0x1b3cea.includes("facebook.com")) {
        return await _0x39df76("*Please enter a valid facebook url!*");
      }
      const _0x15cfb1 = _0x1b3cea.replace(/\?mibextid=[^&]*/, '');
      getFbVideoInfo(_0x15cfb1).then(_0x51aa17 => {
        let _0xa345e0 = [{
          'name': "cta_url",
          'buttonParamsJson': JSON.stringify({
            'display_text': "Watch on Facebook",
            'url': _0x1b3cea,
            'merchant_url': _0x1b3cea
          })
        }, {
          'name': "quick_reply",
          'buttonParamsJson': JSON.stringify({
            'display_text': "SD Quality",
            'id': _0x2aa194 + "downfb " + _0x51aa17.sd
          })
        }, {
          'name': "quick_reply",
          'buttonParamsJson': JSON.stringify({
            'display_text': "HD Quality",
            'id': _0x2aa194 + "downfb " + _0x51aa17.hd
          })
        }];
        const _0x3df192 = {
          image: _0x51aa17.thumbnail,
          header: '',
          footer: config.FOOTER,
          body: "`✦ 𝗙𝗔𝗖𝗘𝗕𝗢𝗢𝗞 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗𝗘𝗥 ✦`\n"
        };
        const _0xfabbab = {
          quoted: _0x37fc48
        };
        return _0x2e0ad1.sendButtonMessage(_0x1e772e, _0xa345e0, _0x1b7505, _0x3df192, _0xfabbab);
      })["catch"](_0x183230 => {
        console.log(_0x183230);
      });
    });
    const _0x35ce10 = {
      pattern: "downfb",
      react: '🎥',
      dontAddCommandList: true,
      filename: __filename
    };
    cmd(_0x35ce10, async (_0x427ca2, _0xc12924, _0x2301c0, {
      from: _0x3645a4,
      q: _0x596b7f,
      reply: _0x2b8a40
    }) => {
      try {
        if (!_0x596b7f) {
          return await _0x2b8a40("*Not Found!*");
        }
        const _0x4d5c25 = {
          url: _0x596b7f
        };
        const _0x33b27b = {
          video: _0x4d5c25
        };
        const _0x49f785 = {
          quoted: _0xc12924
        };
        await _0x427ca2.sendMessage(_0x3645a4, _0x33b27b, _0x49f785);
        const _0x2a1e0a = {
          text: '✅',
          key: _0xc12924.key
        };
        const _0x175075 = {
          react: _0x2a1e0a
        };
        await _0x427ca2.sendMessage(_0x3645a4, _0x175075);
      } catch (_0x50202a) {
        _0x2b8a40("*Error !!*");
        console.log(_0x50202a);
      }
    });
  }