(function (_0x373b5c, _0x3b5f03) {
    const _0x5b300d = _0x373b5c();
    while (true) {
      try {
        const _0x57f992 = parseInt(_0x3ea3(1197, 'kxxO')) / 1 * (-parseInt(_0x3ea3(734, 'xuxn')) / 2) + -parseInt(_0x3ea3(967, 'b8ea')) / 3 * (-parseInt(_0x3ea3(613, 'xuxn')) / 4) + -parseInt(_0x3ea3(953, 'zNeZ')) / 5 + parseInt(_0x3ea3(1117, 'dJj(')) / 6 * (parseInt(_0x3ea3(1085, 'vl%L')) / 7) + -parseInt(_0x3ea3(791, 'Z$Hw')) / 8 * (parseInt(_0x3ea3(660, ']i0f')) / 9) + -parseInt(_0x3ea3(705, 'gYC&')) / 10 + parseInt(_0x3ea3(1258, '4U4b')) / 11;
        if (_0x57f992 === _0x3b5f03) {
          break;
        } else {
          _0x5b300d.push(_0x5b300d.shift());
        }
      } catch (_0x2cce23) {
        _0x5b300d.push(_0x5b300d.shift());
      }
    }
  })(_0x4c38, 310864);
  const config = require("../settings");
  function _0x2ba76f(_0x45225a, _0x4b4b47, _0x451766, _0x508fe3, _0x7c3733) {
    return _0x3ea3(_0x45225a - 0x1a0, _0x4b4b47);
  }
  const {
    cmd,
    commands
  } = require("../lib/command");
  function _0x467c7a(_0xfe3eb, _0x5382b9, _0xa1d3b1, _0x43e7cb, _0x5ecbea) {
    return _0x3ea3(_0x5ecbea + 0x42, _0x43e7cb);
  }
  function _0x102af7(_0x2c5ee4, _0x373d05, _0x52969b, _0x116033, _0x37de53) {
    return _0x3ea3(_0x116033 + 0x158, _0x2c5ee4);
  }
  const {
    getBuffer,
    getGroupAdmins,
    getRandom,
    h2k,
    isUrl,
    Json,
    runtime,
    sleep,
    fetchJson
  } = require("../lib/functions");
  function _0x3a4561(_0x561721, _0x94723b, _0x25c615, _0x4a37ab, _0x470595) {
    return _0x3ea3(_0x4a37ab - 0xf4, _0x25c615);
  }
  const {
    unsplash,
    pixabay
  } = require("@sl-code-lords/image-library");
  function _0x261cdb(_0x4fde35, _0xcfa9ef, _0x12c13b, _0x3e9ef4, _0x39fc27) {
    return _0x3ea3(_0xcfa9ef + 0x1bf, _0x3e9ef4);
  }
  var desc4 = "Searche for related pics on bing.";
  var desc4 = "Searche for related wallpapers.";
  function _0x4c38() {
    const _0x59861c = ['k2pdKK8+', 'tSoUW5ufhW', 'b8kNW5pdISou', 'eu1kxCoA', 'xCoWFtHN', 'hCo7h8o3ga', 'WQhcKthcMCoN', 'fWxcSmk8W6W', 'Emo5fSkoW6S', 'kstcR0BdKa', 'WOBdG8o1DmkX', 'W7X7W6NcGmkP', 'W6LNW4DHeq', 'W4qWcMbt', 'b8o/ianI', 'Ca8eW7Hq', 'WPVcRx/cU8kR', 'W4e6W59GlW', 'FCo2hwHl', 'jdVcQhBdQW', 'gbhcTa', 'z8oDWOTQzW', 'o8k/m8oqW40', 'WP0KW4/cSCkC', 'pdBcOCkDW4S', 'WQhcKsVcNW', 'WQuYW4/cNSk1', 'oSkCnmkOrG', 'BGSpWRX1', 'WOpcTmocBSkE', 'xCkXsKW', 'W6XMW45Hdq', 'WQbEWR7cLmkT', '4BAk6P6f4BAx4BswYzG', 'WP7cGb3cO8kj', 'pu5kWPy8', 'WOeYq8kaaa', 'wwj3WOdWTBw5', 'kSoixSkp', 'W6NdLCoYoq', 'WOX1WRNcM8kD', 'zSo+d3Pc', 'W75eW60', 'k8kBhW', 'uSo0CdPS', 'nYZcMvxdIG', 'e3KZoSk9', 'BrSzW7q', 'W55FW5Lnda', 'W6WHW4nOFq', 'W7JdMCoenx4', 'y8o8cq', 'q8kApSkoW4q', 'CGbJW4un', 'WPfY8kw2PmkCna', 'y8o1fSknWOy', 'FYjIW44W', 'vSk3mCo6WPm', 'hSkinSkydG', 'WP1cWOldISoo', 'W6nRWOzthG', 'BW7cM8k2W5m', 'WOrQWQq', 'uZxcGCkAWOa', 'W5BdIdJcJG0', 'WRHmWRlcOSka', 'aWFdHxmw', 'o8kQiXBcJa', 'WQPIWRFdQSoR', 'f8o8me1f', 'WRL4WQddMSkM', 'DuNcN8kHWPq', 'qmkQW7FdQCoG', 'WO5Mqvn/', 'WPFcGb3dQ8oe', 'smo8FZLl', 'x8o2zJnL', 'WOZcMtNcM8ow', 'WOvcWPtdJmkm', 'WRpcKrlcQCoz', 'W6nEbW', 'cWRcTgtdIG', 'W4uJW4jToW', 'WOtcNmodvmku', 'bX3cVa', 'W68TW5q', 'hrBcQ2K', 'W77cNmoqtmoB', 'W7BdQbJcRI0', 'WQrIW7X6oa', 'dmkbW53dRSo2', 'kmk0W6ZdPmoG', 'WPdiP+g1Kmsr4Bw0', 'A8otvSksW6C', 'WRGavXuxzN9aW4hcLCkjW6K', 'e1HBsSon', 'CSkls8oOWQq', 'j8oPcW', 'W6XHW4yQ', 'oc3cLLFdVW', 'dX3cUmk4W6i', 'WPH2WPhcO8kV', 'gZNcRttdVW', 'DCk4s8oeW7W', 'ogaInCkL', 'WP3cHXpdMIC', 'hK3cRMtdLG', 'x2XDq8kv', 'DCoJc8kiWQW', 'fqddHhSF', 'WOlcJdhcV8oc', 'eHhdJMy', 'fCoZkez8', 'W78jW6ZcO8ki', 'pmohhc3cQW', 'kmongmoBlq', 'iCk2W7xILjVILju', 'WP80W47cOCk0', 'WOeYq8kadW', 'WRywWPOKW5K', 'W5jTdq', 'WRRcLCkWoSky', 'W6/dM8oOAa', 'W6ZdRSoJi2G', 'WQtcNmougG', 'W6zCauvd', 'BCoycZlcLWNdQ8ke', 'W6aOhHrE', 'W5JdUSowy8kT', 'a8oZkG', 'tGL1W6O', 'pIKkW7NdVa', 'WOy4dCkalq', 'n1NdOL8O', 'WRSkd8oFW50', 'ySoIe8kaWQy', 'kmkiwmkzCW', 'W5aGa1m2', 'tSkrk8okW5u', 'WRNdT8kQfCo+', 'FCo2hwK', 'iG3cLw/dLa', 'zCk2x+odShe', 'fbxcUmk8W7m', 'W6LEW5n8kW', 'WOjXWPldUmoV', 'WPddSCksn8o0', 'W51YkalJGkS', 'WOiGW5xcSmkJ', 'mgVdKKSV', 'nrhdL2as', 'WRvaWR3cJmkF', 'lxPNd+ocSG', 'Cqen', 'WRfqW48wWPS', 'W5Pyj8o3WPW', 'W6JcJSkSzSk5', 'vbOVW6BcGW', 'WPS6tmkdjW', 'aXFdGG', 'W6WWW4L/eq', 'WRZdI0pdHX4', 'yGtcGq', 'WQRcONtcSCk7', 'WPtcHgtcQ8k1', 'W7dcGNRcGSk8', 'jCkWbCowW7W', 'W6JdH8o/Cmk/', 'n3ZdNW', 'jrZcJZpdPG', 'WR3cGeFdKZS', 'zJb7W4OJ', '4BwPBmM/Y7JcLW', 'uCo6WODnwq', 'EqChW7S8', 'hK3dUfhdIa', 'WRfvr8kEWPe', 'W6fibMLe', 'WPOZW5tcSa', 'D8klnmk8dW', 'a8kyiCoRW4S', 'WPLoWOldNW', '8kQcSEkbPVc3SkiT4Bwv4Bw94BsY', 'W6JcK3xcLCkE', 'WQSZW5pcUSkJ', 'WQlcPxlcISkT', 'WOdcSbFcMSok', 'mmo+dCkeWQK', 'dshcGW', 'W6DCW7NcPa', 'WQBdSHhdOwS', 'WQBcJeFdKfK', 'WQHbu8kaWOvVW5zjW4ldINS', 'WQ3dSCkSq8o4', 'cqlcOa', 'WRPTWORdJmoa', 'WPWKWO/cTSk+', 'E8o1aq', 'e1zi', 'W6jDow1J', 'W7ddJCoGnL4', 'pXRcHwFdTa', 'zGdcKmkI', 'oSkZi8kpFG', 'W5HZW7VcLmkT', 'wwjWWQFcHa', 'Fmopzmo9aSo1rmk6hmkxdCob', 'W4C0W73dL8od', 'CSoulCkaWOy', 'kXZcMxldTG', 'AbWg', 'WR9iW7etW7q', 'BmktvSoKWQa', 'awpcLrtdHq', 'g8k6iKXG', 'W6ZdImoTf3i', 'WOa1W4xcPCkK', 'a23dLK8r', 'W7eta8osW5q', 'WPdcGb/cOCoh', 'W4vSW6pdK8kP', 'u8o0mu5W', 'WRxcN2dcJmk1', 'WOxdJSo+g8kX', 'W67dT8orfLi', 'WRddPaZdPe4', 'hbBcVxpdNq', '5lQxWRCOWQvO', 'WRVcOSkHWQzf', 'nxZdMLW+', 'W65SW7/cG8kK', 'pSkJW7/dUCoX', 'cmoM8lI0T++6Nq', 'WOlcJJlcJmo+', 'xx8QpSkP', 'W5L7W7VcL8kT', 'E8o2cJ1x', 'ACo8awLc', 'pmk0dmkq', 'wmo4WPPcqW', 'dCkMW77dM8o+', 'W73dLCoRDa', 'WPTBW6JcGCkN', 'AcaiW65p', 'wq1VW68T', 'WQ1mW44eW4y', 'W5z/W7pcNCoO', 'cSosfCk7ka', 'dNjFzmo2', 'vutdH3GJaJ/dKq', 'W6BdOmoNWRzf', 'WPXEWPxdN8oj', 'W50Kcvb5', 'Dmo5fCkoW6S', 'gmk1W7S', 'W41/WRxcJSkn', 'FWeoW6u', 'W5uolvfY', 'W5ivrmkpjW', 'W7yTW4XSkq', 'WQqgWO0IFq', 'iSk4b8ooW6K', 'WRNcLCk8xSoH', 'WO7dH8kr', 'c8kMicRcSa', 'WOpdLJxdJhS', 'WPP4WRZcLSkE', 'WOaSWQpdHSo5W6mSdSojWOddMLZcJhi', 'A8o2hx4', 'WRNdHv7dMaS', 'W5L3W7BcO8kwW6OjDG', 'EbXqWRW', 'WRD6WQRcNmoA', 'cmkNW63dRSkY', 'bqTUW70f', 'BYpcNUoaPhS', 'WP98WRhcMCkA', 'W7WJiMv8', 'WOFcIeJdKbW', 'ECo9gCkoWQ4', 'WRLaW6FcQW', 'zI3cGmkhWPy', '4BE14BwfWOhHT47HT5y', '4BAkeCU5YQ0g', 'W687i8o7W64', 'WOiUW4y', 'WRZdTmkQk8oQ', 'WRzvr+ocV8kC', 'WQxcS3y', 'qX/cJXRdHW', 'W51XW70', 'WQlcIKVcMbq', 'lCoPsmoC', 'WRhcH1dcJmk9', '4Bwv4BEus/c3S7hIGidWOOogmG', 'w8oDf8kqWPe', 'tGfSW6Xa', 'lSkih8ornW', 'W596b8oU8k+hJG', 'vapdPvmIoby', 'Dmo1eCkmWP8', 'WOy/E8kkgG', 'WOxdH1pcLmof', 'YiBlJog3PLFHTRO', 'jb/cRCoWW6u', 'WOTcWQddVSoC', 'hCkZW63dOW', 'W7ivdCkh', 'W7tdOmoNWRrt', 'emkRgConW6S', 'gcpdHHpdMa', 'sCo8Cd59', 'WQddPbO', 'WPm6sa', 'W5/dT8oemEodLq', 'WQiJWOBJGiHF', 'WR9BWRpdG8ou', 'zCk2wmo28kU0Ra', 'lCkbfd/cQq', 'bbVdKMS', 'q03dT23dJq', 'c2hcJ1RdHa', 'W6RdKrtcTJe', 'F8o0rSkpWRq', 'EmoiWO1MEW', 'W6a4W4rNdG', 'oCkmoSk/vW', 'WOVdLmkjcSoD', 'WRtcPfdcHSk0', 'WO/dH8kigW', 'AmkXi8kjna', 'o8kjct3dPq', 'W6ddLCoIDCku', 'CCojf8kLWP8', 'W6e6W4GU', 'gvzaw8oA', 'sqL1W64h', 'bSoLr1Syz0NdMe4/WOJcTq', 'EbWmW7b9', 'FmoNhhrj', 'WPFcLCkjb8oi', 'cr7cICkMW7e', 'fLrosmoA', '8y6cNokbLFgaKiHl4BAQ4Bsu4BA5', 'WRddTGZdOaK', 'W5SOcG', 'aWlcVmo+', 'ESo6wq', 'W65cguXf', 'W6vqWQddRmoa', 'oSo+aCkjpq', 'WPy+qmkdyG', 'i2pdLG', 'l8kPW6RcPmoW', 'ASooWRTErq', 'W5BcGmoaCx8', 'cLDCx8ot', 'qmkQDSoVWOS', 'osOUW7NdIa', 'A8ohvSkCW6C', '8k2sKEkbMpgnOONdPUg0JUg3M+g1Oa', 'jCoQpCk0kq', '4Bsu4BAxtUg0HUg0Oa', 'FaKpW68', 'W44jWOhdUmoX', 'nmkhW5RdG8ob', 'W6vmW6VcR8ko', 'q8kVW7pdRmkH', 'W7TPorry', 'oalcQfFdTG', 'pCkhf3FcGG', 'wCkXeqHm', 'Emk5eqTm', 'W7dcRMBcHmk7', 'W7ngW73cOSkw', 'cComdSoZcW', 'atT6c8kI', 'WQlcLsVcUSoz', 'W4ySqfD5', 'W6VdNCoGDmk2', 'W4ZdGSoOg28', 'W6xcKJ3cImoq', 'WQldUv/dReq', 'efHl', 'crRcLNay', 'WRJdVSkUemoV', '4Bs64BEFppc0GPRIGktXH4cC', 'W4jce1ba', 'WP5hWPpdImoj', 'W7BdHmoKFfC', 'e8oaECkxWOngnSozWRjCz0a', 'AWlcM8k2WOC', 'vcm0W7NdNq', 'W7JdPGhcVaa', 'YBRiKog1Umoj4BEg', 'xSk3Aq4/', 'yaBcNmk/W5m', 'j8klmCk4hq', 'aWRcMwddSa', 'jGpcTCoYW6q', 'WQFcMCkHpmo1', 'eokFNE+4K8knYBlHTk4', 'W6P9W5HLga', 'wCkYW7FdV8o9', 'dKXaw8oA', 'WQZcMt/cMmoC', 'b8o/pfC', 'DSokhSkLWPS', 'aaZdH0eA', 'x8o4ztW', 'oSozDmoQga', 'W6XEdq1H', 'WOL8WQpcMq', 'wX1KW7Kz', 'WQ/cLuZdHqO', 'hZ4jW6hdNG', 'tCoICSk8W5m', 'lCoOaCkDnG', 'tmoGBCkiW6a', 'vMpdIrddNG', 'WPpdGCkjdSol', 'W6Pce0nb', 'jSkSg8oqW7G', 'sCo8yIHL', 'WQrmW58qWPu', 'm8oBdq', 'mmoCwmkLW6S', 'WP4gWPVdM8of', 'dcddThCl', 'WOP4WRNcLmoo', 'WOJdNmktgCou', 'W53dM8oLECkq', '5lMOsfhcQYK', 'BSo+cW', 'dmkOcSogW78', 'WQXvW50AW5O', 'WR3cGeFdKZq', 'b1DaxSoh', 'iZ3cJ2NdMq', 'BXPZW6qs', 'ASoEs27dTxddQSktW6GOWOHU', 'exa2DCkV', 'W5tdLSkscmoD', 'imkQdG', 'W7dcLwhcHCoZ', 'W7TmW6tcQ8ko', 'yLVdGurX', 'W5/cNFcGPPijFa', 'WPRcJb3cO8oD', 'WP/cHbtdTW', 'WPtcPsRcTCoa', 'WOHzW4dcIW', 'W6JdLCo/Dmo4', 'wuyHW5Sm', 'W58xcCogW5e', 'WRNcRxlcJSk8', 'lwHLxSoz', 'hHFcQMJdIG', '5lUgAmo9lXq', 'WQWjW5dcUSkz', 'WONcJ3ddLtm', 'W7P/aLb1', 'pmoPb8kz', 'tSkGzCknWPm', 'z8ozWPfOyq', 'WPH0WOJcVSk7', 'W4mbW6bogG', 'mw1lEmoQ', 'fY4TW77dGa', 'WRdcHJq', 'bcxcIbdcLW', 'zmoIaCojWQO', 'rrP4', 'vhv1WQa', 'cCkJW63dQa', 'fSofn0z+', 'FSkohYZcPG', 'WRSEd8ohW58', 'W4WvhSokW7G', 'WPSdxSkGoG', 'WRGaW6VcNmkd', 'W5xcNxFcJqK', 'ySoEsWLC', 'WRJcHGhcQCoi', 'ACo6neHx', 'FSoow8oDW6q', 'bw08pCkT', 'taldHJVcLW', 'W4qOgKbZ', 'mmkQgmodW74', 's13dToodK8kN', 'xSkZAmom', 'W6yoW55FpW', 'W5aShvC', 'WQ3cGCotfmkl', 'ccxcIXa', 'qwhdI1RcMG', 'WQBdG8oyfSkv', 'r8o9BmkxW4q', 'WRZcPt7cVSk4', 'WO92WRtcGW', 'W4q8hvW', 'BSooWO1GzW', 'B8kFt8koBI3dR8o+zcpdUL4', 'WPxcHGJcUSoQ', 'DCk/dSowW7O', '6P+04BsKYkxHTA/cJW', 'gca6', 'WOJdKmktgSo1', 'DCoJsW', 'W4rdW4r9jq', 'W7KjW7RcPCkc', 'WP7dHdJcL0y', 'lGxcGtddJG', 'xmk2jWPm', '4BET4BETu+g3N+g2RG', 'pgqmmSkO', 'fWxcTSkRW6i', 'WPS0xSoelq', 'uCk3zq', 'drLDsSot', 'l8oCdCoxnW', 'ar3dKgS', 'xuyZnSk+', 'WPddGtlcJGS', 'vCkrk8oCW5m', 'W4a0W73JG7BdJG', 'W6riW5Tfkq', 'D8oXeCkhW6S', 'WOCSW4dcSSk0', 'W7RdGCo1nfW', 'WP7cS2tcKCkP', 'WQBcKXlcVmoz', 'W6PUe0Dk', 'iCkReSkcW7G', 'W7JdICoVFLy', 'g8kZqcHS', 'oYhcIghdGG', 'Amk9DCkoeG', 'BGCeW7TW', 'W7DrW5xcP8kn', 'W79Davfo', 'b8ozfmoRDG', 'W41iWPVdMq', 'vaJcGmkJWPa', 'k8kglIdcKG', '4BAv4BAbWQ7XIOgi4Okh8kAGMG', 'xtPWW6Gm', 'W5bQW7/cL8oO', 'WPCLx8klma', 'acOLW74', 'pCkWbCofWRK', 'tmoKWRX3rq', 'n8kfgZ/cOa', 'W4P2owPq', 'W4pdQWxcTsC', 'qmkHhXHm', 'WORcIhJcNqe', 'W4fdW6PJnW', 'ymoXdmkDWQ4', 'W6pdGJBcIaS', 'W44uW5pcUCo7', 'WQlcIK4', 'W6ddIWBdMXa', 'WP5WWR7cNCkc', 'W4jbWORdJSol', 'WRxcLsZcImow', 'WOSXWRxcLmkH', 'WOyOW4/cSSoX', 'tvNdUa', 'iCo2e8kBna', 'xmoFp8kM', 'W7ZdOCoVWRjf', 'bbVcGJVdLa', 'pCojemowEq', 'lSkjW5pdHSot', 'WPaIwCkqlq', 'euuRpmka', 'hCoHnmo5hG', 'cmkPmbhcLW', 'W5yMcK0', 'bCkJWR7dRCo9', 'eCkducij', 'WOFcGrtcJSo3', 'aYVdHxCD', 'WQ9HW6ZcKCoX', 'ac3cKHldHq', 'emkKnrNcGq', 'W6xdRCo6WQff', 'WQRcHf3dLG', 'ASkRcSovWQq', 'aSkNW7O', 'W6hdM8oUpSk1', 'WOX0WRu', 'iWBdHh0d', 'W65SW4P9uq', 'W5KOafa', 'fcNcHhNdKW', 'z8kAoSk9vW', 'we45W5LD', 'WPO5b1O2', 'e1Xbsmol', 'WQpcNgJdKsW', 'WRdcMGZcHmoK', 'oSkoW4y6jetdUHO3WQP9WQxdRCko', 'W5vXW63cNCkK', 'W4ncWPFdJmkE', 'ecaQW6tdHq', 'p8kAgtddUa', 'W4zCauvd', 'i38vomkl', 'W6GDbmoxW7e', 'WQpcPx3cJCku', 'x8kGESobWPm', 'n3RdH0C1', 'WRrnW5uaW5a', 'w8otWP5JBW', 'W6Tue0e', 'WQj7WPJcOmkL', 'wCo9gCkoWQ4', 'W4aOW4W', 'YRRjGog0K8oj4BEu', 'W6NdGCo1jv4', 'YyZjTog1ISko4BA9', 'W4vOW6blFq', 'WQjuW59A', 'qq14', 'aWBdHh0d', 'WOzIW645W6W', 'W4JdHSonm1O', 'gSo5nWn9', 'rs7cKSkwWOO', 'hSkJW7ddR8oF', 'W6ujW7JcQCkw', 'WPddKmke', 'WQ3cNSoDzmk9', 'mgTnBCon', 'pHLIA8kF', 'WP1BW5xdM8of', 'WQ4nW599mG', 'zSo+cxni', 'W7NdK37dGt7cVSklWQS', 'W4tdMCoTDSk9', 'Emk5mHPn', 'WQjrW5Wn', 'W5xdRSoHWRzi', 'Fmo7aM1M', 'pCoOfW', 'W7ZdKSk7Cq', 'fSk6cJxcGq', 'wqBdL2vm', 'W7CMW4j7eq', 'WOKlWPVdHCov', 'W4jQW6JcMSkM', 'WRNcNCoMD8k1', 'pmklimkU', 'wmk3a0Xg', 'W6jBW6y', 'W7XmW7m', 'BgtdG08', 'W73dGCo/Eq', 'kX3cJZi', 'iINcQMFdJW', 'k8ooWPPJDa', 'jSozeSkKxq', 'ESoHaG', 'ArLxW4Ks', 'WOHlW4KgW5m', 'W6hdOXBdSuy', 'W6KbqmktWOy', 'W4HOW6WVdG', 'WO7dOSklemoQ', 'W7qkeW', 'srXGW5qv', 'W5bZW78', 'qmooWRTQDa', 'W73dLCo8FCkS', 'cCksdqZcRW', 'WR5eWO/dMCop', '4BwO4BAEzog0Uog0Lq', 'WQhcVaNcLmoB', 'yWJcM8kLWRi', 'dCklj8kKqa', '4PEIW6BcTmocW58', 'vmknymkoWOO', 'WPBcG8ofqSkI', 'W7dcPNBcNCk6', 'W5TfnvHe', 'WRn6W7H+eYfXWQa', 'W51bkuPE', 'ptWZW6ldOW', 'WRLaW6FcQ8oo', 'WQLLWOCf8kI1JW', 'EmootmkiW7G', 'xSk3B8oo', 'W7FdRHRcUY8', '4BsoWPZjPSQanq', 'W6CNW4aGgG', 'hG/cSwldGq', '4BwK4Bs9d+g0Tog2Ua', 'kConf8oCfa', 'WRVcL0u', 'W5NdIJBcNq0', 'WQVcG2xdLqe', 'W7DsogrF', 'WPNcLupdNbW', 'WOTeWPxdN8oj', 'W4rmW6VcVSkz', 'DNRdMLW0', 'W5zMdvT7', 'W4hdKJJcJG0', 'k8o6bSkznG', 'o8kCo8kVFW', 'WRNcNvpdMYK', 'dLnSwmox', 'u8o8ivDX', 'zaBcHCkLWPO', 'uvnFsa', 'ytZcG37dOq', 'W70+W5xdK8kj', 'WQFcH8oDxSki', 'kSonwSkjW7C', '8k+2SU+6Va', 'ASoGhxXa', 'W6P8gvD0', 'bupcVM7dLG', '8jw3Lo+4JG', 'WQLtW4m2W7S', 'W7ZdK8oYmfW', 'W7/dIG3cQcS', 'D8kfu8kY8kM0Vq', 'W6FdQCo9WQbm', 'WRFcM8kJCmk0', 'wmo3WQ/cUCkKW6OdW5mVW7TIW6xcHq', 'brxdGNCw', 'WP/cHVc8T4iaWQa', 'q8kqi8opWP8', 'y8ogxSkAW7e', 'k8oDfSompa', 'WOy/rmkkjq', 'W7pdO8oHWQff', 'W5mqivj/', '8kscRUkcK/c9OkNdUEg0K+g2Oog1Ta', 'WQLDW5qtW4e', 'WPCLf8oe', 'FSk5qHHi', 'oCk2da', 'B8kZiCoNW70', 'W7jAW7NcRCkD', 'kbhcQM7dLG', 'xIBcSCkzWQa', 'W7yMgHT0', 'imoWawTc', 'W4fOW4dcHCkO', 'cKjqW74f', 'g8kPlcVcKa', 'qWvGW6Wf', 'DalcM8k1WRe', 'lmkngZVcSq', 'W7hdPCoJWRi', 'W6SrcCoaWPW', 'W7RcKuddGXy', 'W7ZcKNRdTIRcRmkE', '8kkqP+kbKpc9Sjj54BAL4BAR4BwG', 'W74kgmoCW44', 'W4e7aG', 'WP4YamkZiW', 'W4/dVVcPL6VcK0e', '5lQSyCo0W7xcNW', 'W5bTW7i', 'W7xcHWtcVYK', 'WOFcMYZdK8or', 'WOBcHq7cVSob', 'WPm+q8ollW', 'emo5omoNW5G', 'WPj3W70xW6y', 'fxK/', 'WQhcTxZcNCk8', 'WQVcLLRdLH4', 'WRFdR8kLhCo5', 'kq7cG33cSq', 'n8oDm2rM', 'zcXEW585', 'B8oytmkCW7m', 'W5GjpmoXW44', 'WQJcSLRcGCks', 'oIxcQgBdIa', 'WPRcJeNdPa', 'W4ldNN3dMLi', 'dZJcJXJdMq', 'cSkVW7JdSG', 'bN0VoCoG', 'WOm5WQxcLmkD', 'eWddGN0F', 'hc3cKGpdKG', '8j21Qo+4Sa', '8yk1LE+5Va', 'WOzoWOm', 'WP9sW5dcI8kw', 'smojfCkFWRO', 'yGBcHSk0W5m', 'oSo+e8kFjq', 'W50Kd1nZ', 'WRldGmkrA8kk', 'WORdGmkscSoD', 'W55eW6VcQ8kF', 'AbxcJa', 'hqBcNwNdNa', 'g8oZkKqY', 'W7fPpxfx', 'f1bbsmkF', 'F8oMhxu', 'A8o2Edvb', 'c8kVW7ldRSo8', 'b8kDhmoAW6W', 'Bh7WSRsfuwi', 'mLXCxmoE', '4BA04BwetVcsKB7IG57WN6cO', 'WPHfWQ7dK8o7', 'dSkTiMq6W6PeW4mCwComWOm', 'C8oBwSoD8lQrIa', 'W7RdHtxcMWa', 'DZOOW7LM', 'WOPcWPZdKG', 'W4j4WPpdHSoC', 'W7dcHtpcU8o5', 'p8k/W4BdGSoR', 'emo/mCkaW58', 'g3G7pmkR', 'gd7cN1FdLG', 'ySo1c8kCWQC', 'W6ddVmowwmkt', 'pb3cGxRdVa', 'WOPWWRBcGW', 'WO3dRCkxbSoz', 'qmoQgCkrWRS', 'tGRcLmk2WPy', 'WOKOW4FcRa', 'oSkhdtBcQq', 'drDfx8oy', 'sCoGcuvx', 'WPe2wCkbjq', 'AmouDCkpeG', 'W7Kan1fc', 'W5ylW6uV44gq', 'pI3dM2qa', '4Bw3nCUdY5tdRG', 'tSoeWP5Izq', 'W7CTW4nRea', 'hsi8W63dJa', 'WRhcUvBcJCkC', 'nqpcGmk2W6a', 'WQiJWOyPuG', 'vX3cLmkPWOm', 'WQpcTghcGmk3', 'zSoouCkAW6a', 'WQdcGGC', 'lX3cUmk4W6i', 'os7cJZ3dOW', 'gCkUW6VdQCk8', 'Fr/cN8ktWOO', 'WRNdUb3cQKq', 'WQxdTGVdSuW', 'erLiqmoq', 'gcNcNGm', 'lepcLuxcHa', 'b2eUnmkG', 'FbWt', 'hYOK', 'gSkkmmkGwG', 'WOyKW4dcSCk0', 'WR/dSSkkoCom', 'aGlcVa', '8k2tS+kbV/gaK6OS4BA44BsG4BwT', 'WR/dHCkUWRzp', 'W4xdSWtcGba', 'zKBXHRwGWPFdSq', 'FSoswG', 'yHxcH8k+WOe', 'WQJdKmkCdmoB', 'WPqQd0y', 'WQFcIeJdKbW', 'u8oWFZOP', 'wqPSW6Wy', '8k2uP++5Vq', 'WRtcLxRdSWW', 'kCkuma', 'g8kJmq', 'W5z/W6NcTCkI', 'vCkNuqXj', 'W7Tugfy', 'WRxcO2C', 'r8kel8oC', 'yCoorG', 'c1fAtCkr', 'cqFcM27dIq', 'hdSPW7RdMG', 'bSkAp8odW5i', 'mHVdULSR', 'WP3cIN3dSpcLPiC', '4BEZW4NlQSMlWOK', 'fHhcVSk6', 'W4NdPmoia3a', 'WOjzWOm', 'W77cQx4', 'vCk7hHHO', 'W51YW6RcKSk4', 'mJVdPeOW', 'W6jAW68', 'BGSeW7Hr', 'WQldTHpdQvK', 'W5Gnc0Dm', 'YjxkUEg0RW/HTRi', 'DSkNtmokWRa', 'frxcOxtdQW', 'fYaWWQxdRG', 'FSoMawLc', '4Bsg4BwQsUg2H+g0MW', 'W5JdHmo+WQ1M', 'gCk0W6FcQ8oZ', 'tSo1DtmU', 'bGm1W5/dNG', 'pmk0cSofW7W', 'W7yTW556mq', 'W6RdHCoVnxy', 'WOH4WQpcN8oo', 'W64kbG', 'jr/cV8kBW4m', 'cqBcVaBdNq', 'W6VcJSoRivW', 'WRFcQxxcKa', 'eCkYfrHk', 'mMLUqmon', 'dSojcCkyeq', 'y8ktwmoLWQe', 'rSkRDreKdCktW7ZdUSk+WOHFW5S', 'WQbCW5mvWPO', 'ardcRgddLG', 'WRD3FSkHaW', 'tfNcMZ9C', '4BEU4BwmWOhXIOk54Okf8kIYNa', 'gSkxpmo/W5i', 'gmo6hCk/gq', 'DCkvs8oTWRK', 'pvrk', 'dapdU3uy', 'WOFcNbZcSmom', 'bSkJW6C', 'jYNdLCkDW5m', 'cHhcRCk6W7u', 'eCktmEkxKIK', 'W4Tyk8ktW6W', 'n2COnmk8', 'cHxdGNCd', 'WQNcI8krxCkj', 'WP90W6RcLa', 'W6jAW7/cVSkE', 'khzOtmoS', 'WP02sq', 'mwVdKLO4', 'eJOUW57dJa', 'WOJcG8oqxmkd', 'jmkxW7FdUSoN', 'p8kbfhFcQa', 'wCoiWRnoqW', 'W7ddJmo1nfO', 'W6nmW7lcUa', 'W6b8W5i', 'WP58WR7cNSkJ', 'WQJcG8oqxmkd', 'rc8dW7Ts', 'bGBcOq', 'W4ndmgPT', 'd0/cRJpdLa', 'WRhcKsdcIa', 'WPxcIaFcOCoo', 'zHFcKmkJ', 'WQtcJ8ocxSog', 'W6DOW7NcUSkr', 'fbxcQSkQW6S', 'WPaJA8ktiq', 'd8oLkSkBW4uzWQddQLFdLSk5AW', 'uK16gSoU', 'W77dGmkZySk9', 'CCo9hq', 'nSoecCozkq', 'WRBcKtBcMmo+', 'WQldNSo8Dmk/', 'WRlcOWJcU8oA', 'jSouhLfN', 'rmkooqnO', 'W75ed1zd', 'ifysE+odGW', 'b2C2', 'WQXkp8ocW7jqW7vn', 'oCksbSooWQ3dU8otctdcKXS', 'i8o+cW', 'k8osWOPIDW', 'iatcRSk1W64', '4Bs0W7tlQCUJcq', 'qWbUW7KT', 'WQddPrm', 'pG/cRLFJGRO', 'W63dLmoOp1W', 'W7XIW5ZcTmk9', 'YPJlL+g0RCoe4Bwp', 'x8kdvSoxWR4', 'vWBcMSksWRS', 'Amo9f8kimG', 'WQ9BW5LOvq', 'xSo9EdWM', 'E8o2fMK', 'WQblW4KvW5i', 'eZ7cU8kTW5q', '4PAp4Pso4PAR4Pse4Pw/', 'W4CLb1DZ', 'WRxILipcRSo/8jEmPW', 'fbhdL3ef', 'nwdcK0e2'];
    _0x4c38 = function () {
      return _0x59861c;
    };
    return _0x4c38();
  }
  function _0x3ea3(_0x96cb76, _0x464394) {
    const _0x3174d5 = _0x4c38();
    _0x3ea3 = function (_0x1beaed, _0x231ac7) {
      _0x1beaed = _0x1beaed - 445;
      let _0x4105e9 = _0x3174d5[_0x1beaed];
      if (_0x3ea3.sRbrzm === undefined) {
        var _0x4d7902 = function (_0x2f36bf) {
          let _0x4cb2f8 = '';
          let _0x137fcb = '';
          let _0x2385e8 = 0;
          let _0x11b29c;
          let _0x31bb32;
          for (let _0x3b5d91 = 0; _0x31bb32 = _0x2f36bf.charAt(_0x3b5d91++); ~_0x31bb32 && (_0x11b29c = _0x2385e8 % 4 ? _0x11b29c * 64 + _0x31bb32 : _0x31bb32, _0x2385e8++ % 4) ? _0x4cb2f8 += String.fromCharCode(255 & _0x11b29c >> (-2 * _0x2385e8 & 6)) : 0) {
            _0x31bb32 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/='.indexOf(_0x31bb32);
          }
          let _0x36b7c6 = 0;
          for (let _0xa8d731 = _0x4cb2f8.length; _0x36b7c6 < _0xa8d731; _0x36b7c6++) {
            _0x137fcb += '%' + ('00' + _0x4cb2f8.charCodeAt(_0x36b7c6).toString(16)).slice(-2);
          }
          return decodeURIComponent(_0x137fcb);
        };
        const _0xcb0f88 = function (_0x2b8f98, _0x745852) {
          let _0x5c15d6 = [];
          let _0x1df1fb = 0;
          let _0x47e51;
          let _0xabc556 = '';
          _0x2b8f98 = _0x4d7902(_0x2b8f98);
          let _0x42e110;
          for (_0x42e110 = 0; _0x42e110 < 256; _0x42e110++) {
            _0x5c15d6[_0x42e110] = _0x42e110;
          }
          for (_0x42e110 = 0; _0x42e110 < 256; _0x42e110++) {
            _0x1df1fb = (_0x1df1fb + _0x5c15d6[_0x42e110] + _0x745852.charCodeAt(_0x42e110 % _0x745852.length)) % 256;
            _0x47e51 = _0x5c15d6[_0x42e110];
            _0x5c15d6[_0x42e110] = _0x5c15d6[_0x1df1fb];
            _0x5c15d6[_0x1df1fb] = _0x47e51;
          }
          _0x42e110 = 0;
          _0x1df1fb = 0;
          for (let _0x942761 = 0; _0x942761 < _0x2b8f98.length; _0x942761++) {
            _0x42e110 = (_0x42e110 + 1) % 256;
            _0x1df1fb = (_0x1df1fb + _0x5c15d6[_0x42e110]) % 256;
            _0x47e51 = _0x5c15d6[_0x42e110];
            _0x5c15d6[_0x42e110] = _0x5c15d6[_0x1df1fb];
            _0x5c15d6[_0x1df1fb] = _0x47e51;
            _0xabc556 += String.fromCharCode(_0x2b8f98.charCodeAt(_0x942761) ^ _0x5c15d6[(_0x5c15d6[_0x42e110] + _0x5c15d6[_0x1df1fb]) % 256]);
          }
          return _0xabc556;
        };
        _0x3ea3.ABfbPx = _0xcb0f88;
        _0x96cb76 = arguments;
        _0x3ea3.sRbrzm = true;
      }
      const _0x23b6fe = _0x3174d5[0];
      const _0x3abe4a = _0x1beaed + _0x23b6fe;
      const _0x3ca62e = _0x96cb76[_0x3abe4a];
      if (!_0x3ca62e) {
        if (_0x3ea3.SgfchB === undefined) {
          _0x3ea3.SgfchB = true;
        }
        _0x4105e9 = _0x3ea3.ABfbPx(_0x4105e9, _0x231ac7);
        _0x96cb76[_0x3abe4a] = _0x4105e9;
      } else {
        _0x4105e9 = _0x3ca62e;
      }
      return _0x4105e9;
    };
    return _0x3ea3(_0x96cb76, _0x464394);
  }
  if (config.COMMAND_TYPE === "button") {
    const _0x31cb29 = {
      pattern: "img",
      react: "🗃️",
      desc: "image list.",
      category: "download",
      use: ".img",
      filename: __filename
    };
    cmd(_0x31cb29, async (_0xef6b3, _0x117129, _0xc5de5f, {
      from: _0xc0e444,
      q: _0x39fb3e,
      prefix: _0xc8359c,
      pushname: _0x4983cb,
      reply: _0x15cab5
    }) => {
      try {
        const _0x4ca7a7 = "X-BYTE POWERED BY TALKDROVE\n   \n ▏ *IMG-DOWNLOADER*\n\n ▏ *🎭 ʀᴇǫᴜᴇꜱᴛᴇʀ: " + _0x4983cb + "*\n ▏ *✏️ ʀᴇꜱᴜʟᴛ: " + _0x39fb3e + "*\n\n└──────◉";
        let _0x39eb11 = [{
          'name': "cta_url",
          'buttonParamsJson': JSON.stringify({
            'display_text': "see in google",
            'url': _0x39fb3e,
            'merchant_url': _0x39fb3e
          })
        }, {
          'name': "quick_reply",
          'buttonParamsJson': JSON.stringify({
            'display_text': "Normal type 🖼️",
            'id': _0xc8359c + "imgno " + _0x39fb3e
          })
        }, {
          'name': "quick_reply",
          'buttonParamsJson': JSON.stringify({
            'display_text': "Document type 📂",
            'id': _0xc8359c + "imgdoc " + _0x39fb3e
          })
        }];
        const _0x38c410 = {
          image: config.LOGO,
          header: '',
          footer: config.FOOTER,
          body: _0x4ca7a7
        };
        const _0x5461fb = {
          quoted: _0x117129
        };
        return await _0xef6b3.sendButtonMessage(_0xc0e444, _0x39eb11, _0xc5de5f, _0x38c410, _0x5461fb);
      } catch (_0x3369d4) {
        _0x15cab5("*Error !!*");
        console.log(_0x3369d4);
      }
    });
    const _0x5aa963 = {
      pattern: "dimg",
      dontAddCommandList: true,
      filename: __filename
    };
    cmd(_0x5aa963, async (_0x59aabc, _0x28d4c0, _0x261e12, {
      from: _0x11cfbe,
      l: _0x13478e,
      quoted: _0x57c7b6,
      body: _0x4d6139,
      isCmd: _0x5b0388,
      command: _0x33b361,
      args: _0x532c35,
      q: _0x30875d,
      isGroup: _0xa286c9,
      sender: _0x4a7f11,
      senderNumber: _0x441aab,
      botNumber2: _0x4f2695,
      botNumber: _0x769404,
      pushname: _0x56e10a,
      isMe: _0x2f43e0,
      isOwner: _0x42adf9,
      groupMetadata: _0x3c410c,
      groupName: _0x4ad29f,
      participants: _0x2f19f8,
      groupAdmins: _0x4effc4,
      isBotAdmins: _0x1d12b1,
      isAdmins: _0x494bf7,
      reply: _0x383bf1
    }) => {
      try {
        const _0x18e304 = {
          text: '🔃',
          key: _0x28d4c0.key
        };
        const _0x4abb8a = {
          react: _0x18e304
        };
        await _0x59aabc.sendMessage(_0x11cfbe, _0x4abb8a);
        const _0x48639 = {
          url: _0x30875d
        };
        const _0x21c1fe = {
          image: _0x48639,
          caption: config.FOOTER
        };
        const _0xcd3f1f = {
          quoted: _0x28d4c0
        };
        await _0x59aabc.sendMessage(_0x11cfbe, _0x21c1fe, _0xcd3f1f);
        const _0x22274d = {
          text: '✔',
          key: _0x28d4c0.key
        };
        const _0x52bd53 = {
          react: _0x22274d
        };
        await _0x59aabc.sendMessage(_0x11cfbe, _0x52bd53);
      } catch (_0xe41464) {
        _0x383bf1("*I couldn't find anything :(*");
        console.log(_0xe41464);
      }
    });
    const _0x1cd5ea = {
      pattern: "img2",
      react: "🖼️",
      alias: ["unsplash"],
      desc: "Search for related pics on unsplash.com.",
      category: "download",
      use: ".img2 car",
      filename: __filename
    };
    cmd(_0x1cd5ea, async (_0x1f930d, _0x5172d7, _0x358003, {
      from: _0x3ffff2,
      l: _0x5876bc,
      prefix: _0x2fc437,
      quoted: _0x3aeb16,
      body: _0x3064ab,
      isCmd: _0x12551b,
      command: _0x49150b,
      args: _0x4be916,
      q: _0x31c784,
      isGroup: _0x5492c5,
      sender: _0x296094,
      senderNumber: _0x32e9b2,
      botNumber2: _0x1bdf7c,
      botNumber: _0x254d3e,
      pushname: _0x394403,
      isMe: _0x2978bd,
      isOwner: _0xdd1460,
      groupMetadata: _0x1cc266,
      groupName: _0x2449a1,
      participants: _0x549b9f,
      groupAdmins: _0x48ef19,
      isBotAdmins: _0x1f9839,
      isAdmins: _0x20d7c7,
      reply: _0x176652
    }) => {
      try {
        if (!_0x31c784) {
          return await _0x176652("```Please write a few words!```");
        }
        const _0x4849a2 = {
          query: _0x31c784,
          page: 0x1
        };
        const _0x43db1d = await unsplash.search(_0x4849a2);
        const _0x308a0f = {
          text: N_FOUND
        };
        const _0x593c78 = {
          quoted: _0x5172d7
        };
        if (_0x43db1d.result.length < 1) {
          return await _0x1f930d.sendMessage(_0x3ffff2, _0x308a0f, _0x593c78);
        }
        var _0x26958e = [];
        let _0x250e8d = 1;
        for (var _0x1acac2 = 0; _0x1acac2 < _0x43db1d.result.length; _0x1acac2++) {
          _0x26958e.push({
            'rows': [{
              'title': "Image number: " + _0x250e8d++,
              'id': _0x2fc437 + "dimg " + _0x43db1d.result[_0x1acac2]
            }]
          });
        }
        const _0x35f045 = [{
          'name': "single_select",
          'buttonParamsJson': JSON.stringify({
            'title': "Tap Here!",
            'sections': _0x26958e
          })
        }];
        const _0x1867b2 = {
          image: "https://github.com/G4tito/Simple-WaBot/blob/main/media/image/cover.jpg?raw=true",
          header: '',
          footer: "X-BYTE POWERED BY TALKDROVE",
          body: "乂 U N S P L A S H - D O W N L O A D E R "
        };
        const _0x48c2c8 = {
          quoted: _0x5172d7
        };
        return await _0x1f930d.sendButtonMessage(_0x3ffff2, _0x35f045, _0x358003, _0x1867b2, _0x48c2c8);
      } catch (_0x388cff) {
        _0x176652("*I couldn't find anything :(*");
        _0x5876bc(_0x388cff);
      }
    });
    const _0x13a73e = {
      pattern: "img3",
      react: "🖼️",
      alias: ["pixabay"],
      desc: "Search for related pics on pixabay.com.",
      category: "download",
      use: ".img3 car",
      filename: __filename
    };
    cmd(_0x13a73e, async (_0x410f1a, _0x35c1c3, _0x19334e, {
      from: _0x322cd0,
      l: _0x410a68,
      prefix: _0x350d64,
      quoted: _0x31de6d,
      body: _0x6f5e74,
      isCmd: _0x271bd1,
      command: _0x4e34d6,
      args: _0x1b59c3,
      q: _0x2c3e66,
      isGroup: _0x378d36,
      sender: _0x12f59e,
      senderNumber: _0x3678d6,
      botNumber2: _0xb226b8,
      botNumber: _0x32b0ab,
      pushname: _0x3d06e6,
      isMe: _0xe67224,
      isOwner: _0x251894,
      groupMetadata: _0x7d92b7,
      groupName: _0x1c978e,
      participants: _0x3019d0,
      groupAdmins: _0x1d84e8,
      isBotAdmins: _0x19b66a,
      isAdmins: _0x464896,
      reply: _0x4a1e93
    }) => {
      try {
        if (!_0x2c3e66) {
          return await _0x4a1e93("```Please write a few words!```");
        }
        const _0x1427d0 = {
          query: _0x2c3e66,
          page: 0x1
        };
        const _0x391d43 = await pixabay.search(_0x1427d0);
        const _0x3d16f9 = {
          text: N_FOUND
        };
        const _0x329f67 = {
          quoted: _0x35c1c3
        };
        if (_0x391d43.result.length < 1) {
          return await _0x410f1a.sendMessage(_0x322cd0, _0x3d16f9, _0x329f67);
        }
        var _0x4e9d23 = [];
        let _0x5d31b1 = 1;
        for (var _0xfa8349 = 0; _0xfa8349 < _0x391d43.result.length; _0xfa8349++) {
          _0x4e9d23.push({
            'rows': [{
              'title': "Image number: " + _0x5d31b1++,
              'id': _0x350d64 + "dimg " + _0x391d43.result[_0xfa8349]
            }]
          });
        }
        const _0x2ace45 = [{
          'name': "single_select",
          'buttonParamsJson': JSON.stringify({
            'title': "Tap Here!",
            'sections': _0x4e9d23
          })
        }];
        const _0x505d07 = {
          image: "https://github.com/G4tito/Simple-WaBot/blob/main/media/image/cover.jpg?raw=true",
          header: '',
          footer: "X-BYTE POWERED BY TALKDROVE",
          body: "乂 P I X A B A Y - D O W N L O A D E R "
        };
        const _0x156542 = {
          quoted: _0x35c1c3
        };
        return await _0x410f1a.sendButtonMessage(_0x322cd0, _0x2ace45, _0x19334e, _0x505d07, _0x156542);
      } catch (_0x4b106f) {
        _0x4a1e93("*I couldn't find anything :(*");
        console.log(_0x4b106f);
      }
    });
    const _0xd7d45c = {
      pattern: "wallpaper",
      react: "🖼️",
      alias: ["img4", "wallp", 'wp'],
      desc: desc4,
      category: "download",
      use: ".img4 car",
      filename: __filename
    };
    cmd(_0xd7d45c, async (_0x174293, _0x54610e, _0x57cab0, {
      from: _0x3e1176,
      l: _0x331a08,
      prefix: _0x3e5e00,
      quoted: _0x57290a,
      body: _0x34b027,
      isCmd: _0x2d3d09,
      command: _0x35b1e7,
      args: _0x440a6b,
      q: _0xe64f3c,
      isGroup: _0x54edd7,
      sender: _0x5eedcc,
      senderNumber: _0x3aa14f,
      botNumber2: _0x221f27,
      botNumber: _0x12ab57,
      pushname: _0x5b918f,
      isMe: _0x494fdc,
      isOwner: _0x2bd48d,
      groupMetadata: _0x403df4,
      groupName: _0x3c66f7,
      participants: _0x3a8139,
      groupAdmins: _0x44f02f,
      isBotAdmins: _0x5c420e,
      isAdmins: _0x3b65ad,
      reply: _0x3d14a0
    }) => {
      try {
        if (!_0xe64f3c) {
          return await _0x3d14a0("```Please write a few words!```");
        }
        let _0xd4373c = await wallpaper(_0xe64f3c);
        const _0x32c9e2 = {
          text: N_FOUND
        };
        const _0x1d303c = {
          quoted: _0x54610e
        };
        if (_0xd4373c < 1) {
          return await _0x174293.sendMessage(_0x3e1176, _0x32c9e2, _0x1d303c);
        }
        var _0x4c8b82 = [];
        let _0x21a8ec = 1;
        for (var _0x13ab1b = 0; _0x13ab1b < _0xd4373c.length; _0x13ab1b++) {
          _0x4c8b82.push({
            'rows': [{
              'title': "Image number: " + _0x21a8ec++,
              'description': "Source: wallpaperflare.com",
              'id': _0x3e5e00 + "dimg " + _0xd4373c[_0x13ab1b]
            }]
          });
        }
        const _0x3f305f = [{
          'name': "single_select",
          'buttonParamsJson': JSON.stringify({
            'title': "Tap Here!",
            'sections': _0x4c8b82
          })
        }];
        const _0x4b6174 = {
          image: "https://github.com/G4tito/Simple-WaBot/blob/main/media/image/cover.jpg?raw=true",
          header: '',
          footer: "X-BYTE POWERED BY TALKDROVE",
          body: "乂 W A L L P A P E R - D O W N L O A D E R "
        };
        const _0x1cf014 = {
          quoted: _0x54610e
        };
        return await _0x174293.sendButtonMessage(_0x3e1176, _0x3f305f, _0x57cab0, _0x4b6174, _0x1cf014);
      } catch (_0x28c5f2) {
        _0x3d14a0("*I couldn't find anything :(*");
        console.log(_0x28c5f2);
      }
    });
    const _0x2415f1 = {
      pattern: "dimg",
      dontAddCommandList: true,
      filename: __filename
    };
    cmd(_0x2415f1, async (_0x3dd560, _0x2a937a, _0x13cb3d, {
      from: _0xe35cce,
      l: _0x2b59fb,
      quoted: _0x5ac26b,
      body: _0x152557,
      isCmd: _0x1eed38,
      command: _0x597292,
      args: _0x354bc2,
      q: _0x57337a,
      isGroup: _0x445afb,
      sender: _0x2901bd,
      senderNumber: _0xc3715f,
      botNumber2: _0x463c55,
      botNumber: _0x193218,
      pushname: _0x40c89b,
      isMe: _0x13b402,
      isOwner: _0x1250dd,
      groupMetadata: _0x9ffcd2,
      groupName: _0x245d3f,
      participants: _0x2ccc46,
      groupAdmins: _0x25ff73,
      isBotAdmins: _0xd45c50,
      isAdmins: _0x4afd8e,
      reply: _0x343174
    }) => {
      try {
        const _0x142817 = {
          text: '🔃',
          key: _0x2a937a.key
        };
        const _0x248c63 = {
          react: _0x142817
        };
        await _0x3dd560.sendMessage(_0xe35cce, _0x248c63);
        const _0x5b27e6 = {
          url: _0x57337a
        };
        const _0x248544 = {
          image: _0x5b27e6,
          caption: "X-BYTE POWERED BY TALKDROVE"
        };
        const _0x58387b = {
          quoted: _0x2a937a
        };
        await _0x3dd560.sendMessage(_0xe35cce, _0x248544, _0x58387b);
        const _0x5dbe75 = {
          text: '✔',
          key: _0x2a937a.key
        };
        const _0x5a015d = {
          react: _0x5dbe75
        };
        await _0x3dd560.sendMessage(_0xe35cce, _0x5a015d);
      } catch (_0x52452b) {
        _0x343174("*I couldn't find anything :(*");
        console.log(_0x52452b);
      }
    });
    const _0x1816b7 = {
      pattern: "pin",
      react: "🖼️",
      alias: ["pinterest"],
      desc: "Search for related pics on unsplash.com.",
      category: "download",
      use: ".pin supra",
      filename: __filename
    };
    cmd(_0x1816b7, async (_0x22fc5d, _0x51fc71, _0x555ae2, {
      from: _0x20d2b7,
      l: _0x1ab702,
      prefix: _0x28d340,
      quoted: _0x5e0b04,
      body: _0x5acda4,
      isCmd: _0x7e902b,
      command: _0x243514,
      args: _0x5982db,
      q: _0x89ea5d,
      isGroup: _0x37cf2c,
      sender: _0x275654,
      senderNumber: _0x306d6f,
      botNumber2: _0x1ce4c1,
      botNumber: _0x421cce,
      pushname: _0x3bbc65,
      isMe: _0x12823e,
      isOwner: _0x199117,
      groupMetadata: _0x514d0a,
      groupName: _0x21b49c,
      participants: _0x2d1a0c,
      groupAdmins: _0x4a1f25,
      isBotAdmins: _0x68fe17,
      isAdmins: _0x5a6450,
      reply: _0x3a7e68
    }) => {
      try {
        if (!_0x89ea5d) {
          return await _0x3a7e68("```Please write a few words!```");
        }
        const _0x57cb93 = await fetchJson("https://allstars-apis.vercel.app/pinterest?search=" + _0x89ea5d);
        const _0x3f3f3d = {
          text: N_FOUND
        };
        const _0x4e16a4 = {
          quoted: _0x51fc71
        };
        if (_0x57cb93.data.length < 1) {
          return await _0x22fc5d.sendMessage(_0x20d2b7, _0x3f3f3d, _0x4e16a4);
        }
        var _0x1d5a43 = [];
        let _0x5d82d5 = 1;
        for (var _0x90128d = 0; _0x90128d < _0x57cb93.data.length; _0x90128d++) {
          _0x1d5a43.push({
            'rows': [{
              'title': "Image number: " + _0x5d82d5++,
              'id': _0x28d340 + "dimg " + _0x57cb93.data[_0x90128d]
            }]
          });
        }
        const _0xc33b3a = [{
          'name': "single_select",
          'buttonParamsJson': JSON.stringify({
            'title': "Tap Here!",
            'sections': _0x1d5a43
          })
        }];
        const _0x5b175d = {
          image: "https://github.com/G4tito/Simple-WaBot/blob/main/media/image/cover.jpg?raw=true",
          header: '',
          footer: "X-BYTE POWERED BY TALKDROVE",
          body: "乂 P I N - D O W N L O A D E R "
        };
        const _0x56b2d8 = {
          quoted: _0x51fc71
        };
        return await _0x22fc5d.sendButtonMessage(_0x20d2b7, _0xc33b3a, _0x555ae2, _0x5b175d, _0x56b2d8);
      } catch (_0x2ae717) {
        _0x3a7e68("*I couldn't find anything :(*");
        _0x1ab702(_0x2ae717);
      }
    });
  }
  const _0x1fe6b3 = {
    pattern: "imgno",
    react: '👾',
    desc: "to down images",
    category: '',
    use: ".im",
    filename: __filename
  };
  cmd(_0x1fe6b3, async (_0x4d3e4d, _0x49b0b4, _0x4b1e37, {
    from: _0xb39ae7,
    q: _0x1d1906,
    reply: _0xa96c42
  }) => {
    try {
      if (!_0x1d1906) {
        throw "Example: " + (prefix + command) + " Bike";
      }
      let _0x3f7d91 = require("g-i-s");
      _0x3f7d91(_0x1d1906, async (_0x2877f2, _0x3c3536) => {
        if (_0x2877f2) {
          console.error("Error fetching images:", _0x2877f2);
          return _0xa96c42("Error fetching images. Please try again later.");
        }
        const _0x3d5cb2 = _0x3c3536.slice(0, 5);
        for (let _0x26a669 = 0; _0x26a669 < _0x3d5cb2.length; _0x26a669++) {
          const _0x27b048 = _0x3d5cb2[_0x26a669].url;
          const _0x47c683 = {
            url: _0x27b048
          };
          let _0x442bd3 = {
            'image': _0x47c683,
            'caption': "*-------「 X-BYTE   GIMAGE SEARCH 」-------*\n🤠 *Query* : " + _0x1d1906 + "\n\n🔗 *Image " + (_0x26a669 + 1) + " Url* : " + _0x27b048
          };
          const _0x22c0ce = {
            quoted: _0x4b1e37
          };
          _0x4d3e4d.sendMessage(_0xb39ae7, _0x442bd3, _0x22c0ce);
        }
      });
      const _0xc1c2a4 = {
        text: '✅',
        key: _0x4b1e37.key
      };
      const _0x3440cb = {
        react: _0xc1c2a4
      };
      await _0x4d3e4d.sendMessage(_0xb39ae7, _0x3440cb);
    } catch (_0x4040f9) {
      l(_0x4040f9);
    }
  });
  const _0x48e7c2 = {
    pattern: "imgdoc",
    react: '👾',
    desc: "to down images",
    category: '',
    use: ".im",
    filename: __filename
  };
  cmd(_0x48e7c2, async (_0x993083, _0x29938b, _0x3e3925, {
    from: _0x3721b5,
    q: _0x9430ed,
    reply: _0x2f24f5
  }) => {
    try {
      if (!_0x9430ed) {
        throw "Example: " + (prefix + command) + " Bike";
      }
      let _0xee2295 = require("g-i-s");
      _0xee2295(_0x9430ed, async (_0x5e3dec, _0x3a544b) => {
        if (_0x5e3dec) {
          console.error("Error fetching images:", _0x5e3dec);
          return _0x2f24f5("Error fetching images. Please try again later.");
        }
        const _0x2c7310 = _0x3a544b.slice(0, 5);
        for (let _0x5255d4 = 0; _0x5255d4 < _0x2c7310.length; _0x5255d4++) {
          const _0x3c827a = _0x2c7310[_0x5255d4].url;
          const _0x27e50a = {
            url: _0x3c827a
          };
          let _0x2d8f1b = {
            'document': _0x27e50a,
            'fileName': "image.jpg",
            'mimetype': "image/jpeg",
            'caption': "*-------「 X-BYTE   GIMAGE SEARCH 」-------*\n🤠 *Query* : " + _0x9430ed + "\n\n🔗 *Image " + (_0x5255d4 + 1) + " Url* : " + _0x3c827a
          };
          const _0x7ac48a = {
            quoted: _0x3e3925
          };
          _0x993083.sendMessage(_0x3721b5, _0x2d8f1b, _0x7ac48a);
        }
      });
      const _0x2b30c3 = {
        text: '✅',
        key: _0x3e3925.key
      };
      const _0x1668be = {
        react: _0x2b30c3
      };
      await _0x993083.sendMessage(_0x3721b5, _0x1668be);
    } catch (_0x382477) {
      l(_0x382477);
    }
  });