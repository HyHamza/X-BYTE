function _0xf482() {
    const _0x2f263d = ['gbJdLZldQG', 'WPaOWR4mW7C', 'AhhcLSox', 'W4dcKe12', 'W5jPWR8', 'kSoRACkNtSotDmksgmoEWOOhgG', 'WOfwWOxdMYHhcq', 'W5RcKvf3uq', 't8kIWOD9W64', 'EmkYoSoQ', 'W4tdQI/cOse', 'WQf5W7nNW7q', 'wmk2WQnbWOJdHSoMW6vDk3S', 'W6FdHLtcMa', 'u1dcO8oIoa', 'gCot8jQhPN3dPq', 'WRldPGFdN8oS', 'W7pWUlw+WPddJ2G', 'WRldG8oAWPLl', 'k2RdSSkevW', 'WPCrWQdcKMK', 'W4NcLbpdJCo8', 'W5Kgya', 'eXbmWQO7', 'W5xcLqO', 'W5VdQ3XYWQi', 'WOVdTH1/W4i', 'smkxW50ura', 'D3lcHW8Z', 'WPTEWR0', 'W5jesNNcVG', 'C8kiACk2WPS', 'E8odWRm8oG', 'W7BcPIZdPCoc', 'd8oMW64tW5G', 'ANlcGGrU', 'WRWUcuO', 'W4pcKW/dG8o+', 'W67dMSk9WRW', 'j8kvWQzrW5m', 'jXtdRxel', 'WOLnivzZ', 'dCoSW60EW5W', 'WOdcQIlcJmoi', 'W4bXaW', 'W4ZcRM5iWOe', 'W6xcML0VwW', 'FSk2oq', 'WOTDWQBcJW', 'WP7cNu7cLrqVW7PLcq', 'WPldPmo2', 'W5hcQKSHWOfpsHaqnCk2WOfx', 'W4FdGGz5W5O', 'A3xcJG', 'WPzuWQa', 'WO9PgNy', 'W444FSogWOq', 'AcVcQmkOCa', 'pbVdRx8i', 'WRXCW6TkWQJdGqGOmmkT', 'EmkbcSkHWOm', 'W67dLCkbW6xcRbLXdmoIyq', 'WOfrvJdcQa', 'WOzzWRRcHcu', 'WPBdNL7cLCkNnmk7i8kVyXzZAG', 'W4tdJfBcLWW', 'WPNdPSo6WQu', 'WO5CkK14', '4PArWPFcMSoUra', 'WQ95WR0sWQe', 'iHDmWQmS', 'WOzwnXG8', 'W67cRSoDu8oE', 'EMNcNarL', 'W5jTWR/dIXK', 'W5zSaG', 'tKRcKMNcTZhdNmkIsSk9q1lcRa', 'mCoBWRO0W7W', 'AxpcM8ox', 'DSk2pCo0gG', 'W5ZcRKveWOq', 'hCk5wLLv', 'WOpdQmoNWR9V', 'l8ohuCoaya', 'jJDHWOCW', 'W5dcMLP6wq', 'AWtcUYruhCo/W4iPWPzYWO3dLW', 'W4NdHqmV', 'pJhdGCoCha', 'e8k/WOHMW6i', 'WOBdUSo2', 'W4BcK8ofWPLU', 'WRZdVWO', 'W4n3WRJdHHS', 'W5fMhdG', 'WP9qWR3cKW', 'W5jCWRBcHhy', 'WP7IJ7mxFmo2', 'uSkbESkDoq', 'wCkQWRaVbW', 'W7jqt+kDJq', 'WPD9WQ3dNHS', 'WQJdLwvMwW', 'zhBcMSodha', 'cSoEWOWFoq', 'jSoXWQxcK2y', 'W6hcMmozrmou', 'W4HEuW', 'qSkqyG', 'WRRdS8kedmkiW4NdKwlcMu8ncW', 'zdRcVmk3xW', 'WRhcImoBWRNcNG', 'WPHbEbOW', 'BsBcHarL', 'WQldMW5MW7vBqmkUW4NcVG', 'uCkqCG', 'W7i5WQSJtev8', 'WP7cImooWOrp', 'amopWRyKga', 'v8knW5yfda', 't8kwD8kMoa', 'W7KKWRuiW5a+W5fRWOFdPW', 'WP3dIMhcK8km', 'WQS/cebY', 'DXepzsK', 'yNRcJ8omdq', '8yMwIo+5Tq', 'u1FcIJ3dQW', 'W7RcP21dfq', 'gCoIW64eW5u', 'pvxdUNuc', 'eCokWO1dxSo/W4nZWRmspSkJ', 'WOGyWPq1W7y', 'W4jQWRJdHra', 'AeiiBmob', 'Ec4HEca', 'W7xcR8oirSoB', 'Eg/cHW9N', 'uKVcOa', 'uSkxWPKfca', 'W5BcK0WLfq', 'W5BcIqdcHGm', 'WP7dQmoJ', 'kmofzSoktG', 'W6hcQmoEvq', 'grJdSX3cLa', 'WPdcJ8osWPLZ', 'dHddIZBdRG', 'BcBdIKSJ', 'WOxcVbvTW5G', 'WQ1mawL2', 'gmo6WP18W6y', 'W7FcPvfzWOm', 'EGroomoramk7WODXW5pcOupcGa', 'WP5yWR3cNa', 'W5aJqtr3', 'WR3dUbWqW5DKWPyVsJLtv8kX', 'g8o6rSoq', 'gbJdUqe', 'W5VcJeHDCW', 'WPX0dhTn', 'DEkDVmk/uSkU', 'W7NWVygUW6SGWOC', 'WQxdGqKbW4C', 'WPFdP2S', 'WRCuWOW2wa', 'W708WPWaWOm', 'qSkbnSkGka', 'rSkksCk2oa', 'WO5bieW1', 'WQ3dM0m', 'h3tdPHbB', 'W5RcLmogwSoM', 'WObuWQpcM3W', 'nmo9DmoTFa', 'EtGaDq8', 'Bmk+mSo3mG', 'hb7dGhhdTG', 'WPFcTx3cGCko', 'W7ZcV0HvWPi', 'yIRcQmkEWOe', 'yHCYDHC', 'vK0aWRWOkSoCWPX4', 'bviiESka', 'WOjdW4LTW5m', 'WQCfWOmnBW', 'WOrqkXW1', 'lSoUzCkIr8kIa8k6gmoOWPi', 'W4JdImkzWPb1', 'pL7dKZW', 'WPZcMKhdL1DsWOjll8oJW7NdR1a', 'W4/cHGi', 'h2u0r8kM', 'm8kHWQldM3u', 'W4tcKHtdJCoK', 'WRH5W79aWQ8', '8jUKU8oNWQvZW6e', 'BmkzaSk4WOC', 'AmkEaSkGWOC', 'xSo2eCox', 'gCoItSkjxq', 'WOSJkXro', 'WQ9Wdh9m', 'cSoIW64vW5C', 'zXO4lSkl', 'kf3dQNuk', 'p8o7FmkZxW'];
    _0xf482 = function () {
      return _0x2f263d;
    };
    return _0xf482();
  }
  (function (_0xee9209, _0x4b814b) {
    const _0xa88f3 = _0xee9209();
    while (true) {
      try {
        const _0x3eccc3 = -parseInt(_0x4d5c(477, '9dx^')) / 1 + -parseInt(_0x4d5c(395, ')vEc')) / 2 * (-parseInt(_0x4d5c(326, 'Fyf6')) / 3) + parseInt(_0x4d5c(329, ')vEc')) / 4 + parseInt(_0x4d5c(499, 'NW*v')) / 5 * (parseInt(_0x4d5c(462, 'EArQ')) / 6) + -parseInt(_0x4d5c(432, 'v[%F')) / 7 + parseInt(_0x4d5c(397, '*6fO')) / 8 + -parseInt(_0x4d5c(407, '0c7*')) / 9 * (parseInt(_0x4d5c(467, 'RDht')) / 10);
        if (_0x3eccc3 === _0x4b814b) {
          break;
        } else {
          _0xa88f3.push(_0xa88f3.shift());
        }
      } catch (_0x5eab87) {
        _0xa88f3.push(_0xa88f3.shift());
      }
    }
  })(_0xf482, 473206);
  const config = require("../settings");
  function _0x10fda3(_0xa17aa4, _0x39e260, _0x3676b5, _0x5d6b0c, _0x19bd45) {
    return _0x4d5c(_0x39e260 - 0xe1, _0xa17aa4);
  }
  const {
    cmd,
    commands
  } = require("../lib/command");
  const {
    getBuffer,
    getGroupAdmins,
    getRandom,
    h2k,
    isUrl,
    Json,
    runtime,
    sleep,
    fetchJson
  } = require("../lib/functions");
  function _0x116fbd(_0x80479d, _0x3a12ce, _0xaa4fdb, _0x16cd2a, _0x412243) {
    return _0x4d5c(_0x16cd2a - 0x1d3, _0xaa4fdb);
  }
  function _0x4d5c(_0x304bd5, _0x13b7d9) {
    const _0xa003d4 = _0xf482();
    _0x4d5c = function (_0x5f420a, _0x296214) {
      _0x5f420a = _0x5f420a - 295;
      let _0x2203de = _0xa003d4[_0x5f420a];
      if (_0x4d5c.EDKHfW === undefined) {
        var _0x400683 = function (_0x3d1f7d) {
          let _0x1e7551 = '';
          let _0x5e1f69 = '';
          let _0x451b18 = 0;
          let _0x1ee09b;
          let _0x18d346;
          for (let _0x7d8698 = 0; _0x18d346 = _0x3d1f7d.charAt(_0x7d8698++); ~_0x18d346 && (_0x1ee09b = _0x451b18 % 4 ? _0x1ee09b * 64 + _0x18d346 : _0x18d346, _0x451b18++ % 4) ? _0x1e7551 += String.fromCharCode(255 & _0x1ee09b >> (-2 * _0x451b18 & 6)) : 0) {
            _0x18d346 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/='.indexOf(_0x18d346);
          }
          let _0x2d4ca0 = 0;
          for (let _0x259c42 = _0x1e7551.length; _0x2d4ca0 < _0x259c42; _0x2d4ca0++) {
            _0x5e1f69 += '%' + ('00' + _0x1e7551.charCodeAt(_0x2d4ca0).toString(16)).slice(-2);
          }
          return decodeURIComponent(_0x5e1f69);
        };
        const _0x2f0eb1 = function (_0xd51dec, _0x400ae1) {
          let _0xa1d001 = [];
          let _0x39d260 = 0;
          let _0x5e92fb;
          let _0x120453 = '';
          _0xd51dec = _0x400683(_0xd51dec);
          let _0x4b3c05;
          for (_0x4b3c05 = 0; _0x4b3c05 < 256; _0x4b3c05++) {
            _0xa1d001[_0x4b3c05] = _0x4b3c05;
          }
          for (_0x4b3c05 = 0; _0x4b3c05 < 256; _0x4b3c05++) {
            _0x39d260 = (_0x39d260 + _0xa1d001[_0x4b3c05] + _0x400ae1.charCodeAt(_0x4b3c05 % _0x400ae1.length)) % 256;
            _0x5e92fb = _0xa1d001[_0x4b3c05];
            _0xa1d001[_0x4b3c05] = _0xa1d001[_0x39d260];
            _0xa1d001[_0x39d260] = _0x5e92fb;
          }
          _0x4b3c05 = 0;
          _0x39d260 = 0;
          for (let _0x32ab27 = 0; _0x32ab27 < _0xd51dec.length; _0x32ab27++) {
            _0x4b3c05 = (_0x4b3c05 + 1) % 256;
            _0x39d260 = (_0x39d260 + _0xa1d001[_0x4b3c05]) % 256;
            _0x5e92fb = _0xa1d001[_0x4b3c05];
            _0xa1d001[_0x4b3c05] = _0xa1d001[_0x39d260];
            _0xa1d001[_0x39d260] = _0x5e92fb;
            _0x120453 += String.fromCharCode(_0xd51dec.charCodeAt(_0x32ab27) ^ _0xa1d001[(_0xa1d001[_0x4b3c05] + _0xa1d001[_0x39d260]) % 256]);
          }
          return _0x120453;
        };
        _0x4d5c.oAaRYl = _0x2f0eb1;
        _0x304bd5 = arguments;
        _0x4d5c.EDKHfW = true;
      }
      const _0xb9999d = _0xa003d4[0];
      const _0x4d18a8 = _0x5f420a + _0xb9999d;
      const _0x12f1e2 = _0x304bd5[_0x4d18a8];
      if (!_0x12f1e2) {
        if (_0x4d5c.KcJneC === undefined) {
          _0x4d5c.KcJneC = true;
        }
        _0x2203de = _0x4d5c.oAaRYl(_0x2203de, _0x296214);
        _0x304bd5[_0x4d18a8] = _0x2203de;
      } else {
        _0x2203de = _0x12f1e2;
      }
      return _0x2203de;
    };
    return _0x4d5c(_0x304bd5, _0x13b7d9);
  }
  if (config.COMMAND_TYPE === "button") {
    const _0x12f1e2 = {
      pattern: "xnxx",
      react: "🙄",
      desc: "Get news",
      use: ".xxx",
      filename: __filename
    };
    cmd(_0x12f1e2, async (_0x1de0cf, _0x373622, _0x50235a, {
      from: _0x411b2d,
      q: _0x41678d,
      isMe: _0x210695,
      prefix: _0x1d3b9f,
      pushname: _0x5190ba,
      reply: _0x514060
    }) => {
      try {
        if (!_0x210695) {
          return await _0x514060(" 🔐 Premium users only can use this command\nbuy via message to owner buy type .owner!!");
        }
        const _0x17533b = require("api-dylux");
        let _0x1769d6 = await _0x17533b.xnxxSearch(_0x41678d);
        const _0x575958 = [];
        let _0x1449bc = _0x1769d6.result.map((_0xb56b29, _0x148c80) => _0x148c80 + 1 + "┃ *Title* : " + _0xb56b29.title + "\n*Link:* " + _0xb56b29.link + "\n").join("\n");
        if (_0x1769d6.status) {
          _0x373622.reply(_0x1449bc);
        }
        const _0x319320 = _0x1769d6.result;
        for (var _0x282f63 = 0; _0x282f63 < _0x319320.length; _0x282f63++) {
          _0x575958.push({
            'header': _0x282f63 + 1,
            'title': '' + _0x319320[_0x282f63].title,
            'description': '',
            'id': _0x1d3b9f + "xnxxdl " + _0x319320[_0x282f63].link
          });
        }
        const _0x5b51f7 = {
          display_text: config.BTN,
          url: config.BTNURL,
          merchant_url: config.BTNURL
        };
        let _0x5c8ec8 = [{
          'name': "cta_url",
          'buttonParamsJson': JSON.stringify(_0x5b51f7)
        }, {
          'name': "single_select",
          'buttonParamsJson': JSON.stringify({
            'title': "Select news types",
            'sections': [{
              'title': "Please select a category",
              'highlight_label': "X-BYTE",
              'rows': _0x575958
            }]
          })
        }];
        const _0x3feea3 = {
          image: config.LOGO,
          header: '',
          footer: config.FOOTER,
          body: "> X-BYTE VIDEO DOWNLOADER"
        };
        const _0x2ffc8c = {
          quoted: _0x373622
        };
        return await _0x1de0cf.sendButtonMessage(_0x411b2d, _0x5c8ec8, _0x50235a, _0x3feea3, _0x2ffc8c);
      } catch (_0x179f4c) {
        _0x514060("*Error !!*");
        console.log(_0x179f4c);
      }
    });
  }
  const _0xe34ad9 = {
    pattern: "xnxxdl",
    react: '👾'
  };
  function _0x4e91ee(_0x5edd27, _0x829ec8, _0x5f5d67, _0x2527c1, _0x287f68) {
    return _0x4d5c(_0x2527c1 - 0x85, _0x287f68);
  }
  function _0x26cf6d(_0x467db8, _0x4e5d59, _0x551c6e, _0x2ef2f0, _0x14c07a) {
    return _0x4d5c(_0x551c6e - 0x1bf, _0x14c07a);
  }
  function _0x4769b3(_0x18113b, _0x237e4d, _0x52099b, _0x18a014, _0x4ea982) {
    return _0x4d5c(_0x18a014 + 0xe9, _0x4ea982);
  }
  _0xe34ad9.desc = "to take xnxx video";
  _0xe34ad9.category = "download";
  _0xe34ad9.use = ".xnxxdl";
  _0xe34ad9.filename = __filename;
  cmd(_0xe34ad9, async (_0x23b827, _0x331b1a, _0xf808ca, {
    from: _0xdc0d73,
    l: _0x1f0a38,
    prefix: _0x1f242b,
    quoted: _0x4747ec,
    body: _0x15b155,
    isCmd: _0x14e440,
    command: _0x4131ef,
    args: _0x142418,
    q: _0x397b8c,
    isGroup: _0x363783,
    sender: _0x54c6f3,
    senderNumber: _0x283552,
    botNumber2: _0x1c8aa4,
    botNumber: _0x27b184,
    pushname: _0x2e1b9a,
    isMe: _0x36e57a,
    isOwner: _0x2fdb60,
    groupMetadata: _0x18bf1b,
    groupName: _0x5c1aee,
    participants: _0x2cd573,
    groupAdmins: _0x1ee146,
    isBotAdmins: _0x2ef969,
    isAdmins: _0x3a151d,
    reply: _0x5832eb
  }) => {
    try {
      if (!_0x397b8c.includes("xnxx.com")) {
        return _0x331b1a.reply("Enter an xnxx link");
      }
      const _0xdd1e71 = require("api-dylux");
      let _0x2f9917 = await _0xdd1e71.xnxxdl(_0x397b8c);
      const _0x4a09f7 = {
        caption: "  *XNXX DL*\n        \n✍ *Title:* " + _0x2f9917.title + "\n⌛ *Duration:* " + _0x2f9917.duration + "\n📽 *Visual Quality:* " + _0x2f9917.quality,
        video: {}
      };
      _0x4a09f7.video.url = _0x2f9917.url_dl;
      _0x23b827.sendMessage(_0x331b1a.chat, _0x4a09f7, {
        'quoted': _0x331b1a
      });
    } catch (_0x182925) {
      _0x1f0a38(_0x182925);
    }
  });